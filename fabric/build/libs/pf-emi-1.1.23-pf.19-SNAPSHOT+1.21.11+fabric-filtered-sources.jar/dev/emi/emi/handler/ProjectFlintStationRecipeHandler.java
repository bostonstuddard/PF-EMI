package dev.emi.emi.handler;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;

/**
 * Ingredient-transfer support for known ProjectFlint machine screens.
 * The machine remains authoritative for processing, fuel, and output timing.
 * We intentionally do not auto-collect result slots.
 */
public final class ProjectFlintStationRecipeHandler implements StandardRecipeHandler<class_1703> {
    private final String categoryId;
    private final int[] inputSlotIds;

    public ProjectFlintStationRecipeHandler(String categoryId, int... inputSlotIds) {
        this.categoryId = "projectflint:" + categoryId;
        this.inputSlotIds = inputSlotIds.clone();
    }

    @Override
    public boolean supportsRecipe(EmiRecipe recipe) {
        return recipe.supportsRecipeTree() && recipe.getCategory() != null
            && recipe.getCategory().getId() != null
            && categoryId.equals(recipe.getCategory().getId().toString())
            && !recipe.getInputs().isEmpty() && recipe.getInputs().size() <= inputSlotIds.length;
    }

    @Override
    public List<class_1735> getCraftingSlots(class_1703 handler) {
        List<class_1735> slots = new ArrayList<>();
        for (int slotId : inputSlotIds) slots.add(handler.method_7611(slotId));
        return slots;
    }

    @Override
    public List<class_1735> getInputSources(class_1703 handler) {
        List<class_1735> sources = new ArrayList<>(getCraftingSlots(handler));
        var player = class_310.method_1551().field_1724;
        if (player == null) return sources;
        for (class_1735 slot : handler.field_7761) {
            // Real player inventory only: never pull ghost preview items or recipe outputs.
            if (slot.field_7871 == player.method_31548() && slot.method_7682()) sources.add(slot);
        }
        return sources;
    }
}
