package dev.emi.emi.jemi.impl;

import java.util.Collection;
import java.util.List;

import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Either;

import dev.emi.emi.runtime.EmiLog;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.runtime.IJeiKeyMapping;
import net.minecraft.class_2561;
import net.minecraft.class_5348;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

public class JemiTooltipBuilder implements ITooltipBuilder {
	public final List<class_5684> tooltip = Lists.newArrayList();
	public final List<class_2561> texts = Lists.newArrayList(); // TODO

	@Override
	public void add(class_5348 component) {
		// JEI allows non-text StringVisitable... Minecraft's methods don't easily
		if (component instanceof class_2561 text) {
			tooltip.add(class_5684.method_32662(text.method_30937()));
			texts.add(text);
		}
	}

	@Override
	public void addAll(Collection<? extends class_5348> components) {
		for (class_5348 v : components) {
			add(v);
		}
	}

	@Override
	public void add(class_5632 data) {
		try {
			tooltip.add(class_5684.method_32663(data));
		} catch (Exception e) {
			EmiLog.error("Error converting TooltipComponent", e);
		}
	}

    @Override
    public void addKeyUsageComponent(String s, IJeiKeyMapping iJeiKeyMapping) {

    }

    @Override
	public void setIngredient(ITypedIngredient<?> typedIngredient) {
		// EMI's methods bypass the vanilla tooltip render which accepts a stack, so this will do nothing
	}

	@Override
	public void clear() {
		// EMI does not support tooltip removeal, this will only clear the user's additions
	}

    @Override
    public void clearIngredient() {

    }

    @Override
    public List<Either<class_5348, class_5632>> getLines() {
        return List.of();
    }

}
