package dev.emi.emi.jemi.impl;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.config.FluidUnit;
import dev.emi.emi.jemi.JemiStack;
import dev.emi.emi.jemi.JemiUtil;
import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.gui.ingredient.IRecipeSlotRichTooltipCallback;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.class_10302;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_9326;
import javax.naming.Context;

public class JemiIngredientAcceptor implements IIngredientAcceptor<JemiIngredientAcceptor> {
	public static final Pattern FLUID_END = Pattern.compile("(^|\\s)([\\d,]+)\\s*mB$");
	public final RecipeIngredientRole role;
	public final List<EmiStack> stacks = Lists.newArrayList();

	public JemiIngredientAcceptor(RecipeIngredientRole role) {
		this.role = role;
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public void coerceStacks(IRecipeSlotRichTooltipCallback tooltipCallback, Map<IIngredientType<?>, JemiRecipeSlot.IngredientRenderer<?>> renderers) {
		if (tooltipCallback == null && renderers == null) {
			return;
		}
		for (EmiStack stack : stacks) {
			ITypedIngredient typed = JemiUtil.getTyped(stack).orElse(null);
			if (typed != null && (stack instanceof JemiStack || stack.getKey() instanceof class_3611)) {
				List<class_2561> base = Lists.newArrayList();
				if (renderers != null && renderers.containsKey(typed.getType())) {
					base.addAll(((JemiRecipeSlot.IngredientRenderer) renderers.get(typed.getType())).renderer().getTooltip(typed.getIngredient(), class_1836.field_41070));
				}
				if (base == null || base.isEmpty()) {
					if (tooltipCallback == null) {
						continue;
					}
					base.add(stack.getName());
					base.add(EmiPort.literal(""));
				}
				if (tooltipCallback != null) {
					JemiRecipeSlot jsr = new JemiRecipeSlot(role, stack);
					JemiTooltipBuilder builder = new JemiTooltipBuilder();
					tooltipCallback.onRichTooltip(jsr, builder);
					base.addAll(builder.texts);
				}
				for (int i = 0; i < 2 && i < base.size(); i++) {
					class_2561 t = base.get(i);
					if (t != null) {
						Matcher m = FLUID_END.matcher(t.getString());
						if (m.find()) {
							long amount = Long.parseLong(m.group(2).replace(",", ""));
							if (amount != stack.getAmount()) {
								stack.setAmount(amount);
							}
						}
					}
				}
			}
		}
	}

	public EmiIngredient build() {
		return EmiIngredient.of(stacks);
	}

	private void addStack(EmiStack stack) {
		if (!stack.isEmpty()) {
			stacks.add(stack);
		}
	}

    @Override
    public JemiIngredientAcceptor add(class_10302 slotDisplay) {
		class_310 client = class_310.method_1551();
		if (client.field_1687 != null) {
			for (class_1799 stack : slotDisplay.method_64738(class_10363.method_65008(client.field_1687))) {
				addStack(EmiStack.of(stack));
			}
		}
		return this;
    }

    @Override
    public JemiIngredientAcceptor add(class_3611 fluid) {
		addFluidStack(fluid);
        return this;
    }

    @Override
    public JemiIngredientAcceptor add(class_3611 fluid, long amount) {
		addFluidStack(fluid, amount);
        return this;
    }

    @Override
    public JemiIngredientAcceptor add(class_3611 fluid, long amount, class_9326 componentChanges) {
		addFluidStack(fluid, amount, componentChanges);
        return this;
    }

    @Override
    public JemiIngredientAcceptor add(class_1856 ingredient) {
		add(ingredient.method_64673());
		return this;
    }

    @Override
    public <I> JemiIngredientAcceptor add(IIngredientType<I> ingredientType, I i) {
		addIngredient(ingredientType, i);
        return this;
    }

    @Override
	public <I> JemiIngredientAcceptor addIngredients(IIngredientType<I> ingredientType, List<@Nullable I> ingredients) {
		for (I i : ingredients) {
			addIngredient(ingredientType, i);
		}
		return this;
	}

	@Override
	public <I> JemiIngredientAcceptor addIngredient(IIngredientType<I> ingredientType, I ingredient) {
		addStack(JemiUtil.getStack(ingredientType, ingredient));
		return this;
	}

	@Override
	public JemiIngredientAcceptor addIngredientsUnsafe(List<?> ingredients) {
		for (Object o : ingredients) {
			addStack(JemiUtil.getStack(o));
		}
		return this;
	}

	@Override
	public JemiIngredientAcceptor addFluidStack(class_3611 fluid) {
		return addFluidStack(fluid, FluidUnit.BUCKET);
	}

	@Override
	public JemiIngredientAcceptor addFluidStack(class_3611 fluid, long amount) {
		addStack(EmiStack.of(fluid, amount));
		return this;
	}
	
	@Override
	public JemiIngredientAcceptor addFluidStack(class_3611 fluid, long amount, class_9326 componentChanges) {
		addStack(EmiStack.of(fluid, componentChanges, amount));
		return this;
	}

	@Override
	@SuppressWarnings({"rawtypes", "unchecked"})
	public JemiIngredientAcceptor addTypedIngredients(List<ITypedIngredient<?>> ingredients) {
		for (ITypedIngredient<?> i : ingredients) {
			addIngredient(((IIngredientType) i.getType()), i.getIngredient());
		}
		return this;
	}

	@Override
	@SuppressWarnings({"rawtypes", "unchecked"})
	public JemiIngredientAcceptor addOptionalTypedIngredients(List<Optional<ITypedIngredient<?>>> ingredients) {
		for (Optional<ITypedIngredient<?>> opt : ingredients) {
			if (opt.isPresent()) {
				ITypedIngredient<?> i = opt.get();
				addIngredient(((IIngredientType) i.getType()), i.getIngredient());
			}
		}
		return this;
	}
}
