package dev.emi.emi.jemi.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import com.google.common.collect.Lists;

import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.jemi.widget.JemiSlotWidget;
import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.ingredient.IRecipeSlotDrawable;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_768;

public class JemiRecipeSlotDrawable implements IRecipeSlotDrawable {
	public JemiSlotWidget widget;
	public List<IIngredientAcceptor<?>> overrides = Lists.newArrayList();

	@Override
	public Stream<ITypedIngredient<?>> getAllIngredients() {
		return widget.slot.getAllIngredients();
	}

	@Override
	public @Unmodifiable List<@Nullable ITypedIngredient<?>> getAllIngredientsList() {
		return widget.slot.getAllIngredientsList();
	}

	@Override
	public Optional<ITypedIngredient<?>> getDisplayedIngredient() {
		return widget.slot.getDisplayedIngredient();
	}

	@Override
	public RecipeIngredientRole getRole() {
		return widget.slot.getRole();
	}

	@Override
	public void drawHighlight(class_332 raw, int color) {
		widget.slot.drawHighlight(raw, color);
	}

	@Override
	public Optional<String> getSlotName() {
		return widget.slot.getSlotName();
	}

	@Override
	public void draw(class_332 raw) {
		// I don't think I will
	}

	@Override
	public void drawHoverOverlays(class_332 raw) {
		// I don't think I will
	}

	@Override
	public List<class_2561> getTooltip() {
		// Unimplemented
		// Mutable because who knows
		return Lists.newArrayList();
	}

	@Override
	public void getTooltip(ITooltipBuilder tooltipBuilder) {
		// Unimplemented
	}

    @Override
    public void drawTooltip(class_332 guiGraphics, int mouseX, int mouseY) {

    }

    @Override
	public boolean isMouseOver(double mouseX, double mouseY) {
		return widget.getBounds().contains((int) mouseX, (int) mouseY);
	}

	@Override
	public void setPosition(int x, int y) {
		// Nope
	}

//	@Override
//	public IIngredientConsumer createDisplayOverrides() {
//		// "Implemented" but also just ignored
//		JemiIngredientConsumer consumer = new JemiIngredientConsumer();
//		overrides.add(consumer);
//		return consumer;
//	}

    @Override
    public IIngredientAcceptor<?> createDisplayOverrides() {
        // "Implemented" but also just ignored
        IIngredientAcceptor<?> consumer = new JemiIngredientAcceptor(RecipeIngredientRole.RENDER_ONLY); // TODO: review this
		overrides.add(consumer);
		return consumer;
    }

    @Override
	public void clearDisplayOverrides() {
		overrides.clear();
	}

	@Override
	public class_768 getAreaIncludingBackground() {
        Bounds bounds = widget.getBounds();
		return new class_768(bounds.x(), bounds.y(), bounds.width(), bounds.height());
	}
}
