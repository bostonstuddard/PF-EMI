package dev.emi.emi.jemi;

import java.util.List;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.jemi.impl.JemiTooltipBuilder;
import dev.emi.emi.runtime.EmiDrawContext;
import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.IIngredientTypeWithSubtypes;
import mezz.jei.api.ingredients.subtypes.UidContext;
import net.minecraft.class_124;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_9326;

public class JemiStack<T> extends EmiStack {
	private final IIngredientType<T> type;
	private final IIngredientHelper<T> helper;
	public final Object base;
	public final T ingredient;
	public IIngredientRenderer<T> renderer;

	public JemiStack(IIngredientType<T> type, IIngredientHelper<T> helper, IIngredientRenderer<T> renderer, T ingredient) {
		this.type = type;
		this.helper = helper;
		this.renderer = renderer;
		this.ingredient = ingredient;
		if (type instanceof IIngredientTypeWithSubtypes<?, T> iitws) {
			base = iitws.getBase(ingredient);
		} else {
			base = helper.getUid(ingredient, UidContext.Recipe);
		}
	}

    // TODO: review this
	public String getJeiUid() {
		return helper.getUid(ingredient, UidContext.Ingredient).toString();
	}

	@Override
	public void render(class_332 raw, int x, int y, float delta, int flags) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		int xOff = (16 - renderer.getWidth()) / 2;
		int yOff = (16 - renderer.getHeight()) / 2;
		context.push();
		context.matrices().translate(x + xOff, y + yOff/*, 0*/);
		renderer.render(context.raw(), ingredient);
		context.pop();
	}

	@Override
	public JemiStack<T> copy() {
		return new JemiStack<T>(type, helper, renderer, helper.copyIngredient(ingredient));
	}

	@Override
	public boolean isEmpty() {
		return !helper.isValidIngredient(ingredient);
	}

	@Override
	public class_9326 getComponentChanges() {
		return class_9326.field_49588;
	}

	@Override
	public Object getKey() {
		return base;
	}

	@Override
	public class_2960 getId() {
		return helper.getIdentifier(ingredient);
	}

	@Override
	public List<class_2561> getTooltipText() {
		return renderer.getTooltip(ingredient, class_1836.field_41070);
	}

	@Override
	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		class_310 client = class_310.method_1551();
		JemiTooltipBuilder builder = new JemiTooltipBuilder();
		renderer.getTooltip(builder, ingredient, client.field_1690.field_1827 ? class_1836.field_41071 : class_1836.field_41070);
		list.addAll(builder.tooltip);

		class_2960 id = getId();
		if (EmiConfig.appendModId && id != null) {
			String mod = EmiUtil.getModName(id.method_12836());
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.literal(mod, class_124.field_1078, class_124.field_1056))));
		}

		list.addAll(super.getTooltip());
		return list;
	}

	@Override
	public class_2561 getName() {
		return EmiPort.literal(helper.getDisplayName(ingredient));
	}
}
