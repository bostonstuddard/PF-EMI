package dev.emi.emi.jemi.runtime;

import java.util.List;
import java.util.Optional;

import dev.emi.emi.api.EmiDragDropHandler;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.jemi.JemiPlugin;
import dev.emi.emi.jemi.JemiUtil;
import dev.emi.emi.runtime.EmiDrawContext;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_768;

public class JemiDragDropHandler implements EmiDragDropHandler<class_437> {

	@Override
	@SuppressWarnings({"rawtypes", "unchecked"})
	public boolean dropStack(class_437 screen, EmiIngredient stack, int x, int y) {
		try {
			return this.<Object>drop(screen, (Optional<ITypedIngredient<Object>>) (Optional) JemiUtil.getTyped(stack.getEmiStacks().get(0)), x, y);
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	@SuppressWarnings({"rawtypes", "unchecked"})
	public void render(class_437 screen, EmiIngredient dragged, class_332 raw, int mouseX, int mouseY, float delta) {
		try {
			this.<Object>render(screen, EmiDrawContext.wrap(raw), (Optional<ITypedIngredient<Object>>) (Optional) JemiUtil.getTyped(dragged.getEmiStacks().get(0)));
		} catch (Exception e) {
		}
	}

	private <I> boolean drop(class_437 screen, Optional<ITypedIngredient<I>> optional, int x, int y) {
		if (optional.isPresent()) {
			for (IGhostIngredientHandler.Target<I> target : getTargets(screen, optional.get())) {
				if (target.getArea().method_3318(x, y)) {
					target.accept(optional.get().getIngredient());
					return true;
				}
			}
		}
		return false;
	}

	private <I> void render(class_437 screen, EmiDrawContext context, Optional<ITypedIngredient<I>> optional) {
		if (optional.isPresent()) {
			for (IGhostIngredientHandler.Target<I> target : getTargets(screen, optional.get())) {
				class_768 r = target.getArea();
				context.fill(r.method_3321(), r.method_3322(), r.method_3319(), r.method_3320(), 0x8822BB33);
			}
		}
	}

	private <I> List<IGhostIngredientHandler.Target<I>> getTargets(class_437 screen, ITypedIngredient<I> typed) {
//		Optional<IGhostIngredientHandler<Screen>> optGhost = JemiPlugin.runtime.getScreenHelper().getGhostIngredientHandler(screen);
//		if (optGhost.isPresent()) {
//			IGhostIngredientHandler<Screen> ghost = optGhost.get();
//			return ghost.getTargetsTyped(screen, typed, false);
//		} TODO
		return List.of();
	}
}
