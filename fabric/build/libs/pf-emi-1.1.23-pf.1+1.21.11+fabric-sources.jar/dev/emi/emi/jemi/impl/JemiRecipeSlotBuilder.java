package dev.emi.emi.jemi.impl;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Maps;

import dev.emi.emi.jemi.impl.JemiRecipeSlot.IngredientRenderer;
import dev.emi.emi.jemi.impl.JemiRecipeSlot.OffsetDrawable;
import dev.emi.emi.jemi.impl.JemiRecipeSlot.TankInfo;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotRichTooltipCallback;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.class_10302;
import net.minecraft.class_1856;
import net.minecraft.class_3611;
import net.minecraft.class_9326;

public class JemiRecipeSlotBuilder implements IRecipeSlotBuilder {
	public final JemiIngredientAcceptor acceptor;
	public boolean large = false, defaultBackground = false;
	public int x, y;
	public Optional<String> name = Optional.empty();
	public IRecipeSlotRichTooltipCallback richTooltipCallback;
	public OffsetDrawable background, overlay;
	public Map<IIngredientType<?>, IngredientRenderer<?>> renderers; 
	public TankInfo tankInfo;

	public JemiRecipeSlotBuilder(RecipeIngredientRole role, int x, int y) {
		this.acceptor = new JemiIngredientAcceptor(role);
		this.x = x;
		this.y = y;
	}

    @Override
    public IRecipeSlotBuilder add(class_10302 slotDisplay) {
        acceptor.add(slotDisplay);
        return this;
    }

    @Override
    public IRecipeSlotBuilder add(class_3611 fluid) {
        acceptor.add(fluid);
        return this;
    }

    @Override
    public IRecipeSlotBuilder add(class_3611 fluid, long l) {
        acceptor.add(fluid);
        return this;
    }

    @Override
    public IRecipeSlotBuilder add(class_3611 fluid, long l, class_9326 componentChanges) {
        acceptor.add(fluid, l, componentChanges);
        return this;
    }

    @Override
    public IRecipeSlotBuilder add(class_1856 ingredient) {
        acceptor.add(ingredient);
        return this;
    }

    @Override
    public <I> IRecipeSlotBuilder add(IIngredientType<I> iIngredientType, I i) {
        acceptor.add(iIngredientType, i);
        return this;
    }

    @Override
	public <I> IRecipeSlotBuilder addIngredients(IIngredientType<I> ingredientType, List<@Nullable I> ingredients) {
		acceptor.addIngredients(ingredientType, ingredients);
		return this;
	}

	@Override
	public <I> IRecipeSlotBuilder addIngredient(IIngredientType<I> ingredientType, I ingredient) {
		acceptor.addIngredient(ingredientType, ingredient);
		return this;
	}

	@Override
	public IRecipeSlotBuilder addIngredientsUnsafe(List<?> ingredients) {
		acceptor.addIngredientsUnsafe(ingredients);
		return this;
	}

	@Override
	public IRecipeSlotBuilder addFluidStack(class_3611 fluid, long amount) {
		acceptor.addFluidStack(fluid, amount);
		return this;
	}

	@Override
	public IRecipeSlotBuilder addFluidStack(class_3611 fluid, long amount, class_9326 componentChanges) {
		acceptor.addFluidStack(fluid, amount, componentChanges);
		return this;
	}

//	@Override
//	public IRecipeSlotBuilder addTooltipCallback(IRecipeSlotTooltipCallback tooltipCallback) {
//		this.tooltipCallback = tooltipCallback;
//		return this;
//	} TODO

	@Override
	public IRecipeSlotBuilder setSlotName(String slotName) {
		name = Optional.ofNullable(slotName);
		return this;
	}

	@Override
	public IRecipeSlotBuilder setBackground(IDrawable background, int xOffset, int yOffset) {
		this.background = new OffsetDrawable(background, xOffset, yOffset);
		return this;
	}

	@Override
	public IRecipeSlotBuilder setOverlay(IDrawable overlay, int xOffset, int yOffset) {
		this.overlay = new OffsetDrawable(overlay, xOffset, yOffset);
		return this;
	}

	@Override
	public IRecipeSlotBuilder setFluidRenderer(long capacity, boolean showCapacity, int width, int height) {
		this.tankInfo = new TankInfo(width, height, capacity, showCapacity);
		return this;
	}

	@Override
	public <T> IRecipeSlotBuilder setCustomRenderer(IIngredientType<T> ingredientType,
			IIngredientRenderer<T> ingredientRenderer) {
		if (renderers == null) {
			renderers = Maps.newHashMap();
		}
		renderers.put(ingredientType, new IngredientRenderer<T>(ingredientType, ingredientRenderer));
		return this;
	}

	@Override
	public IRecipeSlotBuilder addTypedIngredients(List<ITypedIngredient<?>> ingredients) {
		acceptor.addTypedIngredients(ingredients);
		return this;
	}

	@Override
	public IRecipeSlotBuilder addOptionalTypedIngredients(List<Optional<ITypedIngredient<?>>> ingredients) {
		acceptor.addOptionalTypedIngredients(ingredients);
		return this;
	}

	@Override
	public IRecipeSlotBuilder addRichTooltipCallback(IRecipeSlotRichTooltipCallback tooltipCallback) {
		richTooltipCallback = tooltipCallback;
		return this;
	}

	@Override
	public IRecipeSlotBuilder addFluidStack(class_3611 fluid) {
		acceptor.addFluidStack(fluid);
		return this;
	}

	@Override
	public IRecipeSlotBuilder setPosition(int xPos, int yPos) {
		this.x = xPos;
		this.y = yPos;
		return this;
	}

	@Override
	public int getWidth() {
		return large ? 26 : 18;
	}

	@Override
	public int getHeight() {
		return large ? 26 : 18;
	}

	@Override
	public IRecipeSlotBuilder setStandardSlotBackground() {
		this.defaultBackground = true;
		return this;
	}

	@Override
	public IRecipeSlotBuilder setOutputSlotBackground() {
		this.defaultBackground = true;
		this.large = true;
		return this;
	}
}
