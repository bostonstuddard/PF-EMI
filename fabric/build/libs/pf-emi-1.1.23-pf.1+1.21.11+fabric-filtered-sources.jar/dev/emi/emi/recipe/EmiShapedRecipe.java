package dev.emi.emi.recipe;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1869;
import net.minecraft.class_3955;
import net.minecraft.class_9694;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.recipe.EmiCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.runtime.EmiLog;

public class EmiShapedRecipe extends EmiCraftingRecipe {

	public EmiShapedRecipe(class_1869 recipe) {
		super(padIngredients(recipe), EmiStack.of(EmiPort.getOutput(recipe)), EmiPort.getId(recipe), false);
		setRemainders(input, recipe);
	}

	public static void setRemainders(List<EmiIngredient> input, class_3955 recipe) {
		try {
			class_1715 inv = EmiUtil.getCraftingInventory();
			for (int i = 0; i < input.size(); i++) {
				if (input.get(i).isEmpty()) {
					continue;
				}
				for (int j = 0; j < input.size(); j++) {
					if (j == i) {
						continue;
					}
					if (!input.get(j).isEmpty()) {
						inv.method_5447(j, input.get(j).getEmiStacks().get(0).getItemStack().method_7972());
					}
				}
				List<EmiStack> stacks = input.get(i).getEmiStacks();
				for (EmiStack stack : stacks) {
					inv.method_5447(i, stack.getItemStack().method_7972());
					class_9694 cri = class_9694.method_59986(inv.method_17398(), inv.method_17397(), inv.method_51305());
					if (cri.method_59991() <= 3 && cri.method_59992() <= 3) {
						class_1799 remainder = recipe.method_17704(cri).get((i / 3 * cri.method_59991()) + (i % 3));
						if (!remainder.method_7960()) {
							stack.setRemainder(EmiStack.of(remainder));
						}
					}
				}
				inv.method_5448();
			}
		} catch (Exception e) {
			EmiLog.error("Exception thrown setting remainders for " + EmiPort.getId(recipe), e);
		}
	}

	private static List<EmiIngredient> padIngredients(class_1869 recipe) {
		List<EmiIngredient> list = Lists.newArrayList();
		int i = 0;
		for (int y = 0; y < 3; y++) {
			for (int x = 0; x < 3; x++) {
				if (x >= recipe.method_8150() || y >= recipe.method_8158() || i >= recipe.method_61693().size()) {
					list.add(EmiStack.EMPTY);
				} else {
                    // TODO: is this correct?
                    Optional<class_1856> ingredient = recipe.method_61693().get(i++);
                    if (ingredient.isPresent()) {
                        list.add(EmiIngredient.of(ingredient.get()));
                    } else {
                        list.add(EmiStack.EMPTY);
                    }
				}
			}
		}
		return list;
	}
}
