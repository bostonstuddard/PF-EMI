package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_9636;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;

public class EmiGrindstoneDisenchantingRecipe implements EmiRecipe {
	private static final class_2960 BACKGROUND = EmiPort.id("minecraft", "textures/gui/container/grindstone.png");
	private final int uniq = EmiUtil.RANDOM.nextInt();
	private final class_1792 tool;
	private final class_2960 id;

	public EmiGrindstoneDisenchantingRecipe(class_1792 tool, class_2960 id) {
		this.tool = tool;
		this.id = id;
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return VanillaEmiRecipeCategories.GRINDING;
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@Override
	public List<EmiIngredient> getInputs() {
		return List.of(EmiStack.of(tool));
	}

	@Override
	public List<EmiStack> getOutputs() {
		return List.of(EmiStack.of(tool));
	}

	@Override
	public boolean supportsRecipeTree() {
		return false;
	}

	@Override
	public int getDisplayWidth() {
		return 116;
	}

	@Override
	public int getDisplayHeight() {
		return 56;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		widgets.addTexture(BACKGROUND, 0, 0, 116, 56, 30, 15);

		widgets.addGeneratedSlot(r -> getTool(r, true), uniq, 18, 3).drawBack(false);
		widgets.addGeneratedSlot(r -> getTool(r, false), uniq, 98, 18).drawBack(false).recipeContext(this);
	}

	private EmiStack getTool(Random random, Boolean enchanted){
		class_1799 itemStack = new class_1799(tool);
		int enchantments = 1 + Math.max(random.nextInt(5), random.nextInt(3));

		List<class_1887> list = Lists.newArrayList();

		outer:
		for (int i = 0; i < enchantments; i++) {
			class_1887 enchantment = getEnchantment(random);

			int maxLvl = enchantment.method_8183();
			int minLvl = enchantment.method_8187();
			// Some enchantments are returning zero for max level? I don't want to think about it
			int lvl = maxLvl > 0 ? random.nextInt(maxLvl) + 1 : 0;

			if (lvl < minLvl) {
				lvl = minLvl;
			}
			
			for (class_1887 e : list) {
				if (e == enchantment || !class_1887.method_60033(EmiPort.getEnchantmentRegistry().method_47983(e), EmiPort.getEnchantmentRegistry().method_47983(enchantment))) {
					continue outer;
				}
			}
			list.add(enchantment);

			if (EmiPort.getEnchantmentRegistry().method_47983(enchantment).method_40220(class_9636.field_51551)) {
				itemStack.method_7978(EmiPort.getEnchantmentRegistry().method_47983(enchantment), lvl);
			} else if (enchanted) {
				itemStack.method_7978(EmiPort.getEnchantmentRegistry().method_47983(enchantment), lvl);
			}
		}
		return EmiStack.of(itemStack);
	}

	private class_1887 getEnchantment(Random random){
		List<class_1887> enchantments = EmiPort.getEnchantmentRegistry().method_10220().filter(i -> i.method_8192(tool.method_7854())).toList();
		int enchantment = random.nextInt(enchantments.size());
		return enchantments.get(enchantment);
	}
}
