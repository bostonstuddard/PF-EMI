package dev.emi.emi.recipe;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.VanillaPlugin;
import dev.emi.emi.api.recipe.EmiIngredientRecipe;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.EmiResolutionRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.TagEmiIngredient;

public class EmiTagRecipe extends EmiIngredientRecipe {
	private final List<EmiStack> stacks;
	private final EmiIngredient ingredient;
	public final class_6862<?> key;

	public EmiTagRecipe(class_6862<?> key) {
		this.key = key;
		this.ingredient = new TagEmiIngredient(key, 1);
		this.stacks = ingredient.getEmiStacks();
	}

	@Override
	protected EmiIngredient getIngredient() {
		return ingredient;
	}

	@Override
	protected List<EmiStack> getStacks() {
		return stacks;
	}

	@Override
	protected EmiRecipe getRecipeContext(EmiStack stack, int offset) {
		return new EmiResolutionRecipe(ingredient, stack);
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return VanillaPlugin.TAG;
	}

	@Override
	public class_2960 getId() {
		return EmiPort.id("emi", "/tag/" + key.comp_326().method_29177().method_12832() + "/" + EmiUtil.subId(key.comp_327()));
	}
}
