package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9283;
import net.minecraft.class_9334;
import com.google.common.collect.Lists;

import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.ints.IntLists;

public class EmiFireworkStarFadeRecipe extends EmiPatternCraftingRecipe {
	private static final List<class_1769> DYES = Stream.of(class_1767.values()).map(class_1769::method_7803).toList();

	public EmiFireworkStarFadeRecipe(class_2960 id) {
		super(List.of(
			EmiIngredient.of(DYES.stream().map(i -> (EmiIngredient) EmiStack.of(i)).collect(Collectors.toList())),
			EmiStack.of(class_1802.field_8450)), EmiStack.of(class_1802.field_8450), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		return new GeneratedSlotWidget(r -> {
			EmiStack fireworkStar = getFireworkStar(r, false);
			List<class_1769> dyeItems = getDyes(r, 8);
			final int s = slot - 1;
			if (slot == 0) {
				return fireworkStar;
			}
			if (s < dyeItems.size()) {
				return EmiStack.of(dyeItems.get(s));
			}
			return EmiStack.EMPTY;
		}, unique, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> getFireworkStar(r, true), unique, x, y);
	}

	private List<class_1769> getDyes(Random random, int max) {
		List<class_1769> dyes = Lists.newArrayList();
		int amount = 1 + random.nextInt(max);
		for (int i = 0; i < amount; i++) {
			dyes.add(DYES.get(random.nextInt(DYES.size())));
		}
		return dyes;
	}

	private EmiStack getFireworkStar(Random random, Boolean faded) {
		class_1799 stack = new class_1799(class_1802.field_8450);
		int items = 0;

		int amount = random.nextInt(5);

		class_9283.class_1782 type = class_9283.class_1782.values()[random.nextInt(class_9283.class_1782.values().length)];

		if (!(amount == 0)) {
			items++;
		}

		amount = random.nextInt(4);

		boolean flicker = false, trail = false;

		if (amount == 0) {
			flicker = true;
			items++;
		} else if (amount == 1) {
			trail = true;
			items++;
		} else if (amount == 2){
			flicker = true;
			trail = true;
			items = items + 2;
		}

		List<class_1769> dyeItems = getDyes(random, 8 - items);
		IntList colors = new IntArrayList();
		for (class_1769 dyeItem : dyeItems) {
			colors.add(dyeItem.method_7802().method_7790());
		}

		IntList fadedColors;

		if (faded) {
			List<class_1769> dyeItemsFaded = getDyes(random, 8);
			fadedColors = new IntArrayList();
			for (class_1769 dyeItem : dyeItemsFaded) {
				fadedColors.add(dyeItem.method_7802().method_7790());
			}
		} else {
			fadedColors = IntLists.emptyList();
		}

		class_9283 component = new class_9283(type, colors, fadedColors, trail, flicker);

		stack.method_57379(class_9334.field_49615, component);
		return EmiStack.of(stack);
	}
}
