package dev.emi.emi.recipe.special;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;

public class EmiAnvilEnchantRecipe implements EmiRecipe {
	private final class_1792 tool;
	private final class_1887 enchantment;
	private final int level;
	private final class_2960 id;

	public EmiAnvilEnchantRecipe(class_1792 tool, class_1887 enchantment, int level, class_2960 id) {
		this.tool = tool;
		this.enchantment = enchantment;
		this.level = level;
		this.id = id;
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return VanillaEmiRecipeCategories.ANVIL_REPAIRING;
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@Override
	public List<EmiIngredient> getInputs() {
		return List.of(EmiStack.of(tool), getBook());
	}

	@Override
	public List<EmiStack> getOutputs() {
		return List.of(EmiStack.of(tool));
	}

	@Override
	public boolean supportsRecipeTree() {
		return false;
	}

	@Override
	public int getDisplayWidth() {
		return 125;
	}

	@Override
	public int getDisplayHeight() {
		return 18;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		widgets.addTexture(EmiTexture.PLUS, 27, 3);
		widgets.addTexture(EmiTexture.EMPTY_ARROW, 75, 1);
		widgets.addSlot(EmiStack.of(tool), 0, 0);
		widgets.addSlot(getBook(), 49, 0);
		widgets.addSlot(EmiStack.of(getTool()), 107, 0).recipeContext(this);
	}

	private class_1799 getTool() {
		class_1799 itemStack = tool.method_7854();
		itemStack.method_7978(EmiPort.getEnchantmentRegistry().method_47983(enchantment), level);
		return itemStack;
	}

	private EmiStack getBook() {
		class_1799 item = new class_1799(class_1802.field_8598);
		var enchBuilder = new class_9304.class_9305(class_9304.field_49385);
		enchBuilder.method_57550(EmiPort.getEnchantmentRegistry().method_47983(enchantment), level);
		item.method_57379(class_9334.field_49643, enchBuilder.method_57549());
		return EmiStack.of(item);
	}
}
