package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2356;
import net.minecraft.class_2960;
import net.minecraft.class_9334;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;

public class EmiSuspiciousStewRecipe extends EmiPatternCraftingRecipe {
	private static final List<class_1792> FLOWERS = EmiPort.getItemRegistry().method_10220()
		.filter(i -> i instanceof class_1747 bi && bi.method_7711() instanceof class_2356).collect(Collectors.toList());

	public EmiSuspiciousStewRecipe(class_2960 id) {
		super(List.of(
				EmiStack.of(class_1802.field_8428),
				EmiStack.of(class_1802.field_17517),
				EmiStack.of(class_1802.field_17516),
				EmiIngredient.of(FLOWERS.stream().map(i -> (EmiIngredient) EmiStack.of(i)).collect(Collectors.toList()))),
			EmiStack.of(class_1802.field_8766), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(EmiStack.of(class_1802.field_8428), x, y);
		} else if (slot == 1) {
			return new SlotWidget(EmiStack.of(class_1802.field_17517), x, y);
		} else if (slot == 2) {
			return new SlotWidget(EmiStack.of(class_1802.field_17516), x, y);
		} else if (slot == 3) {
			return new GeneratedSlotWidget(r -> EmiStack.of(getFlower(r)), unique, x, y);
		}
		return new SlotWidget(EmiStack.EMPTY, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> {
			class_2356 block = (class_2356) ((class_1747) getFlower(r)).method_7711();
			class_1799 stack = new class_1799(class_1802.field_8766);
			stack.method_57379(class_9334.field_49652, block.method_53233());
			return EmiStack.of(stack);
		}, unique, x, y);
	}
	
	private class_1792 getFlower(Random random) {
		return FLOWERS.get(random.nextInt(FLOWERS.size()));
	}
}
