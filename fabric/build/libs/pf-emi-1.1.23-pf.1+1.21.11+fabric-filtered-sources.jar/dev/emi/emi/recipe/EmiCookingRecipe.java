package dev.emi.emi.recipe;

import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_1874;
import net.minecraft.class_2960;
import net.minecraft.class_3612;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import dev.emi.emi.config.FluidUnit;

public class EmiCookingRecipe implements EmiRecipe {
	private final class_2960 id;
	private final EmiRecipeCategory category;
	private final EmiIngredient input;
	private final EmiStack output;
	private final class_1874 recipe;
	private final int fuelMultiplier;
	private final boolean infiniBurn;
	
	public EmiCookingRecipe(class_1874 recipe, EmiRecipeCategory category, int fuelMultiplier, boolean infiniBurn) {
		this.id = EmiPort.getId(recipe);
		this.category = category;
		input = EmiIngredient.of(recipe.method_64720());
		output = EmiStack.of(EmiPort.getOutput(recipe));
		if (input.getEmiStacks().get(0).getItemStack().method_31574(class_1802.field_8554)) {
			input.getEmiStacks().get(0).setRemainder(EmiStack.of(class_3612.field_15910, FluidUnit.BUCKET));
		}
		this.recipe = recipe;
		this.fuelMultiplier = fuelMultiplier;
		this.infiniBurn = infiniBurn;
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return category;
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@Override
	public List<EmiIngredient> getInputs() {
		return List.of(input);
	}

	@Override
	public List<EmiStack> getOutputs() {
		return List.of(output);
	}

	@Override
	public int getDisplayWidth() {
		return 82;
	}

	@Override
	public int getDisplayHeight() {
		return 38;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		widgets.addFillingArrow(24, 5, 50 * recipe.method_8167()).tooltip((mx, my) -> {
			return List.of(class_5684.method_32662(EmiPort.ordered(EmiPort.translatable("emi.cooking.time", recipe.method_8167() / 20f))));
		});
		if (infiniBurn) {
			widgets.addTexture(EmiTexture.FULL_FLAME, 1, 24);
		} else {
			widgets.addTexture(EmiTexture.EMPTY_FLAME, 1, 24);
			widgets.addAnimatedTexture(EmiTexture.FULL_FLAME, 1, 24, 4000 / fuelMultiplier, false, true, true);
		}
		widgets.addText(EmiPort.ordered(EmiPort.translatable("emi.cooking.experience", recipe.method_8171())), 26, 28, -1, true);
		widgets.addSlot(input, 0, 4);
		widgets.addSlot(output, 56, 0).large(true).recipeContext(this);
	}
}
