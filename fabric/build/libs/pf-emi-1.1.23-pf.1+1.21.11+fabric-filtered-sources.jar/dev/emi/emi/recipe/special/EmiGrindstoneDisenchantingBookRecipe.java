package dev.emi.emi.recipe.special;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import dev.emi.emi.api.widget.TextWidget.Alignment;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5481;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class EmiGrindstoneDisenchantingBookRecipe implements EmiRecipe {
	private static final class_2960 BACKGROUND = EmiPort.id("minecraft", "textures/gui/container/grindstone.png");
	private final class_1887 enchantment;
	private final int level;
	private final class_2960 id;

	public EmiGrindstoneDisenchantingBookRecipe(class_1887 enchantment, int level, class_2960 id) {
		this.enchantment = enchantment;
		this.level = level;
		this.id = id;
	}

	@Override
	public EmiRecipeCategory getCategory() {
		return VanillaEmiRecipeCategories.GRINDING;
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@Override
	public List<EmiIngredient> getInputs() {
		return List.of(getBook());
	}

	@Override
	public List<EmiStack> getOutputs() {
		return List.of(EmiStack.of(class_1802.field_8529));
	}

	@Override
	public boolean supportsRecipeTree() {
		return false;
	}

	@Override
	public int getDisplayWidth() {
		return 116;
	}

	@Override
	public int getDisplayHeight() {
		return 56;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		widgets.addTexture(BACKGROUND, 0, 0, 116, 56, 30, 15);

		widgets.addText(getExp(), 114, 39, -1, true).horizontalAlign(Alignment.END);
		widgets.addSlot(getBook(), 18, 3).drawBack(false);
		widgets.addSlot(EmiStack.of(class_1802.field_8529), 98, 18).drawBack(false).recipeContext(this);
	}

	private EmiStack getBook() {
		class_1799 book = new class_1799(class_1802.field_8598);

		var enchBuilder = new class_9304.class_9305(class_9304.field_49385);
		enchBuilder.method_57550(EmiPort.getEnchantmentRegistry().method_47983(enchantment), level);
		book.method_57379(class_9334.field_49643, enchBuilder.method_57549());

		return EmiStack.of(book);
	}

	private class_5481 getExp(){
		int minPower = enchantment.method_8182(level);
		int minXP = (int)Math.ceil((double)minPower / 2.0);
		int maxXP = 2 * minXP - 1;
		return EmiPort.ordered(EmiPort.translatable("emi.grinding.experience", minXP, maxXP));
	}
}
