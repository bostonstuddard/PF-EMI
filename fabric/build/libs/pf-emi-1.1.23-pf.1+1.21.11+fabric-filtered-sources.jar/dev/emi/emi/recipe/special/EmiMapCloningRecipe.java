package dev.emi.emi.recipe.special;

import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;

public class EmiMapCloningRecipe extends EmiPatternCraftingRecipe {

	public EmiMapCloningRecipe(class_2960 id) {
		super(List.of(
						EmiStack.of(class_1802.field_8204),
						EmiStack.of(class_1802.field_8895)),
				EmiStack.of(class_1802.field_8204), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(EmiStack.of(class_1802.field_8204), x, y);
		} else {
			final int s = slot - 1;
			return new GeneratedSlotWidget(r -> {
				int amount = r.nextInt(8) + 1;
				if (s < amount) {
					return EmiStack.of(class_1802.field_8895);
				}
				return EmiStack.EMPTY;
			}, unique, x, y);
		}
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> EmiStack.of(class_1802.field_8204, r.nextInt(8) + 2), unique, x, y);
	}

	public EmiStack getAmount(Random random, class_1792 item) {
		return EmiStack.of(item);
	}
}
