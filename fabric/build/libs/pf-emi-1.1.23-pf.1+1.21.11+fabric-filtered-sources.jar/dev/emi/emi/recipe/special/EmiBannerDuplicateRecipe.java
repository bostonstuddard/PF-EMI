package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9307;
import net.minecraft.class_9334;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;

public class EmiBannerDuplicateRecipe extends EmiPatternCraftingRecipe {

	public static final List<class_1792> BANNERS = List.of(
			class_1802.field_8539, class_1802.field_8824, class_1802.field_8671, class_1802.field_8379,
			class_1802.field_8049, class_1802.field_8778, class_1802.field_8329, class_1802.field_8617,
			class_1802.field_8855, class_1802.field_8629, class_1802.field_8405, class_1802.field_8128,
			class_1802.field_8124, class_1802.field_8295, class_1802.field_8586, class_1802.field_8572
	);

	private final class_1792 banner;

	public EmiBannerDuplicateRecipe(class_1792 banner, class_2960 id) {
		super(List.of(
				EmiStack.of(banner),
				EmiStack.of(banner).setRemainder(EmiStack.of(banner))),
				EmiStack.of(banner), id);
		this.banner = banner;
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(EmiStack.of(banner), x, y);
		} else if (slot == 1) {
			return new GeneratedSlotWidget(r -> getPattern(r, true), unique, x, y);
		}
		return new SlotWidget(EmiStack.EMPTY, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> getPattern(r, false) , unique, x, y);
	}

	public EmiStack getPattern(Random random, boolean reminder) {
		class_1799 stack = new class_1799(banner);
		int patterns = 1 + Math.max(random.nextInt(5), random.nextInt(3));
		class_9307 pattern = class_9307.field_49404;
		for (int i = 0; i < patterns; i++) {
			pattern = EmiPort.addRandomBanner(pattern, random);
		}

		stack.method_57379(class_9334.field_49619, pattern);

		EmiStack emiStack = EmiStack.of(stack);
		if (reminder) {
			emiStack.setRemainder(EmiStack.of(stack));
		}
		return emiStack;
	}
}
