package dev.emi.emi.recipe;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import net.minecraft.class_10223;

public class EmiTransmuteRecipe extends EmiCraftingRecipe {

    public EmiTransmuteRecipe(class_10223 recipe) {
        super(recipe.method_61671().method_64675().stream().map(EmiIngredient::of).toList(),
                EmiStack.of(EmiPort.getOutput(recipe)), EmiPort.getId(recipe));
        EmiShapedRecipe.setRemainders(input, recipe);
    }

    @Override
    public boolean canFit(int width, int height) {
        return input.size() <= width * height;
    }
}
