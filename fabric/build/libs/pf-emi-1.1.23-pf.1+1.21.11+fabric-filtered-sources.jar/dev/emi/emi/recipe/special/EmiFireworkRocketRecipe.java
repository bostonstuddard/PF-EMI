package dev.emi.emi.recipe.special;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9283;
import net.minecraft.class_9284;
import net.minecraft.class_9334;
import com.google.common.collect.Lists;

import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.ints.IntLists;


public class EmiFireworkRocketRecipe extends EmiPatternCraftingRecipe {
	private static final List<class_1769> DYES = Stream.of(class_1767.values()).map(class_1769::method_7803).toList();

	public EmiFireworkRocketRecipe(class_2960 id) {
		super(List.of(
				EmiStack.of(class_1802.field_8407),
						EmiStack.of(class_1802.field_8450),
						EmiStack.of(class_1802.field_8054)),
				EmiStack.of(class_1802.field_8639), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(EmiStack.of(class_1802.field_8407), x, y);
		} else {
			final int s = slot - 1;
			return new GeneratedSlotWidget(r -> {
				List<EmiStack> items = getItems(r);
				if (s < items.size()) {
					return items.get(s);
				}
				return EmiStack.EMPTY;
			}, unique, x, y);
		}
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(this::getFireworkRocket, unique, x, y);
	}

	private EmiStack getFireworkRocket(Random random) {
		class_1799 stack = new class_1799(class_1802.field_8639);
		List<class_9283> explosions = new ArrayList<>();

		List<EmiStack> items = getItems(random);
		int gunpowder = 0;
		for (EmiStack item : items) {
			if (item.getId() == EmiStack.of(class_1802.field_8450).getId()){
				explosions.add(item.getOrDefault(class_9334.field_49615, class_9283.field_49315));
			} else if (item.isEqual(EmiStack.of(class_1802.field_8054))) {
				gunpowder++;
			}
		}

		stack.method_57379(class_9334.field_49616, new class_9284(gunpowder, explosions));
		return EmiStack.of(stack, 3);
	}

	private List<EmiStack> getItems(Random random) {
		List<EmiStack> items = Lists.newArrayList();
		int amount = random.nextInt(3);
		for(int i= 0; i<= amount; i++) {
			items.add(EmiStack.of(class_1802.field_8054));
		}
		amount = random.nextInt(8-items.size());
		for(int i= 0; i<= amount; i++) {
			items.add(getFireworkStar(random));
		}

		return items;
	}

	private List<class_1769> getDyes(Random random, int max) {
		List<class_1769> dyes = Lists.newArrayList();
		int amount = 1 + random.nextInt(max);
		for (int i = 0; i < amount; i++) {
			dyes.add(DYES.get(random.nextInt(DYES.size())));
		}
		return dyes;
	}

	private EmiStack getFireworkStar(Random random) {
		class_1799 stack = new class_1799(class_1802.field_8450);
		int items = 0;

		int amount = random.nextInt(5);

		class_9283.class_1782 type = class_9283.class_1782.values()[random.nextInt(class_9283.class_1782.values().length)];

		if (!(amount == 0)) {
			items++;
		}

		amount = random.nextInt(4);

		boolean flicker = false, trail = false;

		if (amount == 0) {
			flicker = true;
			items++;
		} else if (amount == 1) {
			trail = true;
			items++;
		} else if (amount == 2){
			flicker = true;
			trail = true;
			items = items + 2;
		}

		List<class_1769> dyeItems = getDyes(random, 8 - items);
		IntList colors = new IntArrayList();
		for (class_1769 dyeItem : dyeItems) {
			colors.add(dyeItem.method_7802().method_7790());
		}

		amount = random.nextInt(2);

		IntList fadedColors;

		if (amount == 1) {
			List<class_1769> dyeItemsFaded = getDyes(random, 8);
			fadedColors = new IntArrayList();
			for (class_1769 dyeItem : dyeItemsFaded) {
				fadedColors.add(dyeItem.method_7802().method_7790());
			}
		} else {
			fadedColors = IntLists.emptyList();
		}

		class_9283 component = new class_9283(type, colors, fadedColors, trail, flicker);

		stack.method_57379(class_9334.field_49615, component);
		return EmiStack.of(stack);
	}
}
