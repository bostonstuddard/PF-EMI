package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9334;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;

public class EmiRepairItemRecipe extends EmiPatternCraftingRecipe {
	public static final List<class_1792> TOOLS = EmiPort.getItemRegistry().method_10220()
			.filter(i -> i.method_57347().method_58695(class_9334.field_50072, 0) > 0).collect(Collectors.toList());
	private final class_1792 tool;

	public EmiRepairItemRecipe(class_1792 tool, class_2960 id) {
		super(List.of(
				EmiStack.of(tool),
				EmiStack.of(tool)),
				EmiStack.of(tool), id);
		this.tool = tool;
	}
	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		return new GeneratedSlotWidget(r -> {
			List<class_1799> items = getItems(r);
			if (slot < 2) {
				return EmiStack.of(items.get(slot));
			}
			return EmiStack.EMPTY;

		}, unique, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> EmiStack.of(getMergeItems(r)), unique, x, y);
	}

	private List<class_1799> getItems(Random random) {
		List<class_1799> items = Lists.newArrayList();
		items.add(getTool(random));
		items.add(getTool(random));
		return items;
	}

	private class_1799 getMergeItems(Random random) {
		List<class_1799> items = getItems(random);
		class_1799 item = tool.method_7854();
		int maxDamage = item.method_7936();
		int damage = items.get(0).method_7919() - (21 * maxDamage)/20 + items.get(1).method_7919();
		if (damage > 0) {
			item.method_7974(damage);
		}
		return item;
	}

	private class_1799 getTool(Random r) {
		class_1799 stack = tool.method_7854();
		if (stack.method_7936() <= 0) {
			return stack;
		}
		int d = r.nextInt(stack.method_7936());
		stack.method_7974(d);
		return stack;
	}
}
