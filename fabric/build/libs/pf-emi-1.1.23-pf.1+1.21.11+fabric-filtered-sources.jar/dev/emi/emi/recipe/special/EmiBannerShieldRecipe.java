package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_9307;
import net.minecraft.class_9334;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;

public class EmiBannerShieldRecipe extends EmiPatternCraftingRecipe {
	public static final List<class_1792> BANNERS = List.of(
		class_1802.field_8539, class_1802.field_8824, class_1802.field_8671, class_1802.field_8379,
		class_1802.field_8049, class_1802.field_8778, class_1802.field_8329, class_1802.field_8617,
		class_1802.field_8855, class_1802.field_8629, class_1802.field_8405, class_1802.field_8128,
		class_1802.field_8124, class_1802.field_8295, class_1802.field_8586, class_1802.field_8572
	);
	private static final List<EmiStack> EMI_BANNERS = BANNERS.stream().map(i -> EmiStack.of(i)).collect(Collectors.toList());
	public static final EmiStack SHIELD = EmiStack.of(class_1802.field_8255);

	@SuppressWarnings("unchecked")
	public EmiBannerShieldRecipe(class_2960 id) {
		super((List<EmiIngredient>) (List<?>) Stream.concat(Stream.of(SHIELD), EMI_BANNERS.stream()).toList(), EmiStack.of(class_1802.field_8255), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(SHIELD, x, y);
		} else if (slot == 1) {
			return new GeneratedSlotWidget(r -> getPattern(r, null), unique, x, y);
		}
		return new SlotWidget(EmiStack.EMPTY, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> getPattern(r, class_1802.field_8255), unique, x, y);
	}
	
	public EmiStack getPattern(Random random, class_1792 item) {
		int base = random.nextInt(BANNERS.size());
		if (item == null) {
			item = BANNERS.get(base);
		}
		class_1799 stack = new class_1799(item);
		int patterns = 1 + Math.max(random.nextInt(5), random.nextInt(3));
		class_9307 pattern = class_9307.field_49404;
		for (int i = 0; i < patterns; i++) {
			pattern = EmiPort.addRandomBanner(pattern, random);
		}

		stack.method_57379(class_9334.field_49619, pattern);

		return EmiStack.of(stack);
	}
}
