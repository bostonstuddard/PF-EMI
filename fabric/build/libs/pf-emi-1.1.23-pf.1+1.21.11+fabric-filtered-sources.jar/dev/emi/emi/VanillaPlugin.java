package dev.emi.emi;

import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.ANVIL_REPAIRING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.BLASTING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.BREWING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.CAMPFIRE_COOKING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.COMPOSTING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.CRAFTING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.FUEL;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.GRINDING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.INFO;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.SMELTING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.SMITHING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.SMOKING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.STONECUTTING;
import static dev.emi.emi.api.recipe.VanillaEmiRecipeCategories.WORLD_INTERACTION;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_10223;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1847;
import net.minecraft.class_1848;
import net.minecraft.class_1849;
import net.minecraft.class_1850;
import net.minecraft.class_1851;
import net.minecraft.class_1853;
import net.minecraft.class_1854;
import net.minecraft.class_1855;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1861;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_1872;
import net.minecraft.class_1876;
import net.minecraft.class_1887;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2521;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3705;
import net.minecraft.class_3706;
import net.minecraft.class_3858;
import net.minecraft.class_3859;
import net.minecraft.class_3861;
import net.minecraft.class_3862;
import net.minecraft.class_3917;
import net.minecraft.class_3920;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3962;
import net.minecraft.class_3975;
import net.minecraft.class_4317;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_8059;
import net.minecraft.class_8786;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import net.minecraft.class_9636;
import net.minecraft.class_9695;
import net.minecraft.class_9890;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mojang.datafixers.util.Pair;

import dev.emi.emi.api.EmiEntrypoint;
import dev.emi.emi.api.EmiInitRegistry;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiCraftingRecipe;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.EmiRecipeSorting;
import dev.emi.emi.api.recipe.EmiWorldInteractionRecipe;
import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.Comparison;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiRegistryAdapter;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.FluidEmiStack;
import dev.emi.emi.api.stack.ItemEmiStack;
import dev.emi.emi.api.stack.ListEmiIngredient;
import dev.emi.emi.api.stack.TagEmiIngredient;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.config.EffectLocation;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.FluidUnit;
import dev.emi.emi.handler.CookingRecipeHandler;
import dev.emi.emi.handler.CraftingRecipeHandler;
import dev.emi.emi.handler.InventoryRecipeHandler;
import dev.emi.emi.handler.StonecuttingRecipeHandler;
import dev.emi.emi.mixin.accessor.AxeItemAccessor;
import dev.emi.emi.mixin.accessor.HandledScreenAccessor;
import dev.emi.emi.mixin.accessor.HoeItemAccessor;
import dev.emi.emi.mixin.accessor.ShovelItemAccessor;
import dev.emi.emi.mixin.accessor.SmithingTransformRecipeAccessor;
import dev.emi.emi.mixin.accessor.SmithingTrimRecipeAccessor;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.platform.EmiClient;
import dev.emi.emi.recipe.EmiAnvilRecipe;
import dev.emi.emi.recipe.EmiCompostingRecipe;
import dev.emi.emi.recipe.EmiCookingRecipe;
import dev.emi.emi.recipe.EmiFuelRecipe;
import dev.emi.emi.recipe.EmiGrindstoneRecipe;
import dev.emi.emi.recipe.EmiShapedRecipe;
import dev.emi.emi.recipe.EmiShapelessRecipe;
import dev.emi.emi.recipe.EmiSmithingRecipe;
import dev.emi.emi.recipe.EmiStonecuttingRecipe;
import dev.emi.emi.recipe.EmiTagRecipe;
import dev.emi.emi.recipe.EmiTransmuteRecipe;
import dev.emi.emi.recipe.special.EmiAnvilEnchantRecipe;
import dev.emi.emi.recipe.special.EmiAnvilRepairItemRecipe;
import dev.emi.emi.recipe.special.EmiArmorDyeRecipe;
import dev.emi.emi.recipe.special.EmiBannerDuplicateRecipe;
import dev.emi.emi.recipe.special.EmiBannerShieldRecipe;
import dev.emi.emi.recipe.special.EmiBookCloningRecipe;
import dev.emi.emi.recipe.special.EmiFireworkRocketRecipe;
import dev.emi.emi.recipe.special.EmiFireworkStarFadeRecipe;
import dev.emi.emi.recipe.special.EmiFireworkStarRecipe;
import dev.emi.emi.recipe.special.EmiGrindstoneDisenchantingBookRecipe;
import dev.emi.emi.recipe.special.EmiGrindstoneDisenchantingRecipe;
import dev.emi.emi.recipe.special.EmiMapCloningRecipe;
import dev.emi.emi.recipe.special.EmiRepairItemRecipe;
import dev.emi.emi.recipe.special.EmiSmithingTrimRecipe;
import dev.emi.emi.registry.EmiTags;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.runtime.EmiReloadLog;
import dev.emi.emi.runtime.EmiTagKey;
import dev.emi.emi.stack.serializer.FluidEmiStackSerializer;
import dev.emi.emi.stack.serializer.ItemEmiStackSerializer;
import dev.emi.emi.stack.serializer.ListEmiIngredientSerializer;
import dev.emi.emi.stack.serializer.TagEmiIngredientSerializer;

@EmiEntrypoint
public class VanillaPlugin implements EmiPlugin {
	public static EmiRecipeCategory TAG = new EmiRecipeCategory(EmiPort.id("emi:tag"),
		EmiStack.of(class_1802.field_8448), simplifiedRenderer(240, 208), EmiRecipeSorting.none());
	
	public static EmiRecipeCategory INGREDIENT = new EmiRecipeCategory(EmiPort.id("emi:ingredient"),
		EmiStack.of(class_1802.field_8251), simplifiedRenderer(240, 208));
	public static EmiRecipeCategory RESOLUTION = new EmiRecipeCategory(EmiPort.id("emi:resolution"),
		EmiStack.of(class_1802.field_8251), simplifiedRenderer(240, 208));

	static {
		CRAFTING = new EmiRecipeCategory(EmiPort.id("minecraft:crafting"),
			EmiStack.of(class_1802.field_8465), simplifiedRenderer(240, 240), EmiRecipeSorting.compareOutputThenInput());
		SMELTING = new EmiRecipeCategory(EmiPort.id("minecraft:smelting"),
			EmiStack.of(class_1802.field_8732), simplifiedRenderer(224, 240), EmiRecipeSorting.compareOutputThenInput());
		BLASTING = new EmiRecipeCategory(EmiPort.id("minecraft:blasting"),
			EmiStack.of(class_1802.field_16306), simplifiedRenderer(208, 240), EmiRecipeSorting.compareOutputThenInput());
		SMOKING = new EmiRecipeCategory(EmiPort.id("minecraft:smoking"),
			EmiStack.of(class_1802.field_16309), simplifiedRenderer(192, 240), EmiRecipeSorting.compareOutputThenInput());
		CAMPFIRE_COOKING = new EmiRecipeCategory(EmiPort.id("minecraft:campfire_cooking"),
			EmiStack.of(class_1802.field_17346), simplifiedRenderer(176, 240), EmiRecipeSorting.compareOutputThenInput());
		STONECUTTING = new EmiRecipeCategory(EmiPort.id("minecraft:stonecutting"),
			EmiStack.of(class_1802.field_16305), simplifiedRenderer(160, 240), EmiRecipeSorting.compareInputThenOutput());
		SMITHING = new EmiRecipeCategory(EmiPort.id("minecraft:smithing"),
			EmiStack.of(class_1802.field_16308), simplifiedRenderer(240, 224), EmiRecipeSorting.compareInputThenOutput());
		ANVIL_REPAIRING = new EmiRecipeCategory(EmiPort.id("emi:anvil_repairing"),
			EmiStack.of(class_1802.field_8782), simplifiedRenderer(240, 224), EmiRecipeSorting.none());
		GRINDING = new EmiRecipeCategory(EmiPort.id("emi:grinding"),
			EmiStack.of(class_1802.field_16311), simplifiedRenderer(192, 224), EmiRecipeSorting.none());
		BREWING = new EmiRecipeCategory(EmiPort.id("minecraft:brewing"),
			EmiStack.of(class_1802.field_8740), simplifiedRenderer(224, 224), EmiRecipeSorting.none());
		WORLD_INTERACTION = new EmiRecipeCategory(EmiPort.id("emi:world_interaction"),
			EmiStack.of(class_1802.field_8270), simplifiedRenderer(208, 224), EmiRecipeSorting.none());
		EmiRenderable flame = (matrices, x, y, delta) -> {
			EmiTexture.FULL_FLAME.render(matrices, x + 1, y + 1, delta);
		};
		FUEL = new EmiRecipeCategory(EmiPort.id("emi:fuel"), flame, flame, EmiRecipeSorting.compareInputThenOutput());
		COMPOSTING = new EmiRecipeCategory(EmiPort.id("emi:composting"), EmiStack.of(class_1802.field_17530),
			EmiStack.of(class_1802.field_17530), EmiRecipeSorting.compareInputThenOutput());
		INFO = new EmiRecipeCategory(EmiPort.id("emi:info"),
			EmiStack.of(class_1802.field_8674), simplifiedRenderer(208, 224), EmiRecipeSorting.none());
	}


	@Override
	public void initialize(EmiInitRegistry registry) {
		registry.addIngredientSerializer(ItemEmiStack.class, new ItemEmiStackSerializer());
		registry.addIngredientSerializer(FluidEmiStack.class, new FluidEmiStackSerializer());
		registry.addIngredientSerializer(TagEmiIngredient.class, new TagEmiIngredientSerializer());
		registry.addIngredientSerializer(ListEmiIngredient.class, new ListEmiIngredientSerializer());

		registry.addRegistryAdapter(EmiRegistryAdapter.simple(class_1792.class, EmiPort.getItemRegistry(), EmiStack::of));
		registry.addRegistryAdapter(EmiRegistryAdapter.simple(class_3611.class, EmiPort.getFluidRegistry(), EmiStack::of));
	}

	@Override
	public void register(EmiRegistry registry) {
		registry.addCategory(CRAFTING);
		registry.addCategory(SMELTING);
		registry.addCategory(BLASTING);
		registry.addCategory(SMOKING);
		registry.addCategory(CAMPFIRE_COOKING);
		registry.addCategory(STONECUTTING);
		registry.addCategory(SMITHING);
		registry.addCategory(ANVIL_REPAIRING);
		registry.addCategory(GRINDING);
		registry.addCategory(BREWING);
		registry.addCategory(WORLD_INTERACTION);
		registry.addCategory(FUEL);
		registry.addCategory(COMPOSTING);
		registry.addCategory(INFO);
		registry.addCategory(TAG);
		registry.addCategory(INGREDIENT);
		registry.addCategory(RESOLUTION);

		registry.addWorkstation(CRAFTING, EmiStack.of(class_1802.field_8465));
		registry.addWorkstation(SMELTING, EmiStack.of(class_1802.field_8732));
		registry.addWorkstation(BLASTING, EmiStack.of(class_1802.field_16306));
		registry.addWorkstation(SMOKING, EmiStack.of(class_1802.field_16309));
		registry.addWorkstation(CAMPFIRE_COOKING, EmiStack.of(class_1802.field_17346));
		registry.addWorkstation(CAMPFIRE_COOKING, EmiStack.of(class_1802.field_23842));
		registry.addWorkstation(STONECUTTING, EmiStack.of(class_1802.field_16305));
		registry.addWorkstation(SMITHING, EmiStack.of(class_1802.field_16308));
		registry.addWorkstation(ANVIL_REPAIRING, EmiStack.of(class_1802.field_8782));
		registry.addWorkstation(ANVIL_REPAIRING, EmiStack.of(class_1802.field_8750));
		registry.addWorkstation(ANVIL_REPAIRING, EmiStack.of(class_1802.field_8427));
		registry.addWorkstation(BREWING, EmiStack.of(class_1802.field_8740));
		registry.addWorkstation(GRINDING, EmiStack.of(class_1802.field_16311));
		registry.addWorkstation(COMPOSTING, EmiStack.of(class_1802.field_17530));

		registry.addRecipeHandler(null, new InventoryRecipeHandler());
		registry.addRecipeHandler(class_3917.field_17333, new CraftingRecipeHandler());
		registry.addRecipeHandler(class_3917.field_17335, new CookingRecipeHandler<class_3858>(SMELTING));
		registry.addRecipeHandler(class_3917.field_17331, new CookingRecipeHandler<class_3705>(BLASTING));
		registry.addRecipeHandler(class_3917.field_17342, new CookingRecipeHandler<class_3706>(SMOKING));
		registry.addRecipeHandler(class_3917.field_17625, new StonecuttingRecipeHandler());

		registry.addExclusionArea(class_481.class, (screen, consumer) -> {
			int left = ((HandledScreenAccessor) screen).getX();
			int top = ((HandledScreenAccessor) screen).getY();
			int width = ((HandledScreenAccessor) screen).getBackgroundWidth();
			int bottom = top + ((HandledScreenAccessor) screen).getBackgroundHeight();
			consumer.accept(new Bounds(left, top - 28, width, 28));
			consumer.accept(new Bounds(left, bottom, width, 28));
		});

		registry.addGenericExclusionArea((screen, consumer) -> {
			if (EmiConfig.effectLocation != EffectLocation.HIDDEN && screen instanceof class_465<?> inv) {
				class_310 client = class_310.method_1551();
				Collection<class_1293> collection = client.field_1724.method_6026();
				if (!collection.isEmpty()) {
					int k = 33;
					if (collection.size() > 5) {
						k = 132 / (collection.size() - 1);
					}
					int right = ((HandledScreenAccessor) inv).getX() + ((HandledScreenAccessor) inv).getBackgroundWidth() + 2;
					int rightWidth = inv.field_22789 - right;
					if (rightWidth >= 32) {
						int top = ((HandledScreenAccessor) inv).getY();
						int height = (collection.size() - 1) * k + 32;
						int left, width;
						if (EmiConfig.effectLocation == EffectLocation.TOP) {
							int size = collection.size();
							top = ((HandledScreenAccessor) inv).getY() - 34;
							if (screen instanceof class_481) {
								top -= 28;
								if (EmiAgnos.isForge()) {
									top -= 22;
								}
							}
							int xOff = 34;
							if (size == 1) {
								xOff = 122;
							} else if (size > 5) {
								xOff = (((HandledScreenAccessor) inv).getBackgroundWidth() - 32) / (size - 1);
							}
							width = Math.max(122, (size - 1) * xOff + 32);
							left = ((HandledScreenAccessor) inv).getX() + (((HandledScreenAccessor) inv).getBackgroundWidth() - width) / 2;
							height = 32;
						} else {
							left = switch (EmiConfig.effectLocation) {
								case LEFT_COMPRESSED -> ((HandledScreenAccessor) inv).getX() - 2 - 32;
								case LEFT -> ((HandledScreenAccessor) inv).getX() - 2 - 120;
								default -> right;
							};
							width = switch (EmiConfig.effectLocation) {
								case LEFT, RIGHT -> 120;
								case LEFT_COMPRESSED, RIGHT_COMPRESSED -> 32;
								default -> 32;
							};
						}
						consumer.accept(new Bounds(left, top, width, height));
					}
				}
			}
		});

		Comparison potionComparison = Comparison.compareData(stack -> stack.get(class_9334.field_49651));

		registry.setDefaultComparison(class_1802.field_8574, potionComparison);
		registry.setDefaultComparison(class_1802.field_8436, potionComparison);
		registry.setDefaultComparison(class_1802.field_8150, potionComparison);
		registry.setDefaultComparison(class_1802.field_8087, potionComparison);
		registry.setDefaultComparison(class_1802.field_8598, EmiPort.compareStrict());

		Set<class_1792> hiddenItems = Stream.concat(
			EmiTagKey.of(EmiPort.getItemRegistry(), EmiTags.HIDDEN_FROM_RECIPE_VIEWERS).stream(),
			EmiPort.getDisabledItems()
		).collect(Collectors.toSet());

		List<class_1792> dyeableItems = EmiTagKey.of(class_3489.field_48803).getList();

		for (class_3955 recipe : getRecipes(registry, class_3956.field_17545)) {
			class_2960 id = EmiPort.getId(recipe);
			if (recipe instanceof class_1861 map) {
				EmiStack paper = EmiStack.of(class_1802.field_8407);
				addRecipeSafe(registry, () -> new EmiCraftingRecipe(List.of(
						paper, paper, paper, paper,
						EmiStack.of(class_1802.field_8204),
						paper, paper, paper, paper
				), 
						EmiStack.of(class_1802.field_8204),
						id, false), recipe);
			} else if (recipe instanceof class_1869 shaped && shaped.method_8150() <= 3 && shaped.method_8158() <= 3) {
				addRecipeSafe(registry, () -> new EmiShapedRecipe(shaped), recipe);
			} else if (recipe instanceof class_1867 shapeless) {
				addRecipeSafe(registry, () -> new EmiShapelessRecipe(shapeless), recipe);
			} else if (recipe instanceof class_10223 transmute) {
                addRecipeSafe(registry, () -> new EmiTransmuteRecipe(transmute), recipe);
            } else if (recipe instanceof class_1849 dye) {
				for (class_1792 i : dyeableItems) {
					if (!hiddenItems.contains(i)) {
						addRecipeSafe(registry, () -> new EmiArmorDyeRecipe(i, synthetic("crafting/dying", EmiUtil.subId(i))), recipe);
					}
				}
			}
            // These are no longer needed
            /* else if (recipe instanceof SuspiciousStewRecipe stew) {
				addRecipeSafe(registry, () -> new EmiSuspiciousStewRecipe(id), recipe);
			} else if (recipe instanceof ShulkerBoxColoringRecipe shulker) {
			// Shulker boxes are now using transmute recipes;
				for (DyeColor dye : DyeColor.values()) {
					DyeItem dyeItem = DyeItem.byColor(dye);
					Identifier sid = synthetic("crafting/shulker_box_dying", EmiUtil.subId(dyeItem));
					addRecipeSafe(registry, () -> new EmiCraftingRecipe(
						List.of(EmiStack.of(Items.SHULKER_BOX), EmiStack.of(dyeItem)),
						EmiStack.of(ShulkerBoxBlock.getItemStack(dye)), sid), recipe);
				}
			}*/ else if (recipe instanceof class_1872 shield) {
				addRecipeSafe(registry, () -> new EmiBannerShieldRecipe(id), recipe);
			} else if (recipe instanceof class_1850 book) {
				addRecipeSafe(registry, () -> new EmiBookCloningRecipe(id), recipe);
			} else if (recipe instanceof class_1876 tipped) {
				EmiPort.getPotionRegistry().method_42017().forEach(entry -> {
					EmiStack arrow = EmiStack.of(class_1802.field_8107);
					addRecipeSafe(registry, () -> new EmiCraftingRecipe(List.of(
							arrow, arrow, arrow, arrow,
							EmiStack.of(EmiPort.setPotion(new class_1799(class_1802.field_8150), entry.comp_349())),
							arrow, arrow, arrow, arrow
						),
						EmiStack.of(EmiPort.setPotion(new class_1799(class_1802.field_8087, 8), entry.comp_349())),
						synthetic("crafting/tipped_arrow", EmiUtil.subId(EmiPort.getPotionRegistry().method_10221(entry.comp_349()))),
						false), recipe);
				});
			} else if (recipe instanceof class_1853 star) {
				addRecipeSafe(registry, () -> new EmiFireworkStarRecipe(id), recipe);
			} else if (recipe instanceof class_1854 star) {
				addRecipeSafe(registry, () -> new EmiFireworkStarFadeRecipe(id), recipe);
			} else if (recipe instanceof class_1851 rocket) {
				addRecipeSafe(registry, () -> new EmiFireworkRocketRecipe(id), recipe);
			} else if (recipe instanceof class_1848 banner) {
				for (class_1792 i : EmiBannerDuplicateRecipe.BANNERS) {
					if (!hiddenItems.contains(i)) {
						addRecipeSafe(registry, () -> new EmiBannerDuplicateRecipe(i, synthetic("crafting/banner_copying", EmiUtil.subId(i))), recipe);
					}
				}
			} else if (recipe instanceof class_4317 tool) {
				for (class_1792 i : EmiRepairItemRecipe.TOOLS) {
					if (!hiddenItems.contains(i)) {
						addRecipeSafe(registry, () -> new EmiRepairItemRecipe(i, synthetic("crafting/repairing", EmiUtil.subId(i))), recipe);
					}
				}
			} else if (recipe instanceof class_1855 map) {
				addRecipeSafe(registry, () -> new EmiMapCloningRecipe(id), recipe);
			}/* else if (!(recipe instanceof SpecialCraftingRecipe)) {
				try {
					if (!recipe.getIngredients().isEmpty() && !EmiPort.getOutput(recipe).isEmpty() && recipe.fits(3, 3)) {
						boolean shapeless = recipe.fits(1, recipe.getIngredients().size()) && recipe.fits(recipe.getIngredients().size(), 1);
						List<EmiIngredient> input;
						if (shapeless) {
							input = recipe.getIngredients().stream().map(EmiIngredient::of).toList();
						} else {
							int width = recipe.fits(2, 3) ? recipe.fits(1, 3) ? 1 : 2 : 3;
							input = Lists.newArrayList();
							for (int i = 0; i < recipe.getIngredients().size(); i++) {
								input.add(EmiIngredient.of(recipe.getIngredients().get(i)));
								if ((i + 1) % width == 0) {
									for (int j = width; j < 3; j++) {
										input.add(EmiStack.EMPTY);
									}
								}
							}
						}
						EmiShapedRecipe.setRemainders(input, recipe);
						addRecipeSafe(registry, () -> new EmiCraftingRecipe(input, EmiStack.of(EmiPort.getOutput(recipe)), id, shapeless));
					}
				} catch (Exception e) {
					EmiReloadLog.warn("Exception when parsing vanilla crafting recipe " + id, e);
				}
			}*/
		}

		for (class_3861 recipe : getRecipes(registry, class_3956.field_17546)) {
			addRecipeSafe(registry, () -> new EmiCookingRecipe(recipe, SMELTING, 1, false), recipe);
		}
		for (class_3859 recipe : getRecipes(registry, class_3956.field_17547)) {
			addRecipeSafe(registry, () -> new EmiCookingRecipe(recipe, BLASTING, 2, false), recipe);
		}
		for (class_3862 recipe : getRecipes(registry, class_3956.field_17548)) {
			addRecipeSafe(registry, () -> new EmiCookingRecipe(recipe, SMOKING, 2, false), recipe);
		}
		for (class_3920 recipe : getRecipes(registry, class_3956.field_17549)) {
			addRecipeSafe(registry, () -> new EmiCookingRecipe(recipe, CAMPFIRE_COOKING, 1, true), recipe);
		}
		for (class_8059 recipe : getRecipes(registry, class_3956.field_25388)) {
			//addRecipeSafe(registry, () -> new EmiSmithingRecipe(recipe), recipe);
			if (recipe instanceof SmithingTransformRecipeAccessor stra) {
				addRecipeSafe(registry, () -> new EmiSmithingRecipe(EmiIngredient.of(stra.getTemplate().get()), EmiIngredient.of(stra.getBase()),
					EmiIngredient.of(stra.getAddition().get()), EmiStack.of(EmiPort.getOutput(recipe)), EmiPort.getId(recipe)), recipe);
			} else if (recipe instanceof SmithingTrimRecipeAccessor stra) {
				addRecipeSafe(registry, () -> new EmiSmithingTrimRecipe(EmiIngredient.of(stra.getTemplate()), EmiIngredient.of(stra.getBase()),
					EmiIngredient.of(stra.getAddition()), EmiStack.of(EmiPort.getOutput(recipe)), recipe), recipe);
			}
		}
		for (class_3975 recipe : getRecipes(registry, class_3956.field_17641)) {
			addRecipeSafe(registry, () -> new EmiStonecuttingRecipe(recipe), recipe);
		}

		safely("repair", () -> addRepair(registry, hiddenItems));
		safely("brewing", () -> EmiAgnos.addBrewingRecipes(registry));
		safely("world interaction", () -> addWorldInteraction(registry, hiddenItems, dyeableItems));
		safely("fuel", () -> addFuel(registry, hiddenItems));
		safely("composting", () -> addComposting(registry, hiddenItems));

		for (EmiTagKey<?> key : EmiTags.TAGS) {
			if (new TagEmiIngredient(key.raw(), 1).getEmiStacks().size() > 1) {
				addRecipeSafe(registry, () -> new EmiTagRecipe(key.raw()));
			}
		}
	}

	private static void addRepair(EmiRegistry registry, Set<class_1792> hiddenItems) {
		List<class_1887> targetedEnchantments = Lists.newArrayList();
		List<class_1887> universalEnchantments = Lists.newArrayList();
		for (class_1887 enchantment : EmiPort.getEnchantmentRegistry().method_10220().toList()) {
			try {
				if (enchantment.method_8192(class_1799.field_8037)) {
					universalEnchantments.add(enchantment);
					continue;
				}
			} catch (Throwable t) {
			}
			targetedEnchantments.add(enchantment);
		}
		for (class_1792 i : EmiPort.getItemRegistry()) {
			if (hiddenItems.contains(i)) {
				continue;
			}
			try {
                if (i.method_57347().method_58695(class_9334.field_50072, 0) > 0) {
                    class_9890 repairable = i.method_57347().method_58694(class_9334.field_53696);
                    if (repairable != null) {
                        for (class_6880<class_1792> entry : repairable.comp_2939()) {
                            class_1792 item = entry.comp_349();
                            class_2960 id = synthetic("anvil/repairing/material", EmiUtil.subId(i) + "/" + EmiUtil.subId(item));
                            addRecipeSafe(registry, () -> new EmiAnvilRecipe(EmiStack.of(i), EmiIngredient.of(class_1856.method_8101(item)), id));
                        }
                    }
                }
				// TODO used to be isDamageable, the 20.1 impl of that method appears to just be maxDamage > 0 though
				if (i.method_57347().method_58695(class_9334.field_50072, 0) > 0) {
					addRecipeSafe(registry, () -> new EmiAnvilRepairItemRecipe(i, synthetic("anvil/repairing/tool", EmiUtil.subId(i))));
					addRecipeSafe(registry, () -> new EmiGrindstoneRecipe(i, synthetic("grindstone/repairing", EmiUtil.subId(i))));
				}
			} catch (Throwable t) {
				EmiLog.error("Exception thrown registering repair recipes", t);
			}
			try {
				class_1799 defaultStack = i.method_7854();
				int acceptableEnchantments = 0;
				Consumer<class_1887> consumer = e -> {
					int max = e.method_8183();
					addRecipeSafe(registry, () -> new EmiAnvilEnchantRecipe(i, e, max,
						synthetic("anvil/enchanting", EmiUtil.subId(i) + "/" + EmiUtil.subId(EmiPort.getEnchantmentRegistry().method_10221(e)) + "/" + max)));
				};
				for (class_1887 e : targetedEnchantments) {
					if (e.method_8192(defaultStack) && defaultStack.method_7923()
							&& EmiAgnos.isEnchantable(defaultStack, e)) {
						consumer.accept(e);
						acceptableEnchantments++;
					}
				}
				if (acceptableEnchantments > 0) {
					for (class_1887 e : universalEnchantments) {
						if (e.method_8192(defaultStack)) {
							consumer.accept(e);
							acceptableEnchantments++;
						}
					}
					addRecipeSafe(registry, () -> new EmiGrindstoneDisenchantingRecipe(i, synthetic("grindstone/disenchanting/tool", EmiUtil.subId(i))));
				}
			} catch (Throwable t) {
				EmiReloadLog.warn("Exception thrown registering enchantment recipes", t);
			}
			if (i instanceof class_1747 bi && bi.method_7711() instanceof class_2521 tf && EmiPort.canTallFlowerDuplicate(tf)) {
				addRecipeSafe(registry, () -> basicWorld(EmiStack.of(bi).setRemainder(EmiStack.of(bi)), EmiStack.of(class_1802.field_8324), EmiStack.of(i),
						synthetic("world/flower_duping", EmiUtil.subId(i)), false));
			}
		}

		for (class_1887 e : EmiPort.getEnchantmentRegistry().method_10220().toList()) {
			if (!EmiPort.getEnchantmentRegistry().method_47983(e).method_40220(class_9636.field_51551)) {
				int max = Math.min(10, e.method_8183());
				int min = e.method_8187();
				while (min <= max) {
					int level = min;
					addRecipeSafe(registry, () -> new EmiGrindstoneDisenchantingBookRecipe(e, level,
						synthetic("grindstone/disenchanting/book", EmiUtil.subId(EmiPort.getEnchantmentRegistry().method_10221(e)) + "/" + level)));
					min++;
				}
			}
		}
	}

	private static void addWorldInteraction(EmiRegistry registry, Set<class_1792> hiddenItems, List<class_1792> dyeableItems) {
		EmiStack concreteWater = EmiStack.of(class_3612.field_15910);
		concreteWater.setRemainder(concreteWater);
		addConcreteRecipe(registry, class_2246.field_10197, concreteWater, class_2246.field_10107);
		addConcreteRecipe(registry, class_2246.field_10022, concreteWater, class_2246.field_10210);
		addConcreteRecipe(registry, class_2246.field_10300, concreteWater, class_2246.field_10585);
		addConcreteRecipe(registry, class_2246.field_10321, concreteWater, class_2246.field_10242);
		addConcreteRecipe(registry, class_2246.field_10145, concreteWater, class_2246.field_10542);
		addConcreteRecipe(registry, class_2246.field_10133, concreteWater, class_2246.field_10421);
		addConcreteRecipe(registry, class_2246.field_10522, concreteWater, class_2246.field_10434);
		addConcreteRecipe(registry, class_2246.field_10353, concreteWater, class_2246.field_10038);
		addConcreteRecipe(registry, class_2246.field_10628, concreteWater, class_2246.field_10172);
		addConcreteRecipe(registry, class_2246.field_10233, concreteWater, class_2246.field_10308);
		addConcreteRecipe(registry, class_2246.field_10404, concreteWater, class_2246.field_10206);
		addConcreteRecipe(registry, class_2246.field_10456, concreteWater, class_2246.field_10011);
		addConcreteRecipe(registry, class_2246.field_10023, concreteWater, class_2246.field_10439);
		addConcreteRecipe(registry, class_2246.field_10529, concreteWater, class_2246.field_10367);
		addConcreteRecipe(registry, class_2246.field_10287, concreteWater, class_2246.field_10058);
		addConcreteRecipe(registry, class_2246.field_10506, concreteWater, class_2246.field_10458);

		EmiIngredient axes = damagedTool(getPreferredTag(List.of(
				"minecraft:axes", "c:axes", "c:tools/axes", "fabric:axes", "forge:tools/axes"
			), EmiStack.of(class_1802.field_8475)), 1);
		for (Map.Entry<class_2248, class_2248> entry : AxeItemAccessor.getStrippedBlocks().entrySet()) {
			class_2960 id = synthetic("world/stripping", EmiUtil.subId(entry.getKey()));
			addRecipeSafe(registry, () -> basicWorld(EmiStack.of(entry.getKey()), axes, EmiStack.of(entry.getValue()), id));
		}
		for (Map.Entry<class_2248, class_2248> entry : class_5955.field_29565.get().entrySet()) {
			class_2960 id = synthetic("world/stripping", EmiUtil.subId(entry.getKey()));
			addRecipeSafe(registry, () -> basicWorld(EmiStack.of(entry.getKey()), axes, EmiStack.of(entry.getValue()), id));
		}
		for (Map.Entry<class_2248, class_2248> entry : class_5953.field_29561.get().entrySet()) {
			class_2960 id = synthetic("world/stripping", EmiUtil.subId(entry.getKey()));
			addRecipeSafe(registry, () -> basicWorld(EmiStack.of(entry.getKey()), axes, EmiStack.of(entry.getValue()), id));
		}
		
		EmiIngredient shears = damagedTool(EmiStack.of(class_1802.field_8868), 1);
		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/shearing", "minecraft/pumpkin"))
			.leftInput(EmiStack.of(class_1802.field_17518))
			.rightInput(shears, true)
			.output(EmiStack.of(class_1802.field_46249, 4))
			.output(EmiStack.of(class_1802.field_17519))
			.build());
		EmiIngredient hoes = damagedTool(getPreferredTag(List.of(
				"minecraft:hoes", "c:hoes", "c:tools/hoes", "fabric:hoes", "forge:tools/hoes"
			), EmiStack.of(class_1802.field_8609)), 1);
		for (Map.Entry<class_2248, Pair<Predicate<class_1838>, Consumer<class_1838>>> entry
				: HoeItemAccessor.getTillingActions().entrySet()) {
			Consumer<class_1838> consumer = entry.getValue().getSecond();
			if (EmiClient.HOE_ACTIONS.containsKey(consumer)) {
				class_2248 b = entry.getKey();
				class_2960 id = synthetic("world/tilling", EmiUtil.subId(b));
				List<EmiStack> list = EmiClient.HOE_ACTIONS.get(consumer).stream().map(EmiStack::of).toList();
				if (list.size() == 1) {
					addRecipeSafe(registry, () -> basicWorld(EmiStack.of(b), hoes, list.get(0), id));
				} else if (list.size() == 2) {
					addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
						.id(id)
						.leftInput(EmiStack.of(b))
						.rightInput(hoes, true)
						.output(list.get(0))
						.output(list.get(1))
						.build());
				} else {
					EmiReloadLog.warn("Encountered hoe action of peculiar size " + list.size() + ", skipping.");
				}
			}
		}

		EmiIngredient shovels = damagedTool(getPreferredTag(List.of(
				"minecraft:shovels", "c:shovels", "c:tools/shovels", "fabric:shovels", "forge:tools/shovels"
			), EmiStack.of(class_1802.field_8699)), 1);
		for (Map.Entry<class_2248, class_2680> entry : ShovelItemAccessor.getPathStates().entrySet()) {
			class_2248 result = entry.getValue().method_26204();
			class_2960 id = synthetic("world/flattening", EmiUtil.subId(entry.getKey()));
			addRecipeSafe(registry, () -> basicWorld(EmiStack.of(entry.getKey()), shovels, EmiStack.of(result), id));
		}

		EmiIngredient honeycomb = EmiStack.of(class_1802.field_20414);
		for (Map.Entry<class_2248, class_2248> entry : class_5953.field_29560.get().entrySet()) {
			class_2960 id = synthetic("world/waxing", EmiUtil.subId(entry.getKey()));
			addRecipeSafe(registry, () -> basicWorld(EmiStack.of(entry.getKey()), honeycomb, EmiStack.of(entry.getValue()), id, false));
		}

		for (class_1792 i : dyeableItems) {
			if (hiddenItems.contains(i)) {
				continue;
			}
			EmiStack cauldron = EmiStack.of(class_1802.field_8638);
			EmiStack waterThird = EmiStack.of(class_3612.field_15910, FluidUnit.BOTTLE);
			int uniq = EmiUtil.RANDOM.nextInt();
			addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
				.id(synthetic("world/cauldron_washing", EmiUtil.subId(i)))
				.leftInput(EmiStack.EMPTY, s -> new GeneratedSlotWidget(r -> {
					class_1799 stack = i.method_7854();
					stack.method_57379(class_9334.field_49644, new class_9282(r.nextInt(0xFFFFFF + 1)));
					return EmiStack.of(stack);
				}, uniq, s.getBounds().x(), s.getBounds().y()))
				.rightInput(cauldron, true)
				.rightInput(waterThird, false)
				.output(EmiStack.of(i))
				.supportsRecipeTree(false)
				.build());
		}

		EmiStack water = EmiStack.of(class_3612.field_15910, FluidUnit.BUCKET);
		EmiStack lava = EmiStack.of(class_3612.field_15908, FluidUnit.BUCKET);
		EmiStack waterCatalyst = water.copy().setRemainder(water);
		EmiStack lavaCatalyst = lava.copy().setRemainder(lava);

		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/fluid_spring", "minecraft/water"))
			.leftInput(waterCatalyst)
			.rightInput(waterCatalyst, false)
			.output(EmiStack.of(class_3612.field_15910, FluidUnit.BUCKET))
			.build());
		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/fluid_interaction", "minecraft/cobblestone"))
			.leftInput(waterCatalyst)
			.rightInput(lavaCatalyst, false)
			.output(EmiStack.of(class_1802.field_20412))
			.build());
		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/fluid_interaction", "minecraft/stone"))
			.leftInput(waterCatalyst)
			.rightInput(lavaCatalyst, false)
			.output(EmiStack.of(class_1802.field_20391))
			.build());
		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/fluid_interaction", "minecraft/obsidian"))
			.leftInput(lava)
			.rightInput(waterCatalyst, false)
			.output(EmiStack.of(class_1802.field_8281))
			.build());
	
		EmiStack soulSoil = EmiStack.of(class_1802.field_21999);
		soulSoil.setRemainder(soulSoil);
		EmiStack blueIce = EmiStack.of(class_1802.field_8178);
		blueIce.setRemainder(blueIce);

		addRecipeSafe(registry, () -> EmiWorldInteractionRecipe.builder()
			.id(synthetic("world/fluid_interaction", "minecraft/basalt"))
			.leftInput(lavaCatalyst)
			.rightInput(soulSoil, false, s -> s.appendTooltip(EmiPort
				.translatable("tooltip.emi.fluid_interaction.basalt.soul_soil", class_124.field_1060)))
			.rightInput(blueIce, false, s -> s.appendTooltip(EmiPort
				.translatable("tooltip.emi.fluid_interaction.basalt.blue_ice", class_124.field_1060)))
			.output(EmiStack.of(class_1802.field_22000))
			.build());

		EmiPort.getFluidRegistry().method_42017().forEach(entry -> {
			class_3611 fluid = entry.comp_349();
			class_1792 bucket = fluid.method_15774();
			if (fluid.method_15793(fluid.method_15785()) && !fluid.method_15785().method_15759().method_26215() && bucket != class_1802.field_8162 && fluid instanceof class_3609) {
				addRecipeSafe(registry, () -> basicWorld(EmiStack.of(class_1802.field_8550), EmiStack.of(fluid, FluidUnit.BUCKET), EmiStack.of(bucket),
					synthetic("emi", "bucket_filling/" + EmiUtil.subId(fluid)), false));
			}
		});

		addRecipeSafe(registry, () -> basicWorld(EmiStack.of(class_1802.field_8469), water,
			EmiStack.of(EmiPort.setPotion(new class_1799(class_1802.field_8574), class_1847.field_8991.comp_349())),
			synthetic("world/unique", "minecraft/water_bottle")));

		EmiStack waterBottle = EmiStack.of(EmiPort.setPotion(new class_1799(class_1802.field_8574), class_1847.field_8991.comp_349()))
			.setRemainder(EmiStack.of(class_1802.field_8469));
		EmiStack mud = EmiStack.of(class_1802.field_37537);
		addRecipeSafe(registry, () -> basicWorld(EmiStack.of(class_1802.field_8831), waterBottle, mud, synthetic("world/unique", "minecraft/mud"), false));
	}

	private static EmiIngredient damagedTool(EmiIngredient tool, int damage) {
		for (EmiStack stack : tool.getEmiStacks()) {
			class_1799 is = stack.getItemStack().method_7972();
			is.method_7974(1);
			stack.setRemainder(EmiStack.of(is));
		}
		return tool;
	}

	private static EmiIngredient getPreferredTag(List<String> candidates, EmiIngredient fallback) {
		for (String id : candidates) {
			EmiIngredient potential = EmiIngredient.of(class_6862.method_40092(EmiPort.getItemRegistry().method_46765(), EmiPort.id(id)));
			if (!potential.isEmpty()) {
				return potential;
			}
		}
		return fallback;
	}

	private static void addFuel(EmiRegistry registry, Set<class_1792> hiddenItems) {
		Map<class_1792, Integer> fuelMap = EmiAgnos.getFuelMap();
		compressRecipesToTags(fuelMap.keySet().stream().collect(Collectors.toSet()), (a, b) -> {
				return Integer.compare(fuelMap.get(a), fuelMap.get(b));
			}, tag -> {
				EmiIngredient stack = EmiIngredient.of(tag.raw());
				class_1792 item = stack.getEmiStacks().get(0).getItemStack().method_7909();
				int time = fuelMap.get(item);
				registry.addRecipe(new EmiFuelRecipe(stack, time, synthetic("fuel/tag", EmiUtil.subId(tag.id()))));
			}, item -> {
				if (!hiddenItems.contains(item)) {
					int time = fuelMap.get(item);
					registry.addRecipe(new EmiFuelRecipe(EmiStack.of(item), time, synthetic("fuel/item", EmiUtil.subId(item))));
				}
			});
	}

	private static void addComposting(EmiRegistry registry, Set<class_1792> hiddenItems) {
		compressRecipesToTags(class_3962.field_17566.keySet().stream()
			.map(class_1935::method_8389).collect(Collectors.toSet()), (a, b) -> {
				return Float.compare(class_3962.field_17566.getFloat(a), class_3962.field_17566.getFloat(b));
			}, tag -> {
				EmiIngredient stack = EmiIngredient.of(tag.raw());
				class_1792 item = stack.getEmiStacks().get(0).getItemStack().method_7909();
				float chance = class_3962.field_17566.getFloat(item);
				registry.addRecipe(new EmiCompostingRecipe(stack, chance, synthetic("composting/tag", EmiUtil.subId(tag.id()))));
			}, item -> {
				if (!hiddenItems.contains(item)) {
					float chance = class_3962.field_17566.getFloat(item);
					registry.addRecipe(new EmiCompostingRecipe(EmiStack.of(item), chance, synthetic("composting/item", EmiUtil.subId(item))));
				}
			});
	}

	private static void compressRecipesToTags(Set<class_1792> stacks, Comparator<class_1792> comparator, Consumer<EmiTagKey<class_1792>> tagConsumer, Consumer<class_1792> itemConsumer) {
		Set<class_1792> handled = Sets.newHashSet();
		outer:
		for (EmiTagKey<class_1792> key : EmiTags.getTags(EmiPort.getItemRegistry())) {
			List<class_1792> items = key.getList();
			if (items.size() < 2) {
				continue;
			}
			class_1792 base = items.get(0);
			if (!stacks.contains(base)) {
				continue;
			}
			for (int i = 1; i < items.size(); i++) {
				class_1792 item = items.get(i);
				if (!stacks.contains(item) || comparator.compare(base, item) != 0) {
					continue outer;
				}
			}
			if (handled.containsAll(items)) {
				continue;
			}
			handled.addAll(items);
			tagConsumer.accept(key);
		}
		for (class_1792 item : stacks) {
			if (handled.contains(item)) {
				continue;
			}
			itemConsumer.accept(item);
		}
	}

	private static class_2960 synthetic(String type, String name) {
		return EmiPort.id("emi", "/" + type + "/" + name);
	}

	private static <C extends class_9695, T extends class_1860<C>> Iterable<T> getRecipes(EmiRegistry registry, class_3956<T> type) {
		return EmiAgnos.getAllRecipesOfType(registry.getRecipeManager(), type).stream().map(class_8786::comp_1933)::iterator;
	}

	private static void safely(String name, Runnable runnable) {
		try {
			runnable.run();
		} catch (Throwable t) {
			EmiReloadLog.warn("Exception thrown when reloading " + name  + " step in vanilla EMI plugin", t);
		}
	}

	private static void addRecipeSafe(EmiRegistry registry, Supplier<EmiRecipe> supplier) {
		try {
			registry.addRecipe(supplier.get());
		} catch (Throwable e) {
			EmiReloadLog.warn("Exception thrown when parsing EMI recipe (no ID available)", e);
		}
	}

	private static void addRecipeSafe(EmiRegistry registry, Supplier<EmiRecipe> supplier, class_1860<?> recipe) {
		try {
			registry.addRecipe(supplier.get());
		} catch (Throwable e) {
			EmiReloadLog.warn("Exception thrown when parsing vanilla recipe " + EmiPort.getId(recipe), e);
		}
	}

	private static EmiRenderable simplifiedRenderer(int u, int v) {
		return (raw, x, y, delta) -> {
			EmiDrawContext context = EmiDrawContext.wrap(raw);
			context.drawTexture(EmiRenderHelper.WIDGETS, x, y, u, v, 16, 16);
		};
	}

	private static void addConcreteRecipe(EmiRegistry registry, class_2248 powder, EmiStack water, class_2248 result) {
		addRecipeSafe(registry, () -> basicWorld(EmiStack.of(powder), water, EmiStack.of(result),
			synthetic("world/concrete", EmiUtil.subId(result))));
	}

	private static EmiRecipe basicWorld(EmiIngredient left, EmiIngredient right, EmiStack output, class_2960 id) {
		return basicWorld(left, right, output, id, true);
	}

	private static EmiRecipe basicWorld(EmiIngredient left, EmiIngredient right, EmiStack output, class_2960 id, boolean catalyst) {
		return EmiWorldInteractionRecipe.builder()
			.id(id)
			.leftInput(left)
			.rightInput(right, catalyst)
			.output(output)
			.build();
	}
}