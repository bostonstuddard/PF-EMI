package dev.emi.emi.config;

import dev.emi.emi.EmiPort;
import net.minecraft.class_2561;

public enum HeaderType implements ConfigEnum {
	VISIBLE("visible"),
	INVISIBLE("invisible"),
	;

	private final String name;

	private HeaderType(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public class_2561 getText() {
		return EmiPort.translatable("emi.header." + name);
	}
}
