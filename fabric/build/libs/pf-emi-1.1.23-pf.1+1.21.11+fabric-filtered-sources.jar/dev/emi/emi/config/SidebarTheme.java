package dev.emi.emi.config;

import dev.emi.emi.EmiPort;
import net.minecraft.class_2561;

public enum SidebarTheme implements ConfigEnum {
	TRANSPARENT("transparent", 0, 0),
	VANILLA("vanilla", 9, 9),
	MODERN("modern", 0, 0),
	;

	private final String name;
	public final int horizontalPadding, verticalPadding;

	private SidebarTheme(String name, int horizontalPadding, int verticalPadding) {
		this.name = name;
		this.horizontalPadding = horizontalPadding;
		this.verticalPadding = verticalPadding;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public class_2561 getText() {
		return EmiPort.translatable("emi.sidebar.theme." + name);
	}
}
