package dev.emi.emi.config;

import net.minecraft.class_2561;

public interface ConfigEnum {

	String getName();

	class_2561 getText();
}
