package dev.emi.emi.chess;

import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.tooltip.EmiTooltipComponent;
import net.minecraft.class_2561;
import net.minecraft.class_327;

class ChessTooltipComponent implements EmiTooltipComponent {
	private final ChessPiece dragged, hovered;
	private final class_2561 description;
	
	public ChessTooltipComponent(ChessPiece dragged, ChessPiece hovered, class_2561 description) {
		this.dragged = dragged;
		this.hovered = hovered;
		this.description = description;
	}

    @Override
    public int method_32661(class_327 textRenderer) {
        return 30;
    }

    @Override
	public int method_32664(class_327 textRenderer) {
		return Math.max(textRenderer.method_27525(description), 48);
	}

	@Override
	public void drawTooltip(EmiDrawContext context, TooltipRenderData tooltip) {
		context.drawTexture(EmiRenderHelper.PIECES, 0, 14, 100, dragged.type().u, dragged.color() == PieceColor.BLACK ? 0 : 16, 16, 16);
		context.drawTexture(EmiRenderHelper.PIECES, 32, 14, 100, hovered.type().u, hovered.color() == PieceColor.BLACK ? 0 : 16, 16, 16);
	}

	@Override
	public void drawTooltipText(TextRenderData text) {
		text.draw(description, 0, 4, 0xFFFFFFFF, true);
		text.draw("->", 18, 19, 0xFFFFFFFF, true);
	}
}
