package dev.emi.emi.chess;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_9326;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.EmiScreenManager;

class ChessEmiStack extends EmiStack {
	public final int position;

	public ChessEmiStack(int position) {
		this.position = position;
	}

	@Override
	public void render(class_332 raw, int x, int y, float delta, int flags) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		ChessPiece piece = EmiChess.getBoard().get(position);
		context.enableDepthTest();
		EmiChess chess = EmiChess.get();
		if (chess.pendingPromotion != -1) {
			PieceType type = null;
			int dir = chess.pendingPromotion > 31 ? -8 : 8;
			if (position == chess.pendingPromotion) {
				type = PieceType.QUEEN;
			} else if (position == chess.pendingPromotion + dir) {
				type = PieceType.KNIGHT;
			} else if (position == chess.pendingPromotion + dir * 2) {
				type = PieceType.ROOK;
			} else if (position == chess.pendingPromotion + dir * 3) {
				type = PieceType.BISHOP;
			}
			if (type != null) {
				context.push();
//				context.matrices().translate(0, 0, 10);
				context.fill(x - 1, y - 1, 18, 18, 0x55000000);
//				context.matrices().translate(0, 0, 90);
				context.drawTexture(EmiRenderHelper.PIECES, x, y, 100, type.u, chess.pendingPromotion > 31 ? 0 : 16, 16, 16, 256, 256);
				context.pop();
				return;
			}
		}
		context.push();
//		context.matrices().translate(0, 0, 10);
		if (chess.isTarget(position)) {
			context.fill(x - 1, y - 1, 18, 18, 0x5555ff00);
		}
		boolean dragging = !EmiScreenManager.draggedStack.isEmpty();
		ChessMove move = chess.board.lastMove;
		if (!dragging &&move != null && (move.start() == position || move.end() == position)) {
			context.fill(x - 1, y - 1, 18, 18, 0x55aaaa00);
		}
		if (!dragging && piece != null && piece.type() == PieceType.KING && chess.board.isChecked(piece.color())) {
			context.fill(x - 1, y - 1, 18, 18, 0x55ff0000);
		}
		context.pop();
		if (piece != null) {
			context.push();
//			context.matrices().translate(0, 0, 100);
			context.drawTexture(EmiRenderHelper.PIECES, x, y, 100, piece.type().u, piece.color() == PieceColor.BLACK ? 0 : 16, 16, 16, 256, 256);
			context.pop();
		}
	}

	@Override
	public EmiStack copy() {
		return this;
	}

	@Override
	public boolean isEmpty() {
		return EmiChess.get().board.get(position) == null;
	}

	@Override
	public class_9326 getComponentChanges() {
		return class_9326.field_49588;
	}

	@Override
	public Object getKey() {
		return position;
	}

	@Override
	public class_2960 getId() {
		return EmiPort.id("emi:/chess/" + position);
	}

	@Override
	public List<class_2561> getTooltipText() {
		return List.of();
	}

	@Override
	public List<class_5684> getTooltip() {
		ChessPiece piece = EmiChess.getBoard().get(position);
		if (piece != null) {
			List<class_5684> list = Lists.newArrayList();
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.translatable("emi.chess.piece."
				+ piece.color().toString().toLowerCase() + "_" + piece.type().toString().toLowerCase()))));
			class_310 client = class_310.method_1551();
			if (!EmiChess.get().started) {
				if (piece.type() == PieceType.KING) {
					list.add(new ChessTooltipComponent(
						ChessPiece.of(PieceType.PAWN, PieceColor.BLACK),
						ChessPiece.of(PieceType.KING, PieceColor.BLACK),
						EmiPort.translatable("emi.chess.tooltip.invite")));
					if (EmiChess.get().pending != null) {
						class_1657 player = client.field_1687.method_18470(EmiChess.get().pending);
						if (player != null) {
							list.add(new ChessTooltipComponent(
								ChessPiece.of(PieceType.KING, PieceColor.WHITE),
								ChessPiece.of(PieceType.KING, PieceColor.BLACK),
								EmiPort.translatable("emi.chess.tooltip.accept", player.method_5477())));
							list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.translatable("emi.chess.tooltip.decline", player.method_5477()))));
						}
					}
				}
			} else {
				if (piece.type() == PieceType.KING && piece.color() == PieceColor.WHITE) {
					list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.translatable("emi.chess.tooltip.restart"))));
				}
			}
			return list;
		}
		return List.of();
	}

	@Override
	public class_2561 getName() {
		return EmiPort.literal("Chess Piece");
	}
}
