package dev.emi.emi.widget;

import java.util.List;
import net.minecraft.class_11246;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiScreenshotRecorder;

public class RecipeScreenshotButtonWidget extends RecipeButtonWidget {
	public RecipeScreenshotButtonWidget(int x, int y, EmiRecipe recipe) {
		super(x, y, 60, 0, recipe);
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		return List.of(class_5684.method_32662(EmiPort.ordered(EmiPort.translatable("tooltip.emi.recipe_screenshot"))));
	}

	@Override
	public boolean mouseClicked(int mouseX, int mouseY, int button) {
		this.playButtonSound();

		class_2960 id = recipe.getId();
		String path;
		if (id == null) {
			path = "unknown-recipe";
		} else {
			// Note that saveScreenshot treats `/`s as indicating subdirectories.
			// We don't want to keep `/` in paths because we want all recipe images in consistent directory locations.
			path = id.method_12836() + "/" + id.method_12832().replace("/", "_");
		}

		int width = recipe.getDisplayWidth() + 8;
		int height = recipe.getDisplayHeight() + 8;
		class_310 client = class_310.method_1551();
		class_332 context = new class_332(client, new class_11246(), 0, 0); // TODO
		EmiScreenshotRecorder.saveScreenshot("emi/recipes/" + path, width, height,
			() -> EmiRenderHelper.renderRecipe(recipe, EmiDrawContext.wrap(context), 0, 0, false, -1));

		return true;
	}
}
