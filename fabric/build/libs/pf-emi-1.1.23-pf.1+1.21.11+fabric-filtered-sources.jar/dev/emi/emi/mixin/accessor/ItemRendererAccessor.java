package dev.emi.emi.mixin.accessor;

import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_918.class)
public interface ItemRendererAccessor {

//	@Invoker("renderBakedItemModel")
//	void invokeRenderBakedItemModel(BakedModel model, ItemStack stack, int light, int overlay, MatrixStack matrices, VertexConsumer vertices);
}
