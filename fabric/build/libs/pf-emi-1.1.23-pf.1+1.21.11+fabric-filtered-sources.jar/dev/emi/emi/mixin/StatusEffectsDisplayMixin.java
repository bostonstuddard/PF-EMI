package dev.emi.emi.mixin;

import com.google.common.collect.Ordering;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.config.EffectLocation;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.mixin.accessor.HandledScreenAccessor;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.runtime.EmiDrawContext;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10799;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_485;

@Mixin(class_485.class)
public abstract class StatusEffectsDisplayMixin {

    @Shadow
    @Final
    private class_465<?> parent;

    @Shadow
    @Final
    private class_310 client;

    @Unique
    private static final boolean emi$hasInventoryTabs = EmiAgnos.isModLoaded("inventorytabs");

    @Shadow
    protected abstract int drawStatusEffectBackgrounds(class_332 context, class_327 textRenderer, class_2561 description,
                                                       class_2561 duration, int x, int y, boolean ambient, int width);

    @Shadow
    protected abstract class_2561 getStatusEffectDescription(class_1293 statusEffect);

    @Shadow
    protected abstract void drawTexts(class_332 context, class_2561 description, class_2561 duration, class_327 textRenderer,
                                      int x, int y, int width, int height, int mouseX, int mouseY);

    @Inject(at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/ingame/StatusEffectsDisplay;drawStatusEffects(Lnet/minecraft/client/gui/DrawContext;Ljava/util/Collection;IIIII)V"),
            method = "render", cancellable = true)
    private void drawStatusEffects(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
        if (EmiConfig.effectLocation == EffectLocation.TOP) {
            emi$drawCenteredEffects(context, mouseX, mouseY);
            ci.cancel();
        } else if (EmiConfig.effectLocation == EffectLocation.HIDDEN) {
            ci.cancel();
        }
    }

	@Unique
    private void emi$drawCenteredEffects(class_332 raw, int mouseX, int mouseY) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		context.resetColor();
		Collection<class_1293> effects = Ordering.natural().sortedCopy(this.client.field_1724.method_6026());
		int size = effects.size();
		if (size == 0) {
			return;
		}

        int screenX = ((HandledScreenAccessor) parent).getX();
        int screenY = ((HandledScreenAccessor) parent).getY();
        int backgroundWidth = ((HandledScreenAccessor) parent).getBackgroundWidth();

		boolean wide = size == 1;

		int y = screenY - 34;
		if (parent instanceof class_481 || emi$hasInventoryTabs) {
			y -= 28;
			if (parent instanceof class_481 && EmiAgnos.isForge()) {
				y -= 22;
			}
		}

		int xOff = 34;
		if (wide) {
			xOff = 122;
		} else if (size > 5) {
			xOff = (backgroundWidth - 32) / (size - 1);
		}

		int width = (size - 1) * xOff + (wide ? 120 : 32);
		int x = screenX + (backgroundWidth - width) / 2;
		class_1293 hovered = null;

        for (class_1293 inst : effects) {
            int ew = wide ? 120 : 32;

            class_327 textRenderer = this.parent.method_64506();
            class_2561 description = this.getStatusEffectDescription(inst);
            class_2561 duration = class_1292.method_5577(inst, 1.0F, this.client.field_1687.method_54719()
                    .method_54748());
            boolean isAmbient = inst.method_5591();

            int textWidth = this.drawStatusEffectBackgrounds(context.raw(), textRenderer, description, duration, x, y, isAmbient, ew);
            raw.method_52706(class_10799.field_56883, class_329.method_71644(inst.method_5579()), x + 7, y + 7, 18, 18);
            if (wide) {
                this.drawTexts(raw, description, duration, textRenderer, x, y, textWidth, 32, mouseX, mouseY);
            }

            if (mouseX >= x && mouseX < x + ew && mouseY >= y && mouseY < y + 32) {
                hovered = inst;
            }
            x += xOff;
        }

		if (hovered != null && size > 1) {
			List<class_2561> list = List.of(this.getStatusEffectDescription(hovered), class_1292.method_5577(hovered, 1.0f, client.field_1687.method_54719().method_54748()));
			context.raw().method_64038(client.field_1772, list, Optional.empty(), mouseX, Math.max(mouseY, 16));
		}
	}

	@ModifyVariable(at = @At("HEAD"), method = "drawStatusEffects", ordinal = 4, argsOnly = true)
	private int squishEffects(int original) {
		return EmiConfig.effectLocation.compressed ? 32 : original;
	}

    @ModifyVariable(at = @At("HEAD"), method = "drawStatusEffects", ordinal = 0, argsOnly = true)
	private int changeEffectSpace(int original) {
        int screenX = ((HandledScreenAccessor) parent).getX();
		return switch (EmiConfig.effectLocation) {
			case RIGHT, RIGHT_COMPRESSED, HIDDEN -> original;
			case TOP -> screenX;
			case LEFT_COMPRESSED -> screenX - 2- 32;
			case LEFT -> screenX - 2 - 120;
		};
	}

}
