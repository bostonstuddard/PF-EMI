package dev.emi.emi.mixin.accessor;

import net.minecraft.class_1092;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1092.class)
public interface BakedModelManagerAccessor {

//	@Accessor("models")
//    Map<ModelIdentifier, BakedModel> getModels();
}
