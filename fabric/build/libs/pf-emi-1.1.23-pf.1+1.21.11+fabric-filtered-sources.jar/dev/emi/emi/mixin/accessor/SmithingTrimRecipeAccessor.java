package dev.emi.emi.mixin.accessor;

import net.minecraft.class_1856;
import net.minecraft.class_8062;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8062.class)
public interface SmithingTrimRecipeAccessor {

	@Accessor("template")
	class_1856 getTemplate();

	@Accessor("base")
	class_1856 getBase();

	@Accessor("addition")
	class_1856 getAddition();
}
