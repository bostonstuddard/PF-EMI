package dev.emi.emi.mixin;

import com.llamalad7.mixinextras.sugar.Local;

import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.EmiScreenManager;
import net.minecraft.class_1041;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_437;
import net.minecraft.class_465;

@Mixin(class_312.class)
public abstract class MouseMixin {
	@Shadow @Final
	private class_310 client;
	@Shadow
	private double x, y;
    @Shadow
    private double cursorDeltaX;
    @Shadow
    private double cursorDeltaY;
    @Shadow
    private @Nullable class_11910 activeButton;

    @Shadow
    public abstract double getScaledX(class_1041 window);

    @Shadow
    public abstract double getScaledY(class_1041 window);

    @Inject(at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/Screen;mouseClicked(Lnet/minecraft/client/gui/Click;Z)Z"),
            method = "onMouseButton", cancellable = true)
	private void onMouseDown(long window, class_11910 input, int action, CallbackInfo info, @Local(ordinal = 0) class_11909 click, @Local(ordinal = 1) boolean bl2) {
		try {
			class_437 screen = client.field_1755;
			if (screen instanceof class_465<?>) {
				if (EmiScreenManager.mouseClicked(click, bl2)) {
					info.cancel();
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling mouse press", e);
		}
	}

    @Inject(at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screen/Screen;mouseReleased(Lnet/minecraft/client/gui/Click;)Z"),
            method = "onMouseButton", cancellable = true)
	private void onMouseUp(long window, class_11910 input, int action, CallbackInfo info, @Local(ordinal = 0) class_11909 click) {
		try {
			class_437 screen = client.field_1755;
			if (screen instanceof class_465<?>) {
				if (EmiScreenManager.mouseReleased(click)) {
					info.cancel();
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling mouse release", e);
		}
	}

    @Inject(at = @At(value = "INVOKE", target =
            "Lnet/minecraft/client/gui/screen/Screen;mouseDragged(Lnet/minecraft/client/gui/Click;DD)Z"),
            method = "tick", cancellable = true)
	private void onMouseDragged(CallbackInfo info) {
		try {
			class_437 screen = client.field_1755;
			if (screen instanceof class_465<?>) {
                class_1041 window = this.client.method_22683();
                class_11909 click = new class_11909(this.getScaledX(window), this.getScaledY(window), this.activeButton);
                double dx = class_312.method_68880(window, this.cursorDeltaX);
                double dy = class_312.method_68884(window, this.cursorDeltaY);
				EmiScreenManager.mouseDragged(click, dx, dy);
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling mouse drag", e);
		}
	}

	@Inject(at = @At(value = "INVOKE", target =
			"net/minecraft/client/gui/screen/Screen.mouseScrolled(DDDD)Z"),
		method = "onMouseScroll(JDD)V", cancellable = true)
	private void onMouseScrolled(long window, double horizontal, double vertical, CallbackInfo info) {
		try {
			class_437 screen = client.field_1755;
			if (screen instanceof class_465<?> hs) {
				double amount = (client.field_1690.method_42439().method_41753() ? Math.signum(vertical) : vertical) * client.field_1690.method_41806().method_41753();
				double mx = x * client.method_22683().method_4486() / client.method_22683().method_4480();
				double my = y * client.method_22683().method_4502() / client.method_22683().method_4507();
				if (EmiScreenManager.mouseScrolled(mx, my, amount)) {
					info.cancel();
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling mouse scroll", e);
		}
	}
}
