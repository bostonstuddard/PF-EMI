package dev.emi.emi.mixin.conversion;

import org.spongepowered.asm.mixin.Mixin;

import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.EmiStackConvertible;
import net.minecraft.class_3611;

@Mixin(class_3611.class)
public class FluidMixin implements EmiStackConvertible {

	@Override
	public EmiStack emi() {
		return EmiStack.of((class_3611) (Object) this);
	}

	@Override
	public EmiStack emi(long amount) {
		return EmiStack.of((class_3611) (Object) this, amount);
	}
}
