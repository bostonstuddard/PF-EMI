package dev.emi.emi.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1856;

@Mixin(class_1845.class)
public interface BrewingRecipeRegistryAccessor {
    @Accessor("potionTypes")
    List<class_1856> getPotionTypes();

    @Accessor("potionRecipes")
    List<class_1845.class_1846<class_1842>> getPotionRecipes();

    @Accessor("itemRecipes")
    List<class_1845.class_1846<class_1792>> getItemRecipes();
}
