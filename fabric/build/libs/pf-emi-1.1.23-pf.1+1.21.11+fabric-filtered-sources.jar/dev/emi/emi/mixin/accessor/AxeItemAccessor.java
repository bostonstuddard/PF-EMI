package dev.emi.emi.mixin.accessor;

import java.util.Map;
import net.minecraft.class_1743;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1743.class)
public interface AxeItemAccessor {
	
	@Accessor("STRIPPED_BLOCKS")
	static Map<class_2248, class_2248> getStrippedBlocks() {
		throw new UnsupportedOperationException();
	}
}
