package dev.emi.emi.mixin.accessor;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_332.class)
public interface DrawContextAccessor {

	@Invoker("drawTooltip")
	void invokeDrawTooltip(class_327 textRenderer, List<class_5684> components, int x, int y, class_8000 positioner, @Nullable class_2960 texture, boolean focused);
}
