package dev.emi.emi.mixin.accessor;

import java.util.Map;
import net.minecraft.class_1821;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1821.class)
public interface ShovelItemAccessor {

	@Accessor("PATH_STATES")
	static Map<class_2248, class_2680> getPathStates() {
		throw new UnsupportedOperationException();
	}
}
