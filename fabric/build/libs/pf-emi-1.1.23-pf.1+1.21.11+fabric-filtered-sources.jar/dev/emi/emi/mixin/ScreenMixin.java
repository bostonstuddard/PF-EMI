package dev.emi.emi.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.screen.EmiScreenManager;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;

@Mixin(class_437.class)
public class ScreenMixin {

	@Inject(at = @At("RETURN"), method = "init(II)V")
	private void init(int width, int height, CallbackInfo ci) {
		if ((Object) this instanceof class_465<?> hs && class_310.method_1551().field_1755 == hs) {
			EmiScreenManager.addWidgets(hs);
		}
	}

	@Inject(at = @At("RETURN"), method = "resize")
	private void resize(int width, int height, CallbackInfo ci) {
		if ((Object) this instanceof class_465<?> hs && class_310.method_1551().field_1755 == hs) {
			EmiScreenManager.addWidgets(hs);
		}
	}
}
