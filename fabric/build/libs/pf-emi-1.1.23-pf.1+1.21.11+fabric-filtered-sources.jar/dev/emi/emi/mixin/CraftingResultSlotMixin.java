package dev.emi.emi.mixin;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.runtime.EmiSidebars;

@Mixin(class_1734.class)
public class CraftingResultSlotMixin {
	@Shadow @Final
	private class_8566 input;
	@Shadow @Final
	private class_1657 player;
	
	@Inject(at = @At("HEAD"), method = "onCrafted(Lnet/minecraft/item/ItemStack;)V")
	private void onCrafted(class_1799 stack, CallbackInfo info) {
		class_1937 world = player.method_73183();
		if (world.method_8608()) {
			Optional<class_3955> opt = EmiAgnos.getFirstMatchRecipe(world.method_8433(), class_3956.field_17545, input.method_60501().comp_2795(), world).map(class_8786::comp_1933);
			if (opt.isPresent()) {
				EmiRecipe recipe = EmiApi.getRecipeManager().getRecipe(EmiPort.getId(opt.get()));
				if (recipe != null) {
					EmiSidebars.craft(recipe);
				}
			}
		}
	}
}
