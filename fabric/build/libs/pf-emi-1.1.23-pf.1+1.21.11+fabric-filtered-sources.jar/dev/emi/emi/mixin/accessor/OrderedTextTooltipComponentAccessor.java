package dev.emi.emi.mixin.accessor;

import net.minecraft.class_5481;
import net.minecraft.class_5683;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5683.class)
public interface OrderedTextTooltipComponentAccessor {
	
	@Accessor("text")
    public class_5481 getText();
}
