package dev.emi.emi.mixin.conversion;

import org.spongepowered.asm.mixin.Mixin;

import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.EmiStackConvertible;
import net.minecraft.class_1792;
import net.minecraft.class_1935;

@Mixin(class_1935.class)
public interface ItemConvertibleMixin extends EmiStackConvertible {

	@Override
	default EmiStack emi() {
		return EmiStack.of((class_1792) (Object) this);
	}

	@Override
	default EmiStack emi(long amount) {
		return EmiStack.of((class_1792) (Object) this, amount);
	}
}
