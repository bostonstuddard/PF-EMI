package dev.emi.emi.mixin;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1794;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import dev.emi.emi.platform.EmiClient;

@Mixin(class_1794.class)
public class HoeItemMixin {

	@Inject(at = @At("RETURN"), method = "createTillAction")
	private static void createTillAction(class_2680 result, CallbackInfoReturnable<Consumer<class_1838>> info) {
		EmiClient.HOE_ACTIONS.put(info.getReturnValue(), List.of(result.method_26204()));
	}

	@Inject(at = @At("RETURN"), method = "createTillAndDropAction")
	private static void createTillAndDropAction(class_2680 result, class_1935 droppedItem,
			CallbackInfoReturnable<Consumer<class_1838>> info) {
		EmiClient.HOE_ACTIONS.put(info.getReturnValue(), List.of(droppedItem, result.method_26204()));
	}
}
