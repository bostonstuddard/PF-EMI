package dev.emi.emi.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.EmiScreenManager;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;

@Mixin(class_309.class)
public class KeyboardMixin {
	@Shadow @Final
	private class_310 client;
	
	@Inject(at = @At(value = "INVOKE", target =
			"Lnet/minecraft/client/gui/screen/Screen;keyPressed(Lnet/minecraft/client/input/KeyInput;)Z"),
		method = "onKey", cancellable = true)
	public void onKey(long window, int action, class_11908 input, CallbackInfo info) {
		try {
			class_437 screen = client.field_1755;
			if (screen instanceof class_465<?> hs) {
				if (action == 1 || action == 2) {
					if (EmiScreenManager.keyPressed(input)) {
						info.cancel();
					}
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling key press", e);
		}
	}
	
	@Inject(at = @At("HEAD"),
		method = "onChar", cancellable = true)
	public void onChar(long window, class_11905 input, CallbackInfo info) {
		try {
			if (window == client.method_22683().method_4490()) {
				class_437 screen = client.field_1755;
				if (screen instanceof class_465<?> hs && this.client.method_18506() == null) {
					boolean consume = false;
					if (Character.charCount(input.comp_4793()) == 1) {
						consume = EmiScreenManager.search.method_25400(input) || consume;
					} else {
						for (char c : Character.toChars(input.comp_4793())) {
							consume = EmiScreenManager.search.method_25400(input) || consume;
						}
					}
					if (consume) {
						info.cancel();
					}
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error while handling char", e);
		}
	}
}
