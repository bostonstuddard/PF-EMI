package dev.emi.emi.mixin.conversion;

import org.spongepowered.asm.mixin.Mixin;

import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.EmiStackConvertible;
import net.minecraft.class_1799;

@Mixin(class_1799.class)
public class ItemStackMixin implements EmiStackConvertible {

	@Override
	public EmiStack emi() {
		return EmiStack.of((class_1799) (Object) this);
	}

	@Override
	public EmiStack emi(long amount) {
		return EmiStack.of((class_1799) (Object) this, amount);
	}
}
