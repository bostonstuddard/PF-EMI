package dev.emi.emi.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Optional;
import net.minecraft.class_1856;
import net.minecraft.class_8060;

@Mixin(class_8060.class)
public interface SmithingTransformRecipeAccessor {

	@Accessor("template")
    Optional<class_1856> getTemplate();

	@Accessor("base")
	class_1856 getBase();

	@Accessor("addition")
    Optional<class_1856> getAddition();
}
