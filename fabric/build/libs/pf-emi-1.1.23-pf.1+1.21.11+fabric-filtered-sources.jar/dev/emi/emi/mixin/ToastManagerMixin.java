package dev.emi.emi.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.emi.emi.api.EmiApi;
import dev.emi.emi.config.EmiConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_374;

@Mixin(class_374.class)
public class ToastManagerMixin {
	
	@Inject(at = @At("HEAD"), method = "draw", cancellable = true)
	private void drawHead(class_332 raw, CallbackInfo info) {
		class_310 client = class_310.method_1551();
		if (client.field_1755 != null && EmiConfig.enabled && EmiApi.getHandledScreen() != null) {
			info.cancel();
		}
	}
}
