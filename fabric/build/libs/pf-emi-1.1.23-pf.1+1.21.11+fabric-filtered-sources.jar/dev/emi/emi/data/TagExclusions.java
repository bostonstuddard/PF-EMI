package dev.emi.emi.data;

import java.util.Map;
import java.util.Set;
import net.minecraft.class_2960;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

public class TagExclusions {
	public final Set<class_2960> globalExclusions = Sets.newHashSet();
	public final Map<class_2960, Set<class_2960>> exclusions = Maps.newHashMap();

	public void add(class_2960 id) {
		globalExclusions.add(id);
	}

	public void add(class_2960 type, class_2960 id) {
		exclusions.computeIfAbsent(type, t -> Sets.newHashSet()).add(id);
	}

	public void clear() {
		globalExclusions.clear();
		exclusions.clear();
	}

	public boolean contains(class_2960 type, class_2960 id) {
		return globalExclusions.contains(id) || (exclusions.containsKey(type) && exclusions.get(type).contains(id));
	}
}
