package dev.emi.emi.data;

import java.io.InputStreamReader;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import dev.emi.emi.EmiPort;
import dev.emi.emi.runtime.EmiLog;

public class EmiDataLoader<T> extends class_4080<T>
		implements EmiResourceReloadListener {
	private static final Gson GSON = new Gson();
	private final class_2960 id;
	private final String path;
	private final Supplier<T> baseSupplier;
	private final DataConsumer<T> prepare;
	private final Consumer<T> apply;

	public EmiDataLoader(class_2960 id, String path, Supplier<T> baseSupplier,
			DataConsumer<T> prepare, Consumer<T> apply) {
		this.id = id;
		this.path = path;
		this.baseSupplier = baseSupplier;
		this.prepare = prepare;
		this.apply = apply;
	}

	@Override
	public T method_18789(class_3300 manager, class_3695 profiler) {
		T t = baseSupplier.get();
		for (class_2960 id : EmiPort.findResources(manager, path, i -> i.endsWith(".json"))) {
			if (!id.method_12836().equals("emi")) {
				continue;
			}
			for (class_3298 resource : manager.method_14489(id)) {
				try {
					InputStreamReader reader = new InputStreamReader(EmiPort.getInputStream(resource));
					JsonObject json = class_3518.method_15276(GSON, reader, JsonObject.class);
					prepare.accept(t, json, id);
				} catch (Exception e) {
					EmiLog.error("Error loading data for " + this.id + " in " + id, e);
				}
			}
		}
		return t;
	}

	@Override
	public void method_18788(T t, class_3300 manager, class_3695 profiler) {
		apply.accept(t);
	}

	@Override
	public class_2960 getEmiId() {
		return id;
	}

	public static interface DataConsumer<T> {
		void accept(T t, JsonObject json, class_2960 id);
	}
}
