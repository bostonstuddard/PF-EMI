package dev.emi.emi.data;

import java.io.InputStreamReader;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import dev.emi.emi.EmiPort;
import dev.emi.emi.bom.BoM;
import dev.emi.emi.runtime.EmiLog;

public class RecipeDefaultLoader extends class_4080<RecipeDefaults>
		implements EmiResourceReloadListener {
	private static final Gson GSON = new Gson();
	public static final class_2960 ID = EmiPort.id("emi:recipe_defaults");

	@Override
	protected RecipeDefaults method_18789(class_3300 manager, class_3695 profiler) {
		RecipeDefaults defaults = new RecipeDefaults();
		for (class_2960 id : EmiPort.findResources(manager, "recipe/defaults", i -> i.endsWith(".json"))) {
			if (!id.method_12836().equals("emi")) {
				continue;
			}
			try {
				for (class_3298 resource : manager.method_14489(id)) {
					InputStreamReader reader = new InputStreamReader(EmiPort.getInputStream(resource));
					JsonObject json = class_3518.method_15276(GSON, reader, JsonObject.class);
					loadDefaults(defaults, json);
				}
			} catch (Exception e) {
				EmiLog.error("Error loading recipe default file " + id, e);
			}
		}
		return defaults;
	}

	@Override
	protected void apply(RecipeDefaults prepared, class_3300 manager, class_3695 profiler) {
		BoM.setDefaults(prepared);
	}
	
	@Override
	public class_2960 getEmiId() {
		return ID;
	}

	public static void loadDefaults(RecipeDefaults defaults, JsonObject json) {
		if (class_3518.method_15258(json, "replace", false)) {
			defaults.clear();
		}
		JsonArray disabled = class_3518.method_15292(json, "disabled", new JsonArray());
		for (JsonElement el : disabled) {
			class_2960 id = EmiPort.id(el.getAsString());
			defaults.remove(id);
		}
		JsonArray added = class_3518.method_15292(json, "added", new JsonArray());
		if (class_3518.method_15264(json, "recipes")) {
			added.addAll(class_3518.method_15261(json, "recipes"));
		}
		for (JsonElement el : added) {
			class_2960 id = EmiPort.id(el.getAsString());
			defaults.add(id);
		}
		JsonObject resolutions = class_3518.method_15281(json, "resolutions", new JsonObject());
		for (String key : resolutions.keySet()) {
			class_2960 id = EmiPort.id(key);
			if (class_3518.method_15264(resolutions, key)) {
				defaults.add(id, class_3518.method_15261(resolutions, key));
			}
		}
		JsonObject addedTags = class_3518.method_15281(json, "tags", new JsonObject());
		for (String key : addedTags.keySet()) {
			defaults.addTag(new JsonPrimitive(key), addedTags.get(key));
		}
	}
}
