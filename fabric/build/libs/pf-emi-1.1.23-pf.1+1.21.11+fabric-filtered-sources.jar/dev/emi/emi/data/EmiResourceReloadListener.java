package dev.emi.emi.data;

import net.minecraft.class_2960;
import net.minecraft.class_3302;

public interface EmiResourceReloadListener extends class_3302 {
	
	class_2960 getEmiId();
}
