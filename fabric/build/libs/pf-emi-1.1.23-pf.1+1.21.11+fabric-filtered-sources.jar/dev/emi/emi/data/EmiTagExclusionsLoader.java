package dev.emi.emi.data;

import java.io.InputStreamReader;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.emi.emi.EmiPort;
import dev.emi.emi.registry.EmiTags;
import dev.emi.emi.runtime.EmiLog;

public class EmiTagExclusionsLoader extends class_4080<TagExclusions>
		implements EmiResourceReloadListener {
	private static final Gson GSON = new Gson();
	private static final class_2960 ID = EmiPort.id("emi:tag_exclusions");

	@Override
	public TagExclusions method_18789(class_3300 manager, class_3695 profiler) {
		TagExclusions exclusions = new TagExclusions();
		for (class_2960 id : EmiPort.findResources(manager, "tag/exclusions", i -> i.endsWith(".json"))) {
			if (!id.method_12836().equals("emi")) {
				continue;
			}
			try {
				for (class_3298 resource : manager.method_14489(id)) {
					InputStreamReader reader = new InputStreamReader(EmiPort.getInputStream(resource));
					JsonObject json = class_3518.method_15276(GSON, reader, JsonObject.class);
					try {
						if (class_3518.method_15258(json, "replace", false)) {
							exclusions.clear();
						}
						for (String key : json.keySet()) {
							class_2960 type = EmiPort.id(key);
							if (class_3518.method_15264(json, key)) {
								JsonArray arr = class_3518.method_15261(json, key);
								for (JsonElement el : arr) {
									class_2960 eid = EmiPort.id(el.getAsString());
									if (key.equals("exclusions")) {
										exclusions.add(eid);
										if (eid.method_12836().equals("c")) {
											exclusions.add(EmiPort.id("forge", eid.method_12832()));
										}
									} else {
										exclusions.add(type, eid);
										if (eid.method_12836().equals("c")) {
											exclusions.add(type, EmiPort.id("forge", eid.method_12832()));
										}
									}
								}
							}
						}
					} catch (Exception e) {
						EmiLog.error("Error loading tag exclusions", e);
					}
				}
			} catch (Exception e) {
				EmiLog.error("Error loading tag exclusions", e);
			}
		}
		return exclusions;
	}

	@Override
	public void apply(TagExclusions exclusions, class_3300 manager, class_3695 profiler) {
		EmiTags.exclusions = exclusions;
	}

	@Override
	public class_2960 getEmiId() {
		return ID;
	}
}
