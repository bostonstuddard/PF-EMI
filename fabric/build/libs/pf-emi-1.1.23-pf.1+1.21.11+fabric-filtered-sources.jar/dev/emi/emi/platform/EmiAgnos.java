package dev.emi.emi.platform;

import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_10286;
import net.minecraft.class_10439;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3956;
import net.minecraft.class_5684;
import net.minecraft.class_8786;
import net.minecraft.class_9326;
import net.minecraft.class_9695;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.FluidEmiStack;
import dev.emi.emi.registry.EmiPluginContainer;
import dev.emi.emi.runtime.EmiDrawContext;

public abstract class EmiAgnos {
	public static EmiAgnos delegate;

	static {
		try {
			Class.forName("dev.emi.emi.platform.fabric.EmiAgnosFabric");
		} catch (Throwable t) {
		}
		try {
			Class.forName("dev.emi.emi.platform.forge.EmiAgnosForge");
		} catch (Throwable t) {
		}
		try {
			Class.forName("dev.emi.emi.platform.neoforge.EmiAgnosNeoForge");
		} catch (Throwable t) {
		}
	}

	public static boolean isForge() {
		return delegate.isForgeAgnos();
	}

	protected abstract boolean isForgeAgnos();

	public static String getModName(String namespace) {
		return delegate.getModNameAgnos(namespace);
	}

	protected abstract String getModNameAgnos(String namespace);

	public static Path getConfigDirectory() {
		return delegate.getConfigDirectoryAgnos();
	}

	protected abstract Path getConfigDirectoryAgnos();

	public static boolean isDevelopmentEnvironment() {
		return delegate.isDevelopmentEnvironmentAgnos();
	}

	protected abstract boolean isDevelopmentEnvironmentAgnos();

	public static boolean isModLoaded(String id) {
		return delegate.isModLoadedAgnos(id);
	}

	protected abstract boolean isModLoadedAgnos(String id);

	public static List<String> getAllModNames() {
		return delegate.getAllModNamesAgnos();
	}

	protected abstract List<String> getAllModNamesAgnos();

	public static List<String> getAllModAuthors() {
		return delegate.getAllModAuthorsAgnos();
	}

	protected abstract List<String> getAllModAuthorsAgnos();

	public static List<String> getModsWithPlugins() {
		return delegate.getModsWithPluginsAgnos();
	}

	protected abstract List<String> getModsWithPluginsAgnos();

	public static List<EmiPluginContainer> getPlugins() {
		return delegate.getPluginsAgnos();
	}

	protected abstract List<EmiPluginContainer> getPluginsAgnos();

	public static void addBrewingRecipes(EmiRegistry registry) {
		delegate.addBrewingRecipesAgnos(registry);
	}

	protected abstract void addBrewingRecipesAgnos(EmiRegistry registry);

	public static List<class_5684> getItemTooltip(class_1799 stack) {
		return delegate.getItemTooltipAgnos(stack);
	}

	protected abstract List<class_5684> getItemTooltipAgnos(class_1799 stack);

	public static class_2561 getFluidName(class_3611 fluid, class_9326 componentChanges) {
		return delegate.getFluidNameAgnos(fluid, componentChanges);
	}

	protected abstract class_2561 getFluidNameAgnos(class_3611 fluid, class_9326 componentChanges);

	public static List<class_2561> getFluidTooltip(class_3611 fluid, class_9326 componentChanges) {
		return delegate.getFluidTooltipAgnos(fluid, componentChanges);
	}

	protected abstract List<class_2561> getFluidTooltipAgnos(class_3611 fluid, class_9326 componentChanges);

	public static boolean isFloatyFluid(FluidEmiStack stack) {
		return delegate.isFloatyFluidAgnos(stack);
	}

	protected abstract boolean isFloatyFluidAgnos(FluidEmiStack stack);

	public static void renderFluid(FluidEmiStack stack, EmiDrawContext context, int x, int y, float delta) {
		renderFluid(stack, context, x, y, delta, 0, 0, 16, 16);
	}

	public static void renderFluid(FluidEmiStack stack, EmiDrawContext context, int x, int y, float delta, int xOff, int yOff, int width, int height) {
		delegate.renderFluidAgnos(stack, context, x, y, delta, xOff, yOff, width, height);
	}

	protected abstract void renderFluidAgnos(FluidEmiStack stack, EmiDrawContext context, int x, int y, float delta, int xOff, int yOff, int width, int height);

	public static EmiStack createFluidStack(Object object) {
		return delegate.createFluidStackAgnos(object);
	}

	protected abstract EmiStack createFluidStackAgnos(Object object);

	public static boolean canBatch(class_1799 stack) {
		return delegate.canBatchAgnos(stack);
	}
	
	protected abstract boolean canBatchAgnos(class_1799 stack);

	public static Map<class_1792, Integer> getFuelMap() {
		return delegate.getFuelMapAgnos();
	}

	protected abstract Map<class_1792, Integer> getFuelMapAgnos();

	public static class_10439 getBakedTagModel(class_2960 id) {
		return delegate.getBakedTagModelAgnos(id);
	}

	protected abstract class_10439 getBakedTagModelAgnos(class_2960 id);

	public static boolean isEnchantable(class_1799 stack, class_1887 enchantment) {
		return delegate.isEnchantableAgnos(stack, enchantment);
	}

	protected abstract boolean isEnchantableAgnos(class_1799 stack, class_1887 enchantment);

    public static <I extends class_9695, T extends class_1860<I>> Collection<class_8786<T>> getAllRecipesOfType(class_10286 recipeManager, class_3956<T> recipeType) {
        return delegate.getAllRecipesOfTypeAgnos(recipeManager, recipeType);
    }

    protected abstract <I extends class_9695, T extends class_1860<I>> Collection<class_8786<T>> getAllRecipesOfTypeAgnos(class_10286 recipeManager, class_3956<T> recipeType);

    public static <I extends class_9695, T extends class_1860<I>> Stream<class_8786<T>> getAllMatchesRecipe(class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world) {
        return delegate.getAllMatchesRecipeAgnos(recipeManager, recipeType, input, world);
    }

    protected abstract <I extends class_9695, T extends class_1860<I>> Stream<class_8786<T>> getAllMatchesRecipeAgnos(class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world);

    public static <I extends class_9695, T extends class_1860<I>> Optional<class_8786<T>> getFirstMatchRecipe(class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world) {
        return delegate.getFirstMatchRecipeAgnos(recipeManager, recipeType, input, world);
    }

    protected abstract <I extends class_9695, T extends class_1860<I>> Optional<class_8786<T>> getFirstMatchRecipeAgnos(class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world);

    public static Collection<class_8786<?>> listAllRecipes(class_10286 recipeManager) {
        return delegate.getAllRecipesAgnos(recipeManager);
    }

    protected abstract Collection<class_8786<?>> getAllRecipesAgnos(class_10286 recipeManager);

    public static class_8786<?> getRecipe(class_10286 recipeManager, class_2960 id) {
        return delegate.getRecipeAgnos(recipeManager, id);
    }

    protected abstract class_8786<?> getRecipeAgnos(class_10286 recipeManager, class_2960 id);
}
