package dev.emi.emi.platform;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import net.minecraft.class_465;
import com.google.common.collect.Maps;

import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.network.EmiNetwork;
import dev.emi.emi.network.FillRecipeC2SPacket;

public class EmiClient {
	public static final Map<Consumer<class_1838>, List<class_1935>> HOE_ACTIONS = Maps.newHashMap();
	public static boolean onServer = false;

	public static void init() {
		EmiConfig.loadConfig();
	}

	public static <T extends class_1703> void sendFillRecipe(StandardRecipeHandler<T> handler, class_465<T> screen,
			int syncId, int action, List<class_1799> stacks, EmiRecipe recipe) {
		T screenHandler = screen.method_17577();
		List<class_1735> crafting = handler.getCraftingSlots(recipe, screenHandler);
		class_1735 output = handler.getOutputSlot(screenHandler);
		EmiNetwork.sendToServer(new FillRecipeC2SPacket(screenHandler, action, handler.getInputSources(screenHandler), crafting, output, stacks));
	}
}
