package dev.emi.emi.platform.fabric;

import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.apache.commons.lang3.text.WordUtils;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.FabricEmiStack;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.FluidEmiStack;
import dev.emi.emi.mixin.accessor.BrewingRecipeRegistryAccessor;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.recipe.EmiBrewingRecipe;
import dev.emi.emi.registry.EmiPluginContainer;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.FakeScreen;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import mezz.jei.api.fabric.ingredients.fluids.IJeiFluidIngredient;

import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.minecraft.class_10286;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_10439;
import net.minecraft.class_1058;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_5684;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8786;
import net.minecraft.class_9326;
import net.minecraft.class_9695;

public class EmiAgnosFabric extends EmiAgnos {
	static {
		EmiAgnos.delegate = new EmiAgnosFabric();
	}

	@Override
	protected boolean isForgeAgnos() {
		return false;
	}

	@SuppressWarnings("deprecation")
	@Override
	protected String getModNameAgnos(String namespace) {
		if (namespace.equals("c")) {
			return "Common";
		}
		Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(namespace);
		if (container.isPresent()) {
			return container.get().getMetadata().getName();
		}
		container = FabricLoader.getInstance().getModContainer(namespace.replace('_', '-'));
		if (container.isPresent()) {
			return container.get().getMetadata().getName();
		}
		return WordUtils.capitalizeFully(namespace.replace('_', ' '));
	}

	@Override
	protected Path getConfigDirectoryAgnos() {
		return FabricLoader.getInstance().getConfigDir();
	}

	@Override
	protected boolean isDevelopmentEnvironmentAgnos() {
		return FabricLoader.getInstance().isDevelopmentEnvironment();
	}

	@Override
	protected boolean isModLoadedAgnos(String id) {
		return FabricLoader.getInstance().isModLoaded(id);
	}

	@Override
	protected List<String> getAllModNamesAgnos() {
		return FabricLoader.getInstance().getAllMods().stream().map(c -> c.getMetadata().getName()).toList();
	}

	@Override
	protected List<String> getAllModAuthorsAgnos() {
		return FabricLoader.getInstance().getAllMods().stream().flatMap(c -> c.getMetadata().getAuthors().stream())
			.map(p -> p.getName()).distinct().toList();
	}

	@Override
	protected List<String> getModsWithPluginsAgnos() {
		List<String> list = Lists.newArrayList();
		for (EntrypointContainer<EmiPlugin> container : FabricLoader.getInstance().getEntrypointContainers("emi", EmiPlugin.class)) {
			try {
				list.add(container.getProvider().getMetadata().getId());
			} catch (Throwable t) {
				EmiLog.error("Critical exception thrown when reading EMI Plugin from mod " + container.getProvider().getMetadata().getId(), t);
			}
		}
		return list;
	}


	@Override
	protected List<EmiPluginContainer> getPluginsAgnos() {
		List<EmiPluginContainer> list = Lists.newArrayList();
		for (EntrypointContainer<EmiPlugin> container : FabricLoader.getInstance().getEntrypointContainers("emi", EmiPlugin.class)) {
			try {
				list.add(new EmiPluginContainer(container.getEntrypoint(), container.getProvider().getMetadata().getId()));
			} catch (Throwable t) {
				EmiLog.error("Critical exception thrown when constructing EMI Plugin from mod " + container.getProvider().getMetadata().getId(), t);
			}
		}
		return list;
	}

	@Override
	protected void addBrewingRecipesAgnos(EmiRegistry registry) {
        class_1937 world = class_310.method_1551().field_1687;
		class_1845 brewingRegistry = world != null ? world.method_59547() : class_1845.field_51402;
        class_10352 paramMap = class_10363.method_65008(world);
		BrewingRecipeRegistryAccessor brewingRegistryAccess = (BrewingRecipeRegistryAccessor)brewingRegistry;

		for (class_1856 ingredient : brewingRegistryAccess.getPotionTypes()) {
			for (class_1799 stack : ingredient.method_64673().method_64738(paramMap)) {
				String pid = EmiUtil.subId(stack.method_7909());
				for (class_1845.class_1846<class_1842> recipe : brewingRegistryAccess.getPotionRecipes()) {
					try {
						class_1856 recipeIngredient = recipe.comp_2191();
						if (!recipeIngredient.method_64673().method_64738(paramMap).isEmpty()) {
							class_2960 id = EmiPort.id("emi", "/brewing/" + pid
								+ "/" + EmiUtil.subId(recipeIngredient.method_64673().method_64738(paramMap).getFirst().method_7909())
								+ "/" + EmiUtil.subId(EmiPort.getPotionRegistry().method_10221(recipe.comp_2190().comp_349()))
								+ "/" + EmiUtil.subId(EmiPort.getPotionRegistry().method_10221(recipe.comp_2192().comp_349())));
							registry.addRecipe(new EmiBrewingRecipe(
								EmiStack.of(EmiPort.setPotion(stack.method_7972(), recipe.comp_2190().comp_349())), EmiIngredient.of(recipeIngredient),
								EmiStack.of(EmiPort.setPotion(stack.method_7972(), recipe.comp_2192().comp_349())), id));
						}
					} catch (Exception e) {
						EmiLog.error("Error registering brewing recipe", e);
					}
				}
			}
		}

		for (class_1845.class_1846<class_1792> recipe : brewingRegistryAccess.getItemRecipes()) {
			try {
				class_1856 recipeIngredient = recipe.comp_2191();
				if (!recipeIngredient.method_64673().method_64738(paramMap).isEmpty()) {
					String gid = EmiUtil.subId(recipeIngredient.method_64673().method_64738(paramMap).getFirst().method_7909());
					String iid = EmiUtil.subId(recipe.comp_2190().comp_349());
					String oid = EmiUtil.subId(recipe.comp_2192().comp_349());
					Consumer<class_6880<class_1842>> potionRecipeGen = entry -> {
						if (brewingRegistry.method_20361(entry)) {
							class_2960 id = EmiPort.id("emi", "/brewing/item/"
								+ EmiUtil.subId(entry.method_40230().get().method_29177()) + "/" + gid + "/" + iid + "/" + oid);
							registry.addRecipe(new EmiBrewingRecipe(
								EmiStack.of(EmiPort.setPotion(new class_1799(recipe.comp_2190().comp_349()), entry.comp_349())), EmiIngredient.of(recipeIngredient),
								EmiStack.of(EmiPort.setPotion(new class_1799(recipe.comp_2192().comp_349()), entry.comp_349())), id));
						}
					};
					if (recipe.comp_2190().comp_349() instanceof class_1812) {
						EmiPort.getPotionRegistry().method_42017().forEach(potionRecipeGen);
					} else {
						potionRecipeGen.accept(class_1847.field_8999);
					}
				}
			} catch (Exception e) {
				EmiLog.error("Error registering brewing recipe", e);
			}
		}
	}

	@Override
	protected List<class_5684> getItemTooltipAgnos(class_1799 stack) {
		return FakeScreen.INSTANCE.getTooltipComponentListFromItem(stack);
	}

	@Override
	protected class_2561 getFluidNameAgnos(class_3611 fluid, class_9326 componentChanges) {
		return FluidVariantAttributes.getName(FluidVariant.of(fluid, componentChanges));
	}

	@Override
	protected List<class_2561> getFluidTooltipAgnos(class_3611 fluid, class_9326 componentChanges) {
		return FluidVariantRendering.getTooltip(FluidVariant.of(fluid, componentChanges));
	}

	@Override
	protected boolean isFloatyFluidAgnos(FluidEmiStack stack) {
		FluidVariant fluid = FluidVariant.of(stack.getKeyOfType(class_3611.class), stack.getComponentChanges());
		return FluidVariantAttributes.isLighterThanAir(fluid);
	}

	@Override
	protected void renderFluidAgnos(FluidEmiStack stack, EmiDrawContext context, int x, int y, float delta, int xOff, int yOff, int width, int height) {
		FluidVariant fluid = FluidVariant.of(stack.getKeyOfType(class_3611.class), stack.getComponentChanges());
		class_1058[] sprites = FluidVariantRendering.getSprites(fluid);
		if (sprites == null || sprites.length < 1 || sprites[0] == null) {
			return;
		}
		class_1058 sprite = sprites[0];
		int color = FluidVariantRendering.getColor(fluid);
		
		EmiRenderHelper.drawTintedSprite(context, sprite, color, x, y, xOff, yOff, width, height);
	}

	@Override
	protected EmiStack createFluidStackAgnos(Object object) {
		if (object instanceof IJeiFluidIngredient fluid) {
			return FabricEmiStack.of(fluid.getFluidVariant(), fluid.getAmount());
		}
		return EmiStack.EMPTY;
	}

	@Override
	protected boolean canBatchAgnos(class_1799 stack) {
		return false;//ColorProviderRegistry.ITEM.get(stack.getItem()) == null; TODO
	}

	@Override
	protected Map<class_1792, Integer> getFuelMapAgnos() {
		Object2IntMap<class_1792> fuelMap = new Object2IntOpenHashMap<>();
		for (class_1792 item : EmiPort.getItemRegistry()) {
			if (!class_310.method_1551().field_1687.method_61269().method_61751().contains(item)) {
				continue;
			}
			int time = class_310.method_1551().field_1687.method_61269().method_61755(item.method_7854());
			if (time > 0) {
				fuelMap.put(item, time);
			}
		}
		return fuelMap;
	}

    @Override
	protected class_10439 getBakedTagModelAgnos(class_2960 id) {
		return class_310.method_1551().method_1554().method_65746(id);
	}

	@Override
	protected boolean isEnchantableAgnos(class_1799 stack, class_1887 enchantment) {
		return true;
	}

    @Override
    protected <I extends class_9695, T extends class_1860<I>> Collection<class_8786<T>> getAllRecipesOfTypeAgnos(class_10286 recipeManager,
                                                                                     class_3956<T> recipeType) {
        return recipeManager.getSynchronizedRecipes().getAllOfType(recipeType);
    }

    @Override
    protected <I extends class_9695, T extends class_1860<I>> Stream<class_8786<T>> getAllMatchesRecipeAgnos(
            class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world) {
        return recipeManager.getSynchronizedRecipes().getAllMatches(recipeType, input, world);
    }

    @Override
    protected <I extends class_9695, T extends class_1860<I>> Optional<class_8786<T>> getFirstMatchRecipeAgnos(
            class_10286 recipeManager, class_3956<T> recipeType, I input, class_1937 world) {
        return recipeManager.getSynchronizedRecipes().getFirstMatch(recipeType, input, world);
    }

    @Override
    protected Collection<class_8786<?>> getAllRecipesAgnos(class_10286 recipeManager) {
        return recipeManager.getSynchronizedRecipes().recipes();
    }

    @Override
    protected class_8786<?> getRecipeAgnos(class_10286 recipeManager, class_2960 id) {
        return recipeManager.getSynchronizedRecipes().get(class_5321.method_29179(class_7924.field_52178, id));
    }

}
