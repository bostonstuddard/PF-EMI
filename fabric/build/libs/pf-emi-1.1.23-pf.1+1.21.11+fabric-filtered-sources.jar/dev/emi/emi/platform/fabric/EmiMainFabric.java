package dev.emi.emi.platform.fabric;

import dev.emi.emi.network.CommandS2CPacket;
import dev.emi.emi.network.CreateItemC2SPacket;
import dev.emi.emi.network.EmiChessPacket;
import dev.emi.emi.network.EmiNetwork;
import dev.emi.emi.network.EmiPacket;
import dev.emi.emi.network.FillRecipeC2SPacket;
import dev.emi.emi.network.PingS2CPacket;
import dev.emi.emi.platform.EmiMain;
import dev.emi.emi.registry.EmiCommands;
import dev.emi.emi.runtime.EmiLog;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.recipe.v1.sync.RecipeSynchronization;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9141;

public class EmiMainFabric implements ModInitializer {

	@Override
	public void onInitialize() {
		EmiMain.init();
		CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> EmiCommands.registerCommands(dispatcher));

		EmiNetwork.initServer(ServerPlayNetworking::send);

		registerPacketReader(EmiNetwork.FILL_RECIPE, FillRecipeC2SPacket::new);
		registerPacketReader(EmiNetwork.CREATE_ITEM, CreateItemC2SPacket::new);
		registerPacketReader(EmiNetwork.CHESS, EmiChessPacket.C2S::new);

		PayloadTypeRegistry.playS2C().register(EmiNetwork.PING, class_9139.method_56437((buf, v) -> v.write(buf), PingS2CPacket::new));
		PayloadTypeRegistry.playS2C().register(EmiNetwork.COMMAND, class_9139.method_56437((buf, v) -> v.write(buf), CommandS2CPacket::new));
		PayloadTypeRegistry.playS2C().register(EmiNetwork.CHESS, class_9139.method_56437((buf, v) -> v.write(buf), EmiChessPacket.S2C::new));

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			EmiNetwork.sendToClient(handler.field_14140, new PingS2CPacket());
		});

        // Run through vanilla recipe serializers and sync them
        for (var entry : class_7923.field_41189.method_29722()) {
            class_5321<class_1865<?>> resourceKey = entry.getKey();
            if (resourceKey.method_29177().method_12836().equals(class_2960.field_33381)) {
                class_1865<?> serializer = entry.getValue();
                try {
                    RecipeSynchronization.synchronizeRecipeSerializer(serializer);
                } catch (RuntimeException e) {
                    EmiLog.error("Failed to synchronize recipe serializer", e);
                }
            }
        }
	}

	private <T extends EmiPacket> void registerPacketReader(class_8710.class_9154<T> id, class_9141<class_9129, T> decode) {
		PayloadTypeRegistry.playC2S().register(id, class_9139.method_56437((buf, v) -> v.write(buf), decode));
		ServerPlayNetworking.registerGlobalReceiver(id, (payload, context) -> {
			context.server().execute(() -> {
				((EmiPacket) payload).apply(context.player());
			});
		});
	}
}