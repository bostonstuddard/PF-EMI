package dev.emi.emi.platform.fabric;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import dev.emi.emi.data.EmiData;
import dev.emi.emi.network.CommandS2CPacket;
import dev.emi.emi.network.EmiChessPacket;
import dev.emi.emi.network.EmiNetwork;
import dev.emi.emi.network.EmiPacket;
import dev.emi.emi.network.PingS2CPacket;
import dev.emi.emi.platform.EmiClient;
import dev.emi.emi.runtime.EmiReloadManager;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.recipe.v1.sync.ClientRecipeSynchronizedEvent;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9141;
import org.jspecify.annotations.NonNull;

public class EmiClientFabric implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		EmiClient.init();
		EmiData.init(reloader -> {
			ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new IdentifiableResourceReloadListener() {

                @Override
                public CompletableFuture<Void> method_25931(class_11558 store, Executor prepareExecutor,
                                                      class_4045 reloadSynchronizer, Executor applyExecutor) {
                    return reloader.method_25931(store, prepareExecutor, reloadSynchronizer, applyExecutor);
                }

                @Override
				public String method_22322() {
					return reloader.method_22322();
				}

				@Override
				public @NonNull class_2960 getFabricId() {
					return reloader.getEmiId();
				}
			});
		});

        ClientRecipeSynchronizedEvent.EVENT.register((minecraft, synchronizedRecipes) -> {
            EmiReloadManager.reloadRecipes();
        });

//		PreparableModelLoadingPlugin.<List<Identifier>>register((manager, executor) -> {
//			return CompletableFuture.supplyAsync(() -> {
//				List<Identifier> ids = Lists.newArrayList();
//				EmiTags.registerTagModels(manager, id -> ids.add(id.id()), "");
//				return ids;
//			}, executor);
//		}, (ids, context) -> {
//			context.addModels(ids);
//		}); TODO

		EmiNetwork.initClient(packet -> {
			if (ClientPlayNetworking.canSend(packet.method_56479())) {
				ClientPlayNetworking.send(packet);
			}
		});

		registerPacketReader(EmiNetwork.PING, PingS2CPacket::new);
		registerPacketReader(EmiNetwork.COMMAND, CommandS2CPacket::new);
		registerPacketReader(EmiNetwork.CHESS, EmiChessPacket.S2C::new);
	}

	private <T extends EmiPacket> void registerPacketReader(class_8710.class_9154<T> id, class_9141<class_9129, T> decode) {
		ClientPlayNetworking.registerGlobalReceiver(id, (payload, context) -> {
			context.client().execute(() -> {
				payload.apply(context.client().field_1724);
			});
		});
	}
}
