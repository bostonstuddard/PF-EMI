package dev.emi.emi.input;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;

public class EmiBind {
	public static final EmiBind LEFT_CLICK = new EmiBind("", new EmiBind.ModifiedKey(class_3675.class_307.field_1672.method_1447(0), 0));
	public static final int MAX_BINDS = 4;
	public final String translationKey;
	public final List<ModifiedKey> defaultKeys;
	public List<ModifiedKey> boundKeys;
	
	public EmiBind(String translationKey, int code) {
		this(translationKey, 0, code);
	}
	
	public EmiBind(String translationKey, int modifiers, int code) {
		this(translationKey, ModifiedKey.of(code, modifiers));
	}

	public EmiBind(String translationKey, ModifiedKey... defaultKeys) {
		this.translationKey = translationKey;
		this.defaultKeys = Arrays.asList(defaultKeys);
		this.boundKeys = this.defaultKeys.stream().collect(Collectors.toCollection(ArrayList::new));
		updateBinds();
	}

	public void updateBinds() {
		if (boundKeys.size() == 0) {
			boundKeys.add(new ModifiedKey(class_3675.field_16237, 0));
		}
		for (int i = 0; i < boundKeys.size() - 1; i++) {
			if (boundKeys.get(i).isUnbound()) {
				boundKeys.remove(i);
				i--;
			}
		}
		if (!boundKeys.get(boundKeys.size() - 1).isUnbound() && boundKeys.size() < MAX_BINDS) {
			boundKeys.add(new ModifiedKey(class_3675.field_16237, 0));
		}
	}

	public boolean isBound() {
		return boundKeys.size() > 0 && !boundKeys.get(0).isUnbound();
	}

	public class_2561 getBindText() {
		if (!isBound()) {
			return EmiPort.literal("[]", class_124.field_1065);
		} else {
			ModifiedKey bind = boundKeys.get(0);
			for (ModifiedKey key : boundKeys) {
				if (key.key.method_1442() == class_3675.class_307.field_1672) {
					bind = key;
					break;
				}
			}
			return EmiPort.literal("[", class_124.field_1065)
				.method_10852(bind.getKeyText(class_124.field_1065))
				.method_10852(EmiPort.literal("]", class_124.field_1065));
		}
	}

	public void setToDefault() {
		this.boundKeys = this.defaultKeys.stream().collect(Collectors.toCollection(ArrayList::new));
		updateBinds();
	}

	public void setBinds(ModifiedKey... keys) {
		this.boundKeys = Stream.of(keys).collect(Collectors.toCollection(ArrayList::new));
		updateBinds();
	}

	public void setBind(int offset, ModifiedKey key) {
		if (offset < boundKeys.size() && offset >= 0) {
			boundKeys.set(offset, key);
		}
		updateBinds();
	}

	public boolean isHeld() {
		for (ModifiedKey boundKey : boundKeys) {
			if (EmiInput.getCurrentModifiers() == boundKey.modifiersToMatch()) {
				if (boundKey.key.method_1442() == class_3675.class_307.field_1668 && boundKey.key.method_1444() != -1) {
					if (class_3675.method_15987(class_310.method_1551().method_22683(), boundKey.key.method_1444())) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public boolean matchesKey(int keyCode, int scanCode) {
		for (ModifiedKey boundKey : boundKeys) {
			if (EmiInput.getCurrentModifiers() == boundKey.modifiersToMatch()) {
				if (keyCode == class_3675.field_16237.method_1444()) {
					if (boundKey.key.method_1442() == class_3675.class_307.field_1671 && boundKey.key.method_1444() == scanCode) {
						return true;
					}
				} else {
					if (boundKey.key.method_1442() == class_3675.class_307.field_1668 && boundKey.key.method_1444() == keyCode) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public boolean matchesMouse(int code) {
		for (ModifiedKey boundKey : boundKeys) {
			if (EmiInput.getCurrentModifiers() == boundKey.modifiersToMatch()) {
				if (boundKey.key.method_1442() == class_3675.class_307.field_1672 && boundKey.key.method_1444() == code) {
					return true;
				}
			}
		}
		return false;
	}

	public void setKey(List<String> keys) {
		List<ModifiedKey> modifiedKeys = Lists.newArrayList();
		for (String string : keys) {
			String[] parts = string.split(" ");
			class_3675.class_306 key = class_3675.field_16237;
			int modifiers = 0;
			if (parts.length > 0) {
				key = class_3675.method_15981(parts[parts.length - 1]);
				for (int i = 0; i < parts.length - 1; i++) {
					if (parts[i].equals("ctrl") || parts[i].equals("control")) {
						modifiers |= EmiInput.CONTROL_MASK;
					} else if (parts[i].equals("alt")) {
						modifiers |= EmiInput.ALT_MASK;
					} else if (parts[i].equals("shift")) {
						modifiers |= EmiInput.SHIFT_MASK;
					}
				}
			}
			modifiedKeys.add(new ModifiedKey(key, modifiers));
		}
		this.boundKeys = modifiedKeys;
		updateBinds();
	}

	public static record ModifiedKey(class_3675.class_306 key, int modifiers) {

		public static ModifiedKey of(int code, int modifiers) {
			return new ModifiedKey(class_3675.class_307.field_1668.method_1447(code), modifiers);
		}

		public String toName() {
			String name = "";
			if ((modifiers & EmiInput.CONTROL_MASK) > 0) {
				name += "ctrl ";
			}
			if ((modifiers & EmiInput.ALT_MASK) > 0) {
				name += "alt ";
			}
			if ((modifiers & EmiInput.SHIFT_MASK) > 0) {
				name += "shift ";
			}
			name += key.method_1441();
			return name;
		}

		public int modifiersToMatch() {
			int modifiers = this.modifiers;
			if (key.method_1442() == class_3675.class_307.field_1668) {
				modifiers ^= EmiInput.maskFromCode(key.method_1444());
			}
			return modifiers;
		}

		public boolean isUnbound() {
			return key == class_3675.field_16237;
		}

		public class_5250 getKeyText(class_124 formatting) {
			class_5250 text = EmiPort.literal("", formatting);
			appendModifiers(text, modifiers());
			EmiPort.append(text, key().method_27445());
			return text;
		}
	
		private void appendModifiers(class_5250 text, int modifiers) {
			if ((modifiers & EmiInput.CONTROL_MASK) > 0) {
				EmiPort.append(text, EmiPort.translatable("key.keyboard.control"));
				EmiPort.append(text, EmiPort.literal(" + "));
			}
			if ((modifiers & EmiInput.ALT_MASK) > 0) {
				EmiPort.append(text, EmiPort.translatable("key.keyboard.alt"));
				EmiPort.append(text, EmiPort.literal(" + "));
			}
			if ((modifiers & EmiInput.SHIFT_MASK) > 0) {
				EmiPort.append(text, EmiPort.translatable("key.keyboard.shift"));
				EmiPort.append(text, EmiPort.literal(" + "));
			}
		}
	}
}
