package dev.emi.emi.stack.serializer;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ItemEmiStack;
import dev.emi.emi.api.stack.serializer.EmiStackSerializer;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9326;

public class ItemEmiStackSerializer implements EmiStackSerializer<ItemEmiStack> {

	@Override
	public String getType() {
		return "item";
	}

	@Override
	public EmiStack create(class_2960 id, class_9326 componentChanges, long amount) {
		class_1799 stack = new class_1799(EmiPort.getItemRegistry().method_10223(id).orElseThrow(), 1, componentChanges);
		return EmiStack.of(stack, amount);
	}
}
