package dev.emi.emi.stack.serializer;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.FluidEmiStack;
import dev.emi.emi.api.stack.serializer.EmiStackSerializer;
import net.minecraft.class_2960;
import net.minecraft.class_9326;

public class FluidEmiStackSerializer implements EmiStackSerializer<FluidEmiStack> {

	@Override
	public String getType() {
		return "fluid";
	}

	@Override
	public EmiStack create(class_2960 id, class_9326 componentChanges, long amount) {
		return EmiStack.of(EmiPort.getFluidRegistry().method_63535(id), componentChanges, amount);
	}
}
