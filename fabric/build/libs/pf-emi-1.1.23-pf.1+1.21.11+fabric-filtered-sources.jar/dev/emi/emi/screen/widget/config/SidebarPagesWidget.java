package dev.emi.emi.screen.widget.config;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5684;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.config.SidebarPages;
import dev.emi.emi.config.SidebarType;
import dev.emi.emi.screen.ConfigScreen.Mutator;

public class SidebarPagesWidget extends ConfigEntryWidget {
	private List<class_4185> buttons = Lists.newArrayList();
	private Mutator<SidebarPages> mutator;

	public SidebarPagesWidget(class_2561 name, List<class_5684> tooltip, Supplier<String> search, Mutator<SidebarPages> mutator) {
		super(name, tooltip, search, 0);
		this.mutator = mutator;
		setChildren(buttons);
		updateButtons();
	}

	public void updateButtons() {
		buttons.clear();
		SidebarPages pages = mutator.get();
		for (int i = 0; i < pages.pages.size(); i++) {
			final int j = i;
			SidebarPages.SidebarPage page = pages.pages.get(i);
			buttons.add(EmiPort.newButton(0, 0, 194, 20, page.type.getText(), b -> {
				EnumWidget.page(page.type, t -> pages.canShowChess() || t != SidebarType.CHESS, t -> {
					pages.pages.get(j).type = (SidebarType) t;
					pages.unique();
				});
			}));
		}
		buttons.add(EmiPort.newButton(0, 0, 20, 20, EmiPort.literal("+"), b -> {
			EnumWidget.page(SidebarType.INDEX, t -> pages.canShowChess() || t != SidebarType.CHESS, t -> {
				pages.pages.add(new SidebarPages.SidebarPage((SidebarType) t));
				pages.unique();
			});
		}));
	}

	@Override
	public void update(int y, int x, int width, int height) {
		int h = 0;
		for (int i = 0; i < buttons.size() - 1; i++) {
			class_4185 button = buttons.get(i);
			button.field_22760 = x + width - 218;
			button.field_22761 = y + h;
			h += 24;
		}
		class_4185 button = buttons.get(buttons.size() - 1);
		button.field_22760 = x + width - 20;
		button.field_22761 = y;
	}

	@Override
	public int getHeight() {
		if (!isVisible() || !isParentVisible()) {
			return 0;
		}
		if (buttons.size() == 1) {
			return 20;
		}
		return buttons.size() * 24 - 28;
	}
}
