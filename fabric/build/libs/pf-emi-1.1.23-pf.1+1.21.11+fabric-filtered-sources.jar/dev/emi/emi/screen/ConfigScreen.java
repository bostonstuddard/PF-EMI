package dev.emi.emi.screen;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1074;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5348;
import net.minecraft.class_5684;
import org.lwjgl.glfw.GLFW;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.render.EmiTooltipComponents;
import dev.emi.emi.com.unascribed.qdcss.QDCSS;
import dev.emi.emi.config.ConfigEnum;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.EmiConfig.Comment;
import dev.emi.emi.config.EmiConfig.ConfigGroup;
import dev.emi.emi.config.EmiConfig.ConfigGroupEnd;
import dev.emi.emi.config.EmiConfig.ConfigValue;
import dev.emi.emi.config.IntGroup;
import dev.emi.emi.config.ScreenAlign;
import dev.emi.emi.config.SidebarPages;
import dev.emi.emi.config.SidebarSubpanels;
import dev.emi.emi.input.EmiBind;
import dev.emi.emi.input.EmiBind.ModifiedKey;
import dev.emi.emi.input.EmiInput;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.widget.SizedButtonWidget;
import dev.emi.emi.screen.widget.config.BooleanWidget;
import dev.emi.emi.screen.widget.config.ConfigEntryWidget;
import dev.emi.emi.screen.widget.config.ConfigJumpButton;
import dev.emi.emi.screen.widget.config.ConfigSearch;
import dev.emi.emi.screen.widget.config.EmiBindWidget;
import dev.emi.emi.screen.widget.config.EmiNameWidget;
import dev.emi.emi.screen.widget.config.EnumWidget;
import dev.emi.emi.screen.widget.config.GroupNameWidget;
import dev.emi.emi.screen.widget.config.IntGroupWidget;
import dev.emi.emi.screen.widget.config.IntWidget;
import dev.emi.emi.screen.widget.config.ListWidget;
import dev.emi.emi.screen.widget.config.ScreenAlignWidget;
import dev.emi.emi.screen.widget.config.SidebarPagesWidget;
import dev.emi.emi.screen.widget.config.SidebarSubpanelsWidget;
import dev.emi.emi.screen.widget.config.SubGroupNameWidget;
import dev.emi.emi.search.EmiSearch;

public class ConfigScreen extends class_437 {
	private static final int maxWidth = 240;
	private class_437 last;
	private ConfigSearch search;
	public ListWidget list;
	public EmiBind activeBind;
	public int activeBindOffset;
	public int activeModifiers;
	public int lastModifier;
	public String originalConfig;
	public class_4185 resetButton;

	public ConfigScreen(class_437 last) {
		super(EmiPort.translatable("screen.emi.config"));
		this.last = last;
		originalConfig = EmiConfig.getSavedConfig();
	}

	public void setActiveBind(EmiBind bind, int offset) {
		activeBind = bind;
		activeBindOffset = offset;
		activeModifiers = 0;
		lastModifier = 0;
	}

	@Override
	public void method_25419() {
		EmiConfig.writeConfig();
		EmiSearch.update();
		class_310.method_1551().method_1507(last);
	}

	@SuppressWarnings("unchecked")
	public static List<class_5684> getFieldTooltip(Field field) {
		List<class_5684> text;
		ConfigValue annot = field.getAnnotation(ConfigValue.class);
		String key = "config.emi.tooltip." + annot.value().replace('-', '_');
		Comment comment = field.getAnnotation(Comment.class);
		if (class_1074.method_4663(key)) {
			text = (List<class_5684>) (Object) Arrays.stream(class_1074.method_4662(key).split("\n"))
				.map(EmiPort::literal).map(EmiTooltipComponents::of).toList();
		} else if (comment != null) {
			text = (List<class_5684>) (Object) Arrays.stream(comment.value().split("\n"))
				.map(EmiPort::literal).map(EmiTooltipComponents::of).toList();
		} else {
			text = null;
		}
		if (text == null) {
			return List.of();
		}
		return text;
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void method_25426() {
		super.method_25426();

		// Persistent-ish state
		int scroll = 0;
		String query = "";
		Set<String> collapsed = Sets.newHashSet();
		if (list != null) {
			scroll = (int) list.getScrollAmount();
			query = search.getSearch();
			for (ListWidget.Entry e : list.method_25396()) {
				if (e instanceof GroupNameWidget g) {
					if (g.collapsed) {
						collapsed.add(g.text.getString());
					}
				}
			}
		}

		list = new ListWidget(field_22787, field_22789, field_22790, 40, field_22790 - 60);
		this.method_37060(new EmiNameWidget(field_22789 / 2, 16));
		int w = Math.min(400, field_22789 - 40) / 4 * 4;
		int x = (field_22789 - w) / 2;
		search = new ConfigSearch(x + 3, field_22790 - 51, w / 2 - 4, 18);
		this.method_37060(search.field);
		this.resetButton = EmiPort.newButton(x + 2, field_22790 - 30, w / 2 - 2, 20, EmiPort.translatable("gui.done"), button -> {
			EmiConfig.loadConfig(QDCSS.load("revert", originalConfig));
			class_310 client = class_310.method_1551();
			this.method_25423(client.method_22683().method_4486(), client.method_22683().method_4502());
		});
		this.method_37063(EmiPort.newButton(x + w / 2 + 2, field_22790 - 30, w / 2 - 2, 20, EmiPort.translatable("gui.done"), button -> {
			this.method_25419();
		}));
		this.method_37063(EmiPort.newButton(x + w / 2 + 2, field_22790 - 52, w / 2 - 24, 20, EmiPort.translatable("screen.emi.presets"), button -> {
			class_310 client = class_310.method_1551();
			client.method_1507(new ConfigPresetScreen(this));
		}));
		this.method_37063(new SizedButtonWidget(x + w - 20, field_22790 - 52, 20, 20, 164, 0, () -> true, widget -> {
			EmiConfig.setGlobalState(!EmiConfig.useGlobalConfig);
			ConfigScreen.this.method_25410(field_22789, field_22790);
		}, () -> (EmiConfig.useGlobalConfig ? 40 : 0), () -> {
			return (List<class_2561>) (Object) Arrays.stream(class_1074.method_4662("tooltip.emi.config.global").split("\n"))
				.map(s -> field_22787.field_1772.method_27527().method_27495(class_5348.method_29430(s), maxWidth, class_2583.field_24360))
				.flatMap(l -> l.stream()).map(v -> EmiPort.literal(v.getString())).toList();
		}));
		this.method_37063(resetButton);
		this.method_25429(search.field);

		try {
			String lastGroup = "";
			GroupNameWidget lastGroupWidget = null;
			ConfigGroup currentGroup = null;
			SubGroupNameWidget currentSubGroupWidget = null;
			Supplier<String> searchSupplier = () -> search.getSearch();
			for (Field field : EmiConfig.class.getFields()) {
				ConfigValue annot = field.getAnnotation(ConfigValue.class);
				if (annot != null) {
					String group = annot.value().split("\\.")[0];
					if (group.equals("persistent")) {
						continue;
					}
					if (!group.equals(lastGroup)) {
						lastGroup = group;
						class_2561 text = EmiPort.translatable("config.emi.group." + group.replace('-', '_'));
						lastGroupWidget = new GroupNameWidget(group, text);
						if (collapsed.contains(text.getString())) {
							lastGroupWidget.collapsed = true;
						}
						list.addEntry(lastGroupWidget);
					}
					ConfigGroup configGroup = field.getAnnotation(ConfigGroup.class);
					if (configGroup != null) {
						currentGroup = configGroup;
						class_2561 text = EmiPort.translatable("config.emi.group." + configGroup.value().replace('-', '_'));
						currentSubGroupWidget = new SubGroupNameWidget(configGroup.value(), text);
						if (collapsed.contains(text.getString())) {
							currentSubGroupWidget.collapsed = true;
						}
						currentSubGroupWidget.parent = lastGroupWidget;
						list.addEntry(currentSubGroupWidget);
					}
					Predicate<?> predicate = EmiConfig.FILTERS.getOrDefault(annot.value(), v -> true);
					class_2561 translation = EmiPort.translatable("config.emi." + annot.value().replace('-', '_'));
					ConfigEntryWidget entry = null;
					if (field.getType() == boolean.class) {
						entry = new BooleanWidget(translation, getFieldTooltip(field), searchSupplier, new Mutator<Boolean>() {

							public Boolean getValue() {
								try {
									return field.getBoolean(null);
								} catch(Exception e) {}
								return false;
							}

							public void setValue(Boolean value) {
								try {
									field.setBoolean(null, value);
								} catch (Exception e) {}
							}						
						});
					} else if (field.getType() == int.class) {
						entry = new IntWidget(translation, getFieldTooltip(field), searchSupplier, new Mutator<Integer>() {

							public Integer getValue() {
								try {
									return field.getInt(null);
								} catch(Exception e) {}
								return -1;
							}

							public void setValue(Integer value) {
								try {
									field.setInt(null, value);
								} catch (Exception e) {}
							}						
						});
					} else if (field.getType() == EmiBind.class) {
						entry = new EmiBindWidget(this, getFieldTooltip(field), searchSupplier, (EmiBind) field.get(null));
					} else if (field.getType() == ScreenAlign.class) {
						entry = new ScreenAlignWidget(translation, getFieldTooltip(field), searchSupplier, objectMutator(field));
					} else if (field.getType() == SidebarPages.class) {
						entry = new SidebarPagesWidget(translation, getFieldTooltip(field), searchSupplier, objectMutator(field));
					} else if (field.getType() == SidebarSubpanels.class) {
						entry = new SidebarSubpanelsWidget(translation, getFieldTooltip(field), searchSupplier, objectMutator(field));
					} else if (IntGroup.class.isAssignableFrom(field.getType())) {
						entry = new IntGroupWidget(translation, getFieldTooltip(field), searchSupplier, objectMutator(field));
					} else if (ConfigEnum.class.isAssignableFrom(field.getType())) {
						entry = new EnumWidget(translation, getFieldTooltip(field), searchSupplier, objectMutator(field), (Predicate<ConfigEnum>) predicate);
					}
					boolean endGroup = field.getAnnotation(ConfigGroupEnd.class) != null;
					if (entry != null) {
						entry.group = currentGroup;
						entry.endGroup = endGroup;
						list.addEntry(entry);
						if (lastGroupWidget != null) {
							lastGroupWidget.children.add(entry);
							entry.parentGroups.add(lastGroupWidget);
						}
						if (currentSubGroupWidget != null) {
							currentSubGroupWidget.children.add(entry);
							entry.parentGroups.add(currentSubGroupWidget);
						}
					}
					if (endGroup) {
						currentGroup = null;
						currentSubGroupWidget = null;
					}
				}
			}
		} catch (Exception e) {
			EmiLog.error("Error initializing config screen", e);
		}

        addJumpButtons(); // Add this before the list, or mouse events will be intercepted by the list
		this.method_25429(list);
		list.setScrollAmount(scroll);
		search.setText(query);
		updateChanges();
	}

	private void addJumpButtons() {
		List<String> jumps = Lists.newArrayList(
			"general", "general.search",
			"ui", "ui.left-sidebar", "ui.right-sidebar", "ui.top-sidebar", "ui.bottom-sidebar",
			"binds", "binds.crafts", "binds.cheats",
			"dev"
		);
		List<List<String>> removes = List.of(
			List.of("binds.cheats"),
			List.of("general.search"),
			List.of("ui.top-sidebar", "ui.bottom-sidebar"),
			List.of("binds.crafts"),
			List.of("ui.left-sidebar", "ui.right-sidebar")
		);
		int space = list.getLogicalHeight() - 10;
		for (List<String> r : removes) {
			if (jumps.size() * 16 > space) {
				jumps.removeAll(r);
			}
		}
		int y = 40 + (list.getLogicalHeight() - jumps.size() * 16) / 2;
		int u = 0, v = -16;
		for (String s : jumps) {
			boolean newGroup = !s.contains(".");
			if (newGroup) {
				v += 16;
				u = 0;
			} else {
				u += 16;
			}
			this.method_37063(new ConfigJumpButton(
				2 + (newGroup ? 0 : 8), y, u, v, w -> jump(s),
				List.of(EmiPort.translatable("config.emi.group." + s.replace('-', '_')))));
			y += 16;
		}
	}

	public void jump(String jump) {
		for (ListWidget.Entry e : list.method_25396()) {
			if (e instanceof ConfigEntryWidget c) {
				for (GroupNameWidget p : c.parentGroups) {
					if (p.id.equals(jump)) {
						list.centerScrollOn(e);
						return;
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	public <T> Mutator<T> objectMutator(Field field) {
		return new Mutator<T>() {
			public T getValue() {
				try {
					return (T) field.get(null);
				} catch(Exception e) {
					throw new RuntimeException(e);
				}
			}

			public void setValue(T en) {
				try {
					field.set(null, en);
				} catch(Exception e) {
					throw new RuntimeException(e);
				}
			}
		};
	}

	public void updateChanges() {
		// Split on the blank lines between config options
		String[] oLines = originalConfig.split("\n\n");
		String[] cLines = EmiConfig.getSavedConfig().split("\n\n");
		int different = 0;
		for (int i = 0; i < oLines.length; i++) {
			if (i >= cLines.length) {
				break;
			}
			if (!oLines[i].equals(cLines[i])) {
				different++;
			}
		}
		this.resetButton.field_22763 = different > 0;
		this.resetButton.method_25355(EmiPort.translatable("screen.emi.config.reset", different));
	}
	
	@Override
	public void method_25394(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		list.setScrollAmount(list.getScrollAmount());
        list.method_25394(context.raw(), mouseX, mouseY, delta);
		super.method_25394(context.raw(), mouseX, mouseY, delta);
		if (list.getHoveredEntry() != null) {
			EmiRenderHelper.drawTooltip(this, context, list.getHoveredEntry().getTooltip(mouseX, mouseY), mouseX, mouseY, Math.min(field_22789 / 2 - 16, maxWidth));
		}
	}

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (activeBind != null) {
            pushModifier(0);
            activeBind.setBind(activeBindOffset, new ModifiedKey(class_3675.class_307.field_1672.method_1447(click.method_74245()), activeModifiers));
            activeBind = null;
            return true;
        }
        return super.method_25402(click, doubled);
    }

	private void pushModifier(int lastModifier) {
		activeModifiers |= EmiInput.maskFromCode(this.lastModifier);
		this.lastModifier = lastModifier;
		activeModifiers &= ~EmiInput.maskFromCode(lastModifier);
	}

    @Override
	public boolean method_25404(class_11908 input) {
		if (activeBind != null) {
			if (EmiInput.maskFromCode(input.comp_4795()) != 0) {
				pushModifier(input.comp_4795());
			} else {
				pushModifier(0);
				if (input.method_74231()) {
					activeBind.setBind(activeBindOffset, new ModifiedKey(class_3675.field_16237, 0));
				} else {
					activeBind.setBind(activeBindOffset, new ModifiedKey(class_3675.class_307.field_1668.method_1447(input.comp_4795()), activeModifiers));
				}
				activeBind = null;
				updateChanges();
			}
			return true;
		} else {
			// Element nesting causes crashing for cycling, for some reason
			if (input.method_74236()) {
				return false;
			}
			if (super.method_25404(input)) {
				return true;
			}
			if (this.method_25399() instanceof class_342 tfw && tfw.method_25370()) {
				if (input.method_74231()) {
					EmiPort.focus(tfw, false);
					return true;
				}
			} else {
				if (input.method_74231()) {
					this.method_25419();
					return true;
				} else if (this.field_22787.field_1690.field_1822.method_1417(input)) {
					this.method_25419();
					return true;
				}
			}
		}
		return false;
	}

    @Override
	public boolean method_16803(class_11908 input) {
        int keyCode = input.comp_4795();
		if (activeBind != null) {
			activeModifiers &= ~EmiInput.maskFromCode(keyCode);
			if (keyCode == lastModifier) {
				activeBind.setBind(activeBindOffset, new ModifiedKey(class_3675.class_307.field_1668.method_1447(keyCode), activeModifiers));
				activeBind = null;
			}
			return true;
		}
		return super.method_16803(input);
	}

	@Override
	public boolean method_25422() {
		return false;
	}

	public abstract class Mutator<T> {
		protected abstract T getValue();
		protected abstract void setValue(T value);

		public T get() {
			return getValue();
		}

		public void set(T value) {
			setValue(value);
			updateChanges();
		}
	}
}
