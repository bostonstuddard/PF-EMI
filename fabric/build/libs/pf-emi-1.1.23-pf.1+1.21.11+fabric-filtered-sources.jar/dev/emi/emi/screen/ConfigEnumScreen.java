package dev.emi.emi.screen;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5684;
import org.lwjgl.glfw.GLFW;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.widget.config.EmiNameWidget;
import dev.emi.emi.screen.widget.config.ListWidget;

public class ConfigEnumScreen<T> extends class_437 {
	private final ConfigScreen last;
	private final List<Entry<T>> entries;
	private final Consumer<T> selection;
	private ListWidget list;

	public ConfigEnumScreen(ConfigScreen last, List<Entry<T>> entries, Consumer<T> selection) {
		super(EmiPort.translatable("screen.emi.config"));
		this.last = last;
		this.entries = entries;
		this.selection = selection;
	}

	@Override
	public void method_25426() {
		super.method_25426();
		this.method_37060(new EmiNameWidget(field_22789 / 2, 16));
		int w = 200;
		int x = (field_22789 - w) / 2;
		this.method_37063(EmiPort.newButton(x, field_22790 - 30, w, 20, EmiPort.translatable("gui.done"), button -> {
			method_25419();
		}));
		list = new ListWidget(field_22787, field_22789, field_22790, 40, field_22790 - 40);
		for (Entry<T> e : entries) {
			list.addEntry(new SelectionWidget<T>(this, e));
		}
		this.method_25429(list);
	}

	@Override
	public void method_25394(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		list.setScrollAmount(list.getScrollAmount());
		super.method_25394(context.raw(), mouseX, mouseY, delta);
		list.method_25394(context.raw(), mouseX, mouseY, delta);
		ListWidget.Entry entry = list.getHoveredEntry();
		if (entry instanceof SelectionWidget<?> widget) {
			if (widget.button.method_49606()) {
				EmiRenderHelper.drawTooltip(this, context, widget.tooltip, mouseX, mouseY);
			}
		}
	}

	@Override
	public void method_25419() {
		class_310.method_1551().method_1507(last);
	}

    @Override
	public boolean method_25404(class_11908 input) {
		if (input.method_74231()) {
			this.method_25419();
			return true;
		} else if (this.field_22787.field_1690.field_1822.method_1417(input)) {
			this.method_25419();
			return true;
		} else if (input.method_74236()) {
			return false;
		}
		return super.method_25404(input);
	}

	public static record Entry<T>(T value, class_2561 name, List<class_5684> tooltip) {
	}

	public static class SelectionWidget<T> extends ListWidget.Entry {
		private final class_4185 button;
		private final List<class_5684> tooltip;

		public SelectionWidget(ConfigEnumScreen<T> screen, Entry<T> e) {
			button = EmiPort.newButton(0, 0, 200, 20, e.name(), t -> {
				screen.selection.accept(e.value());
				screen.method_25419();
			});
			tooltip = e.tooltip();
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of(button);
		}

		@Override
		public void render(class_332 raw, int index, int y, int x, int width, int height, int mouseX, int mouseY,
				boolean hovered, float delta) {
			button.field_22761 = y;
			button.field_22760 = x + width / 2 - button.method_25368() / 2;
			button.method_25394(raw, mouseX, mouseY, delta);
		}

		@Override
		public int getHeight() {
			return 20;
		}
	}
}
