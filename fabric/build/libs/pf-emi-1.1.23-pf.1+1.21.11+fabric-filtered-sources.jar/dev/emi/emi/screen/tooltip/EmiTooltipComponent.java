package dev.emi.emi.screen.tooltip;

import dev.emi.emi.EmiPort;
import dev.emi.emi.runtime.EmiDrawContext;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_918;

public interface EmiTooltipComponent extends class_5684 {

	default void drawTooltip(EmiDrawContext context, TooltipRenderData tooltip) {
	}

	default void drawTooltipText(TextRenderData text) {
	}

    @Override
    default void method_32666(class_327 textRenderer, int x, int y, int width, int height, class_332 raw) {
        EmiDrawContext context = EmiDrawContext.wrap(raw);
        context.push();
        context.matrices().translate(x, y/*, 0*/);
        class_310 client = class_310.method_1551();
        drawTooltip(context, new TooltipRenderData(textRenderer, client.method_1480(), x, y));
        context.pop();
    }

    @Override
    default void method_32665(class_332 raw, class_327 textRenderer, int x, int y) {
        EmiDrawContext context = EmiDrawContext.wrap(raw);
        context.push();
        context.matrices().translate(x, y/*, 0*/);
        drawTooltipText(new TextRenderData(context, textRenderer, x, y));
        context.pop();
    }

	public static class TextRenderData {
        private final EmiDrawContext context;
		public final class_327 renderer;
		public final int x, y;
		
		public TextRenderData(EmiDrawContext context, class_327 renderer, int x, int y) {
            this.context = context;
            this.renderer = renderer;
			this.x = x;
			this.y = y;
		}

		public void draw(String text, int x, int y, int color, boolean shadow) {
			draw(EmiPort.literal(text), x, y, color, shadow);
		}

		public void draw(class_2561 text, int x, int y, int color, boolean shadow) {
            if (shadow) {
                context.drawTextWithShadow(text, x, y, color);
            } else {
                context.drawText(text, x + this.x, y + this.y, color);
            }
		}
	}

	public static class TooltipRenderData {
		public final class_327 text;
		public final class_918 item;
		public final int x, y;

		public TooltipRenderData(class_327 text, class_918 item, int x, int y) {
			this.text = text;
			this.item = item;
			this.x = x;
			this.y = y;
		}
	}
}
