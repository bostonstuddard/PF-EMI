package dev.emi.emi.screen.tooltip;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;

public class EmiTooltip {
	public static final DecimalFormat TEXT_FORMAT = new DecimalFormat("0.##");
	
	public static class_5684 chance(String type, float chance) {
		return class_5684.method_32662(EmiPort.ordered(
			EmiPort.translatable("tooltip.emi.chance." + type,
				TEXT_FORMAT.format(chance * 100))
					.method_27692(class_124.field_1065)));
	}

	public static List<class_5684> splitTranslate(String key) {
		return Arrays.stream(class_1074.method_4662(key).split("\n"))
			.map(s -> class_5684.method_32662(EmiPort.ordered(EmiPort.literal(s)))).toList();
	}

	public static List<class_5684> splitTranslate(String key, Object... objects) {
		return Arrays.stream(class_1074.method_4662(key, objects).split("\n"))
			.map(s -> class_5684.method_32662(EmiPort.ordered(EmiPort.literal(s)))).toList();
	}
}
