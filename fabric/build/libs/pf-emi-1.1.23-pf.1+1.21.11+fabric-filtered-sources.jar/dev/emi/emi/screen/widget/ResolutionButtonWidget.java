package dev.emi.emi.screen.widget;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.widget.SlotWidget;
import dev.emi.emi.api.widget.Widget;
import dev.emi.emi.bom.BoM;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiHistory;
import dev.emi.emi.widget.RecipeDefaultButtonWidget;

public class ResolutionButtonWidget extends class_4185 {
	public Supplier<Widget> hoveredWidget;
	public EmiIngredient stack;

	public ResolutionButtonWidget(int x, int y, int width, int height, EmiIngredient stack, Supplier<Widget> hoveredWidget) {
		super(x, y, width, height, EmiPort.literal(""), button -> {
			BoM.tree.addResolution(stack, null);
			EmiHistory.pop();
		}, s -> s.get());
		this.stack = stack;
		this.hoveredWidget = hoveredWidget;
	}

    @Override
    protected void method_75752(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		int u = 0;
		if (this.method_49606()) {
			u = 18;
		} else {
			Widget widget = hoveredWidget.get();
			if ((widget instanceof SlotWidget slot && slot.getRecipe() != null)
					|| widget instanceof RecipeDefaultButtonWidget) {
				u = 36;
			}
		}
		EmiTexture.SLOT.render(context.raw(), field_22760, field_22761, delta);
		context.drawTexture(EmiRenderHelper.WIDGETS, field_22760, field_22761, u, 128, field_22758, field_22759);
		if (this.method_49606()) {
			class_310 client = class_310.method_1551();
			raw.method_51434(client.field_1772, List.of(
				EmiPort.translatable("tooltip.emi.resolution"),
				EmiPort.translatable("tooltip.emi.select_resolution"),
				EmiPort.translatable("tooltip.emi.default_resolution"),
				EmiPort.translatable("tooltip.emi.clear_resolution")
			), mouseX, mouseY);
		}
		stack.render(raw, field_22760 + 1, field_22761 + 1, delta);
    }

}
