package dev.emi.emi.screen.widget.config;

import dev.emi.emi.EmiPort;
import net.minecraft.class_1074;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_342;

public class ConfigSearch {
	public final ConfigSearchWidgetField field;

	public ConfigSearch(int x, int y, int width, int height) {
		class_310 client = class_310.method_1551();

		field = new ConfigSearchWidgetField(client.field_1772, x, y, width, height, EmiPort.literal(""));
		field.method_1863(s -> {
			if (s.length() > 0) {
				field.method_1887("");
			} else {
				field.method_1887(class_1074.method_4662("emi.search_config"));
			}
		});
		field.method_1887(class_1074.method_4662("emi.search_config"));
	}

	public void setText(String query) {
		field.method_1852(query);
	}

	public String getSearch() {
		return field.method_1882();
	}
	
	private class ConfigSearchWidgetField extends class_342 {

		public ConfigSearchWidgetField(class_327 textRenderer, int x, int y, int width, int height, class_2561 text) {
			super(textRenderer, x, y, width, height, text);
		}

        @Override
		public boolean method_25402(class_11909 click, boolean doubled) {
			if (click.method_74245() == 1 && method_25405(click.comp_4798(), click.comp_4799())) {
				this.method_1852("");
				EmiPort.focus(this, true);
				return true;
			}
            return super.method_25402(click, doubled);
		}
	}
}
