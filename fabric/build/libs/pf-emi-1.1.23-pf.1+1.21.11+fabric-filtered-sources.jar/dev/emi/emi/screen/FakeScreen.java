package dev.emi.emi.screen;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1799;
import net.minecraft.class_437;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.runtime.EmiLog;

public class FakeScreen extends class_437 {
	public static final FakeScreen INSTANCE = new FakeScreen();

	protected FakeScreen() {
		super(EmiPort.literal(""));
		this.field_22789 = Integer.MAX_VALUE;
		this.field_22790 = Integer.MAX_VALUE;
	}

	public List<class_5684> getTooltipComponentListFromItem(class_1799 stack) {
		List<class_5684> list = class_437.method_25408(field_22787, stack)
			.stream().map(EmiPort::ordered).map(class_5684::method_32662).collect(Collectors.toList());
		Optional<class_5632> data = stack.method_32347();
		if (data.isPresent()) {
			try {
				list.add(class_5684.method_32663(data.get()));
			} catch (Throwable e) {
				EmiLog.error("Exception converting TooltipComponent", e);
			}
		}
		return list;
	}
}
