package dev.emi.emi.screen;

import dev.emi.emi.EmiPort;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.runtime.EmiDrawContext;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;

public class DisabledToast implements class_368 {
	private static final class_2960 TEXTURE = EmiPort.id("toast/advancement");
// TODO
//	@Override
//	public Visibility draw(DrawContext raw, ToastManager manager, long time) {
//		EmiDrawContext context = EmiDrawContext.wrap(raw);
//		context.resetColor();
//		raw.drawGuiTexture(TEXTURE, 0, 0, this.getWidth(), this.getHeight());
//		context.drawCenteredText(EmiPort.translatable("emi.disabled"), getWidth() / 2, 7);
//		context.drawCenteredText(EmiConfig.toggleVisibility.getBindText(), getWidth() / 2, 18);
//		if (time > 8_000 || EmiConfig.enabled) {
//			return Visibility.HIDE;
//		}
//		return Visibility.SHOW;
//	}

    @Override
    public class_369 method_61988() {
//        EmiDrawContext context = EmiDrawContext.wrap(raw);
//        context.resetColor();
//        raw.drawGuiTexture(TEXTURE, 0, 0, this.getWidth(), this.getHeight());
//        context.drawCenteredText(EmiPort.translatable("emi.disabled"), getWidth() / 2, 7);
//        context.drawCenteredText(EmiConfig.toggleVisibility.getBindText(), getWidth() / 2, 18);
//        if (time > 8_000 || EmiConfig.enabled) {
//            return Visibility.HIDE;
//        }
        return class_369.field_2210;
    }

    @Override
    public void method_61989(class_374 manager, long time) {

    }

    @Override
    public void method_1986(class_332 context, class_327 textRenderer, long startTime) {
//        EmiDrawContext context = EmiDrawContext.wrap(raw);
//        context.resetColor();
//        raw.drawGuiTexture(TEXTURE, 0, 0, this.getWidth(), this.getHeight());
//        context.drawCenteredText(EmiPort.translatable("emi.disabled"), getWidth() / 2, 7);
//        context.drawCenteredText(EmiConfig.toggleVisibility.getBindText(), getWidth() / 2, 18);
//        if (time > 8_000 || EmiConfig.enabled) {
//            return Visibility.HIDE;
//        }
//        return Visibility.SHOW;
    }
}
