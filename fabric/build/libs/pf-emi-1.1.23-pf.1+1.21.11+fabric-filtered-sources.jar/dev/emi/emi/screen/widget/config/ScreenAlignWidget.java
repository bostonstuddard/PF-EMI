package dev.emi.emi.screen.widget.config;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.config.ScreenAlign;
import dev.emi.emi.screen.ConfigScreen.Mutator;

public class ScreenAlignWidget extends ConfigEntryWidget {
	private final Mutator<ScreenAlign> mutator;
	private class_4185 horizontal, vertical;

	public ScreenAlignWidget(class_2561 name, List<class_5684> tooltip, Supplier<String> search, Mutator<ScreenAlign> mutator) {
		super(name, tooltip, search, 20);
		this.mutator = mutator;

		horizontal = EmiPort.newButton(0, 0, 106, 20, getHorizontalText(), button -> {
			EnumWidget.page(mutator.get().horizontal, v -> true, c -> {
				mutator.get().horizontal = (ScreenAlign.Horizontal) c;
				mutator.set(mutator.get());
			});
		});
		vertical = EmiPort.newButton(0, 0, 106, 20, getVerticalText(), button -> {
			EnumWidget.page(mutator.get().vertical, v -> true, c -> {
				mutator.get().vertical = (ScreenAlign.Vertical) c;
				mutator.set(mutator.get());
			});
		});
		this.setChildren(List.of(horizontal, vertical));
	}

	public class_2561 getHorizontalText() {
		return mutator.get().horizontal.getText();
	}

	public class_2561 getVerticalText() {
		return mutator.get().vertical.getText();
	}

	@Override
	public void update(int y, int x, int width, int height) {
		horizontal.field_22760 = x + width - horizontal.method_25368() - vertical.method_25368() - 7;
		horizontal.field_22761 = y;
		vertical.field_22760 = x + width - vertical.method_25368();
		vertical.field_22761 = y;
	}
}
