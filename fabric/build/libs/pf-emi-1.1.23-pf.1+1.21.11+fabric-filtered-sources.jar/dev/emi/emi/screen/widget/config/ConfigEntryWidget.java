package dev.emi.emi.screen.widget.config;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5684;
import com.google.common.collect.Lists;

import dev.emi.emi.config.EmiConfig.ConfigGroup;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.widget.config.ListWidget.Entry;

public abstract class ConfigEntryWidget extends Entry {
	private final class_2561 name;
	private final List<class_5684> tooltip;
	protected final Supplier<String> search;
	private final int height;
	public ConfigGroup group;
	public boolean endGroup = false;
	private List<? extends class_364> children = List.of();
	public List<GroupNameWidget> parentGroups = Lists.newArrayList();
	
	public ConfigEntryWidget(class_2561 name, List<class_5684> tooltip, Supplier<String> search, int height) {
		this.name = name;
		this.tooltip = tooltip;
		this.search = search;
		this.height = height;
	}

	public void setChildren(List<? extends class_364> children) {
		this.children = children;
	}

	public void update(int y, int x, int width, int height) {
	}

	@Override
	public void render(class_332 raw, int index, int y, int x, int width, int height, int mouseX, int mouseY,
			boolean hovered, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		if (group != null) {
			context.fill(x + 4, y + height / 2 - 1, 6, 2, 0xFFFFFFFF);
			if (endGroup) {
				context.fill(x + 2, y - 4, 2, height / 2 + 5, 0xFFFFFFFF);
			} else {
				context.fill(x + 2, y - 4, 2, height + 4, 0xFFFFFFFF);
			}
			x += 10;
			width -= 10;
		}
		update(y, x, width, height);
		context.fill(x, y, width, height, 0x66000000);
        // Color must be in AARRGGBB format
		context.drawTextWithShadow(this.name, x + 6, y + 10 - parentList.client.field_1772.field_2000 / 2, 0xFFFFFFFF);
		for (class_364 element : method_25396()) {
			if (element instanceof class_4068 drawable) {
				drawable.method_25394(context.raw(), mouseX, mouseY, delta);
			}
		}
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		return tooltip;
	}

	public String getSearchableText() {
		return name.getString();
	}

	public boolean isParentVisible() {
		for (GroupNameWidget g : parentGroups) {
			if (g.collapsed) {
				return false;
			}
		}
		return true;
	}

	public boolean isVisible() {
		String s = search.get().toLowerCase();
		if (getSearchableText().toLowerCase().contains(s)) {
			return true;
		}
		for (GroupNameWidget g : parentGroups) {
			if (g.text.getString().toLowerCase().contains(s)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int getHeight() {
		if (isParentVisible() && isVisible()) {
			return height;
		}
		return 0;
	}

	@Override
	public List<? extends class_364> method_25396() {
		return children;
	}
}
