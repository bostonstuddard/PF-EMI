package dev.emi.emi.screen.tooltip;

import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.mixin.accessor.OrderedTextTooltipComponentAccessor;
import net.minecraft.class_5481;
import net.minecraft.class_5683;

public class EmiTextTooltipWrapper extends class_5683 {
	public EmiIngredient stack;

	public EmiTextTooltipWrapper(EmiIngredient stack, class_5481 text) {
		super(text);
		this.stack = stack;
	}

	public EmiTextTooltipWrapper(EmiIngredient stack, class_5683 original) {
		super(((OrderedTextTooltipComponentAccessor) original).getText());
		this.stack = stack;
	}
}
