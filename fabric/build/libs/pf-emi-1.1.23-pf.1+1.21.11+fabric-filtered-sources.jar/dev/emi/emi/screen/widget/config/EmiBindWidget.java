package dev.emi.emi.screen.widget.config;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_5684;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.input.EmiBind;
import dev.emi.emi.input.EmiBind.ModifiedKey;
import dev.emi.emi.screen.ConfigScreen;

public class EmiBindWidget extends ConfigEntryWidget {
	private final ConfigScreen screen;
	private EmiBind bind;
	private List<class_4185> buttons = Lists.newArrayList();

	public EmiBindWidget(ConfigScreen screen, List<class_5684> tooltip, Supplier<String> search, EmiBind bind) {
		super(EmiPort.translatable(bind.translationKey), tooltip, search, 0);
		this.screen = screen;
		this.bind = bind;
		updateButtons();
		setChildren(buttons);
	}

	private void updateButtons() {
		buttons.clear();
		for (int i = 0; i < bind.boundKeys.size(); i++) {
			final int j = i;
			class_4185 widget = EmiPort.newButton(0, 0, 200, 20, bind.boundKeys.get(i).getKeyText(class_124.field_1070), button -> {
				screen.setActiveBind(bind, j);
			});
			buttons.add(widget);
		}
	}

	@Override
	public void update(int y, int x, int width, int height) {
		if (buttons.size() != bind.boundKeys.size()) {
			updateButtons();
		}
		int h = 0;
		for (int i = 0; i < buttons.size(); i++) {
			class_4185 button = buttons.get(i);
			button.field_22760 = x + width - 224;
			button.field_22761 = y + h;
			if (screen.activeBind == bind && screen.activeBindOffset == i) {
				button.method_25358(200);
				button.field_22760 = x + width - 224;
				if (screen.lastModifier == 0) {
					button.method_25355(EmiPort.literal("...", class_124.field_1054));
				} else {
					button.method_25355(new ModifiedKey(class_3675.class_307.field_1668
						.method_1447(screen.lastModifier), screen.activeModifiers)
						.getKeyText(class_124.field_1054));
				}
			} else if (i < bind.boundKeys.size()) {
				if (bind.boundKeys.get(i).isUnbound() && i > 0) {
					button.method_25358(20);
					button.field_22760 = x + width - 20;
					button.field_22761 = y;
					button.method_25355(EmiPort.literal("+", class_124.field_1075));
				} else {
					button.method_25355(bind.boundKeys.get(i).getKeyText(class_124.field_1070));
				}
			}
			h += 24;
		}
	}

	@Override
	public int getHeight() {
		if (!isVisible() || !isParentVisible()) {
			return 0;
		}
		int size = buttons.size() * 24;
		if (buttons.size() > 1 && buttons.size() <= bind.boundKeys.size() && bind.boundKeys.get(buttons.size() - 1).isUnbound()
				&& (screen.activeBind != bind || screen.activeBindOffset != buttons.size() - 1)) {
			size -= 24;
		}
		return size - 4;
	}
}
