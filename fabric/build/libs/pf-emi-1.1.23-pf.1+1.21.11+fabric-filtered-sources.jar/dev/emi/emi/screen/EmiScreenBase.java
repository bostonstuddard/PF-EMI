package dev.emi.emi.screen;

import com.google.common.collect.Lists;
import dev.emi.emi.api.EmiScreenBoundsProvider;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.mixin.accessor.HandledScreenAccessor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1703;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_518;

public class EmiScreenBase {

	private static final Map<Class<?>, List<EmiScreenBoundsProvider<?>>> PROVIDERS_BY_CLASS = new HashMap<>();
	private static final List<EmiScreenBoundsProvider<class_437>> GENERIC_PROVIDERS = new ArrayList<>();

	private final class_437 screen;
	private final Bounds bounds;

	private static final EmiScreenBase EMPTY = new EmiScreenBase(null, Bounds.EMPTY);

	private EmiScreenBase(class_437 screen, Bounds bounds) {
		this.screen = screen;
		this.bounds = bounds;
	}

	public class_437 screen() {
		return screen;
	}

	public Bounds bounds() {
		return bounds;
	}

	public boolean isEmpty() {
		return screen == null;
	}
	
	public static EmiScreenBase getCurrent() {
		class_310 client = class_310.method_1551();
		return of(client.field_1755);
	}

	public static <T extends class_437> void addScreenBoundsProvider(Class<T> clazz, EmiScreenBoundsProvider<T> provider) {
		PROVIDERS_BY_CLASS.computeIfAbsent(clazz, k -> Lists.newArrayList()).add(provider);
	}

	public static void addGenericScreenBoundsProvider(EmiScreenBoundsProvider<class_437> provider) {
		GENERIC_PROVIDERS.add(provider);
	}

	public static void clearScreenBoundsProviders() {
		PROVIDERS_BY_CLASS.clear();
		GENERIC_PROVIDERS.clear();
	}

	public static EmiScreenBase of(class_437 screen) {
		if (screen == null) {
			return EMPTY;
		}

		Class<?> screenClass = screen.getClass();
		List<EmiScreenBoundsProvider<?>> classProviders = PROVIDERS_BY_CLASS.get(screenClass);
		if (classProviders != null) {
			for (EmiScreenBoundsProvider<?> provider : classProviders) {
				@SuppressWarnings("unchecked")
				Bounds bounds = ((EmiScreenBoundsProvider<class_437>) provider).getBounds(screen);
				if (bounds != null && !bounds.empty()) {
					return new EmiScreenBase(screen, bounds);
				}
			}
		}
		for (EmiScreenBoundsProvider<class_437> provider : GENERIC_PROVIDERS) {
			Bounds bounds = provider.getBounds(screen);
			if (bounds != null && !bounds.empty()) {
				return new EmiScreenBase(screen, bounds);
			}
		}
		if (screen instanceof class_465 hs) {
			HandledScreenAccessor hsa = (HandledScreenAccessor) hs;
			class_1703 sh = hs.method_17577();
			if (sh.field_7761 != null && !sh.field_7761.isEmpty()) {
				int extra = 0;
				if (hs instanceof class_518 provider) {
//					if (provider.getRecipeBookWidget().isOpen()) {
//						extra = 177;
//					} TODO
				}
				Bounds bounds = new Bounds(hsa.getX() - extra, hsa.getY(), hsa.getBackgroundWidth() + extra, hsa.getBackgroundHeight());
				return new EmiScreenBase(screen, bounds);
			}
		} else if (screen instanceof RecipeScreen rs) {
			return new EmiScreenBase(rs, rs.getBounds());
		}
		return EMPTY;
	}
}
