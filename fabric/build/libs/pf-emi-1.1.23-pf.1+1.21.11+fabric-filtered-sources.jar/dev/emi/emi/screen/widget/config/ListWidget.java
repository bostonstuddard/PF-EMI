package dev.emi.emi.screen.widget.config;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_12249;
import net.minecraft.class_2561;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5684;
import net.minecraft.class_6379;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.vertex.VertexFormat;

import dev.emi.emi.EmiPort;

/**
 * Shamelessly modified vanilla lists to support variable width.
 * This is the lesser of two evils, at least this way I have vanilla compat.
 */
public class ListWidget extends class_362 implements class_4068, class_6379 {
	private static final class_2960 MENU_LIST_BACKGROUND_TEXTURE = EmiPort.id("minecraft", "textures/gui/menu_list_background.png");
	private static final class_2960 INWORLD_MENU_LIST_BACKGROUND_TEXTURE = EmiPort.id("minecraft", "textures/gui/inworld_menu_list_background.png");

	protected final class_310 client;
	private final List<Entry> children = Lists.newArrayList();
	protected int width;
	protected int height;
	protected int top;
	protected int bottom;
	protected int right;
	protected int left;
	private double scrollAmount;
	private boolean renderSelection = true;
	private boolean scrolling;
	private Entry selected;
	private Entry hoveredEntry;
	public int padding = 4;

	public ListWidget(class_310 client, int width, int height, int top, int bottom) {
		this.client = client;
		this.width = width;
		this.height = height;
		this.top = top;
		this.bottom = bottom;
		this.left = 0;
		this.right = width;
	}

	public void setRenderSelection(boolean renderSelection) {
		this.renderSelection = renderSelection;
	}

	public int getRowWidth() {
		return Math.min(400, width - 60);
	}

	public int getLogicalHeight() {
		return bottom - top;
	}

	@Nullable
	public Entry getSelectedOrNull() {
		return this.selected;
	}

	public void setSelected(@Nullable Entry entry) {
		this.selected = entry;
	}

	public final List<Entry> method_25396() {
		return this.children;
	}

	protected final void clearEntries() {
		this.children.clear();
	}

	protected void replaceEntries(Collection<Entry> newEntries) {
		this.children.clear();
		this.children.addAll(newEntries);
	}

	protected Entry getEntry(int index) {
		return this.method_25396().get(index);
	}

	public int addEntry(Entry entry) {
		this.children.add(entry);
		entry.parentList = this;
		return this.children.size() - 1;
	}

	protected int getEntryCount() {
		return this.method_25396().size();
	}

	protected boolean isSelectedEntry(int index) {
		return Objects.equals(this.getSelectedOrNull(), this.method_25396().get(index));
	}

	@Nullable
	protected final Entry getEntryAtPosition(double x, double y) {
		int rowWidth = this.getRowWidth() / 2;
		int mid = this.left + this.width / 2;
		int rowLeft = mid - rowWidth;
		int rowRight = mid + rowWidth;
		int m = class_3532.method_15357(y - (double)this.top) + (int)this.getScrollAmount() - 4;
		if (x < this.getScrollbarPositionX() && x >= rowLeft && x <= rowRight && m >= 0) {
			int h = 0;
			for (int i = 0; i < this.getEntryCount(); i++) {
				int eh = getEntryHeight(i);
				if (m >= h && m < h + eh - padding) {
					return this.getEntry(i);
				}
				h += eh;
			}
		}
		return null;
	}

	public void updateSize(int width, int height, int top, int bottom) {
		this.width = width;
		this.height = height;
		this.top = top;
		this.bottom = bottom;
		this.left = 0;
		this.right = width;
	}

	public void setLeftPos(int left) {
		this.left = left;
		this.right = left + this.width;
	}

	protected int getMaxPosition() {
		return this.getTotalHeight();
	}

	@Override
	public void method_25394(class_332 draw, int mouseX, int mouseY, float delta) {
		int o;
		int n;
		int m;
		int i = this.getScrollbarPositionX();
		int j = i + 6;
		class_289 tessellator = class_289.method_1348();
		class_287 bufferBuilder = tessellator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);
//		RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
		this.hoveredEntry = this.method_25405(mouseX, mouseY) ? this.getEntryAtPosition(mouseX, mouseY) : null;

		{	// Render background
//			RenderSystem.enableBlend();
			class_2960 identifier = this.client.field_1687 == null ? MENU_LIST_BACKGROUND_TEXTURE : INWORLD_MENU_LIST_BACKGROUND_TEXTURE;
			draw.method_25290(class_10799.field_56883, identifier, left, top, right, bottom + (int)scrollAmount, right - left, bottom - top, 32, 32);
//			RenderSystem.disableBlend();
		}

		draw.method_44379(left, top, right, bottom);
		int k = this.getRowLeft();
		int l = this.top + 4 - (int)this.getScrollAmount();
		this.renderList(draw, k, l, mouseX, mouseY, delta);
		draw.method_44380();


		{	// Render header & footer separators
//			RenderSystem.enableBlend();
			class_2960 identifier = this.client.field_1687 == null ? class_437.field_49895 : class_437.field_49897;
			class_2960 identifier2 = this.client.field_1687 == null ? class_437.field_49896 : class_437.field_49898;
			draw.method_25290(class_10799.field_56883, identifier, left, top - 2, 0.0F, 0.0F, width, 2, 32, 2);
			draw.method_25290(class_10799.field_56883, identifier2, left, bottom, 0.0F, 0.0F, width, 2, 32, 2);
//			RenderSystem.disableBlend();
		}

		if ((o = this.getMaxScroll()) > 0) {
//			RenderSystem.setShader(GameRenderer::getPositionColorProgram);
			m = (int)((float)((this.bottom - this.top) * (this.bottom - this.top)) / (float)this.getMaxPosition());
			m = class_3532.method_15340(m, 32, this.bottom - this.top - 8);
			n = (int)this.getScrollAmount() * (this.bottom - this.top - m) / o + this.top;
			if (n < this.top) {
				n = this.top;
			}
			bufferBuilder = tessellator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
			bufferBuilder.method_22912(i, this.bottom, 0).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(j, this.bottom, 0).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(j, this.top, 0).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(i, this.top, 0).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(i, n + m, 0).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(j, n + m, 0).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(j, n, 0).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(i, n, 0).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(i, n + m - 1, 0).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(j - 1, n + m - 1, 0).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(j - 1, n, 0).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(i, n, 0).method_1336(192, 192, 192, 255);
            class_12249.method_76023().method_60895(bufferBuilder.method_60800());
		}
//        RenderSystem.
//		RenderSystem.disableBlend();
	}

	public void centerScrollOn(Entry entry) {
		int i = 0;
		for (Entry e : this.method_25396()) {
			if (e == entry) {
				this.setScrollAmount(i - 42);
				return;
			}
			i += getEntryHeight(e);
		}
	}

	protected void ensureVisible(Entry entry) {
		int i = this.getRowTop(this.method_25396().indexOf(entry));
		int j = i - this.top - 4 - entry.getHeight();
		int k = this.bottom - i - entry.getHeight() * 2;
		if (j < 0) {
			this.scroll(j);
		}
		if (k < 0) {
			this.scroll(-k);
		}
	}

	private void scroll(int amount) {
		this.setScrollAmount(this.getScrollAmount() + (double)amount);
	}

	public double getScrollAmount() {
		return this.scrollAmount;
	}

	public void setScrollAmount(double amount) {
		this.scrollAmount = class_3532.method_15350(amount, 0.0, (double)this.getMaxScroll());
	}

	public int getMaxScroll() {
		return Math.max(0, this.getMaxPosition() - (this.bottom - this.top - 4) + 40);
	}

	protected void updateScrollingState(double mouseX, double mouseY, int button) {
		this.scrolling = button == 0 && mouseX >= (double)this.getScrollbarPositionX() && mouseX < (double)(this.getScrollbarPositionX() + 6);
	}

	protected int getScrollbarPositionX() {
		return this.width - 6;
	}

	public void unfocusTextField() {
		for (Entry e : this.children) {
			for (class_364 el : e.method_25396()) {
				if (el instanceof class_342 tfw) {
					EmiPort.focus(tfw, false);
				}
			}
		}
	}

	public class_342 getFocusedTextField() {
		for (Entry e : this.children) {
			for (class_364 el : e.method_25396()) {
				if (el instanceof class_342 tfw) {
					if (tfw.method_25370()) {
						return tfw;
					}
				}
			}
		}
		return null;
	}

    @Override
	public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

		this.updateScrollingState(mouseX, mouseY, button);
		/*
		for (Entry entry : this.children()) {
			if (entry.mouseClicked(mouseX, mouseY, button)) {
				this.setFocused((Element)entry);
				this.setDragging(true);
				return true;
			}
		}*/
		unfocusTextField();
		if (!this.method_25405(mouseX, mouseY)) {
			return false;
		}
		Entry entry = this.getEntryAtPosition(mouseX, mouseY);
		if (entry != null) {
			if (entry.method_25402(click, doubled)) {
				this.method_25395(entry);
				this.method_25398(true);
				return true;
			}
		}
		return this.scrolling;
	}

    @Override
	public boolean method_25406(class_11909 click) {
		if (this.method_25399() != null) {
			this.method_25399().method_25406(click);
		}
		return false;
	}

    @Override
	public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
		if (super.method_25403(click, deltaX, deltaY)) {
			return true;
		}
		if (click.method_74245() != 0 || !this.scrolling) {
			return false;
		}
		if (click.comp_4799() < (double)this.top) {
			this.setScrollAmount(0.0);
		} else if (click.comp_4799() > (double)this.bottom) {
			this.setScrollAmount(this.getMaxScroll());
		} else {
			double d = Math.max(1, this.getMaxScroll());
			int i = this.bottom - this.top;
			int j = class_3532.method_15340((int)((float)(i * i) / (float)this.getMaxPosition()), 32, i - 8);
			double e = Math.max(1.0, d / (double)(i - j));
			this.setScrollAmount(this.getScrollAmount() + deltaY * e);
		}
		return true;
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontal, double amount) {
		this.setScrollAmount(this.getScrollAmount() - amount * 22);
		return true;
	}

    @Override
	public boolean method_25404(class_11908 input) {
		if (super.method_25404(input)) {
			return true;
		}
		/*
		if (keyCode == GLFW.GLFW_KEY_DOWN) {
			this.moveSelection(MoveDirection.DOWN);
			return true;
		}
		if (keyCode == GLFW.GLFW_KEY_UP) {
			this.moveSelection(MoveDirection.UP);
			return true;
		}*/
		return false;
	}

	protected void moveSelection(MoveDirection direction) {
		this.moveSelectionIf(direction, entry -> true);
	}

	protected void ensureSelectedEntryVisible() {
		Entry entry = this.getSelectedOrNull();
		if (entry != null) {
			this.setSelected(entry);
			this.ensureVisible(entry);
		}
	}

	/**
	 * Moves the selection in the specified direction until the predicate returns true.
	 * 
	 * @param direction the direction to move the selection
	 */
	protected void moveSelectionIf(MoveDirection direction, Predicate<Entry> predicate) {
		int i = direction == MoveDirection.UP ? -1 : 1;
		if (!this.method_25396().isEmpty()) {
			int k;
			int j = this.method_25396().indexOf(this.getSelectedOrNull());
			while (j != (k = class_3532.method_15340(j + i, 0, this.getEntryCount() - 1))) {
				Entry entry = (Entry)this.method_25396().get(k);
				if (predicate.test(entry)) {
					this.setSelected(entry);
					this.ensureVisible(entry);
					break;
				}
				j = k;
			}
		}
	}

	@Override
	public boolean method_25405(double mouseX, double mouseY) {
		return mouseY >= (double)this.top && mouseY <= (double)this.bottom && mouseX >= (double)this.left && mouseX <= (double)this.right;
	}

	protected void renderList(class_332 draw, int x, int y, int mouseX, int mouseY, float delta) {
		int i = this.getEntryCount();
		class_289 tessellator = class_289.method_1348();
		class_287 bufferBuilder = tessellator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1592);
		for (int j = 0; j < i; ++j) {
			int p;
			int k = this.getRowTop(j);
			int l = this.getRowBottom(j);
			if (l < this.top || k > this.bottom) continue;
			int m = k;
			int n = getEntryHeight(j);
			if (n == 0) {
				continue;
			}
			n -= 4;
			Entry entry = this.getEntry(j);
			int o = this.getRowWidth();
			if (this.renderSelection && this.isSelectedEntry(j)) {
				p = this.left + this.width / 2 - o / 2;
				int q = this.left + this.width / 2 + o / 2;
//				RenderSystem.setShader(GameRenderer::getPositionProgram);
				float f = this.method_25370() ? 1.0f : 0.5f;
//				RenderSystem.setShaderColor(f, f, f, 1.0f);
				bufferBuilder.method_22912(p, m + n + 2, 0);
				bufferBuilder.method_22912(q, m + n + 2, 0);
				bufferBuilder.method_22912(q, m - 2, 0);
				bufferBuilder.method_22912(p, m - 2, 0);
                class_12249.method_76023().method_60895(bufferBuilder.method_60800());
//				RenderSystem.setShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
				bufferBuilder = tessellator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1592);
				bufferBuilder.method_22912(p + 1, m + n + 1, 0);
				bufferBuilder.method_22912(q - 1, m + n + 1, 0);
				bufferBuilder.method_22912(q - 1, m - 1, 0);
				bufferBuilder.method_22912(p + 1, m - 1, 0);
                class_12249.method_76023().method_60895(bufferBuilder.method_60800());
			}
			p = this.getRowLeft();
			((Entry)entry).render(draw, j, k, p, o - 3, n, mouseX, mouseY, Objects.equals(this.hoveredEntry, entry), delta);
		}
	}

	public int getRowLeft() {
		return this.left + this.width / 2 - this.getRowWidth() / 2 + 2;
	}

	public int getRowRight() {
		return this.getRowLeft() + this.getRowWidth();
	}

	private int getEntryHeight(int i) {
		return getEntryHeight(this.getEntry(i));
	}

	private int getEntryHeight(Entry entry) {
		int h = entry.getHeight();
		if (h == 0) {
			return 0;
		}
		return h + padding;
	}

	protected int getRowTop(int index) {
		int height = 0;
		for (int i = 0; i < index; i++) {
			height += getEntryHeight(i);
		}
		return this.top + 4 - (int)this.getScrollAmount() + height;
	}

	private int getRowBottom(int index) {
		return this.getRowTop(index) + this.getEntry(index).getHeight();
	}

	public boolean method_25370() {
		return false;
	}

	@Override
	public class_6379.class_6380 method_37018() {
		if (this.method_25370()) {
			return class_6379.class_6380.field_33786;
		}
		if (this.hoveredEntry != null) {
			return class_6379.class_6380.field_33785;
		}
		return class_6379.class_6380.field_33784;
	}

	@Nullable
	public Entry getHoveredEntry() {
		return this.hoveredEntry;
	}

	void setEntryParentList(Entry entry) {
		entry.parentList = this;
	}

	protected void appendNarrations(class_6382 builder, Entry entry) {
		int i;
		List<Entry> list = this.method_25396();
		if (list.size() > 1 && (i = list.indexOf(entry)) != -1) {
			builder.method_37034(class_6381.field_33789, (class_2561)EmiPort.translatable("narrator.position.list", i + 1, list.size()));
		}
	}

	public int getTotalHeight() {
		int height = 0;
		for (int i = 0; i < this.getEntryCount(); i++) {
			height += getEntryHeight(i);
		}
		if (height > 0) {
			height -= padding;
		}
		return height;
	}

	@Override
	public void method_37020(class_6382 var1) {
	}

	public static abstract class Entry extends class_362 {
		public ListWidget parentList;

		public abstract void render(class_332 draw, int index, int y, int x, int width, int height, int mouseX, int mouseY,
			boolean hovered, float delta);

		@Override
		public boolean method_25405(double mouseX, double mouseY) {
			return Objects.equals(this.parentList.getEntryAtPosition(mouseX, mouseY), this);
		}

		public List<class_5684> getTooltip(int mouseX, int mouseY) {
			return List.of();
		}

		public abstract int getHeight();
	}

	protected static enum MoveDirection {
		UP,
		DOWN;

	}
}