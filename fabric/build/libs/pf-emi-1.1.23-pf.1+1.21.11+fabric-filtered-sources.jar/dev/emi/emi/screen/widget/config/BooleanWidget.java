package dev.emi.emi.screen.widget.config;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.screen.ConfigScreen.Mutator;

public class BooleanWidget extends ConfigEntryWidget {
	private final Mutator<Boolean> mutator;
	private class_4185 button;

	public BooleanWidget(class_2561 name, List<class_5684> tooltip, Supplier<String> search, Mutator<Boolean> mutator) {
		super(name, tooltip, search, 20);
		this.mutator = mutator;

		button = EmiPort.newButton(0, 0, 150, 20, getText(), button -> {
			mutator.set(!mutator.get());
			button.method_25355(getText());
		});
		this.setChildren(List.of(button));
	}

	public class_2561 getText() {
		if (mutator.get()) {
			return EmiPort.literal("true", class_124.field_1060);
		} else {
			return EmiPort.literal("false", class_124.field_1061);
		}
	}

	@Override
	public void update(int y, int x, int width, int height) {
		button.field_22760 = x + width - button.method_25368();
		button.field_22761 = y;
	}
}
