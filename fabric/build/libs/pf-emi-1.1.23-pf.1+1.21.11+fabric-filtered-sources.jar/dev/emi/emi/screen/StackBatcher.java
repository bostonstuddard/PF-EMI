package dev.emi.emi.screen;


import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1058;
import net.minecraft.class_12249;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_777;
import net.minecraft.class_8251;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.runtime.EmiLog;

/**
 * @author Una "unascribed" Thompson
 */
public class StackBatcher {
	private static MethodHandle sodiumSpriteHandle;

	static {
		try {
			Class<?> clazz = null;
			try {
				// Try Sodium 0.5 name
				clazz = Class.forName("me.jellysquid.mods.sodium.client.render.texture.SpriteUtil");
			} catch (Throwable t) {
			}
			sodiumSpriteHandle = MethodHandles.lookup()
				.findStatic(clazz, "markSpriteActive", MethodType.methodType(void.class, class_1058.class));
			if (sodiumSpriteHandle != null) {
				EmiLog.info("Discovered Sodium");
			}
		} catch (Throwable e) {
		}
	}

	public interface Batchable {
		boolean isSideLit();
		boolean isUnbatchable();
		void setUnbatchable();
		void renderForBatch(class_4597 vcp, class_332 draw, int x, int y, int z, float delta);
	}

	private final BatcherVertexConsumerProvider imm;
	private final class_4597 unlitFacade;
	private final Map<class_1921, GpuBuffer> buffers = new LinkedHashMap<>();
	private final Set<class_1058> spritesToUpdate = Sets.newHashSet();
	private boolean populated = false;
	private boolean dirty = false;
	private int x;
	private int y;
	private int z;

	public static final List<class_1921> EXTRA_RENDER_LAYERS = Lists.newArrayList();

	public static boolean isEnabled() {
		return EmiConfig.useBatchedRenderer;
	}

	public StackBatcher() {
		Map<class_1921, class_9799> buffers = new HashMap<>();
		assign(buffers, class_12249.method_75965());
		assign(buffers, class_12249.method_75972());
//		assign(buffers, RenderLayer.getTranslucent());
		assign(buffers, class_4722.method_24073());
		assign(buffers, class_4722.method_24074());
//		assign(buffers, TexturedRenderLayers.getEntityTranslucentCull());
		assign(buffers, class_12249.method_75995());
		//assign(buffers, RenderLayer.getDirectGlint());
		assign(buffers, class_12249.method_75997());
		for (class_1921 layer : EXTRA_RENDER_LAYERS) {
			assign(buffers, layer);
		}
		imm = new BatcherVertexConsumerProvider(new class_9799(256), buffers);
		unlitFacade = new UnlitFacade(imm);
	}

	private void assign(Map<class_1921, class_9799> buffers, class_1921 layer) {
		buffers.put(layer, new class_9799(layer.method_22722()));
	}

	public boolean isPopulated() {
		return populated;
	}

	public void repopulate() {
		dirty = true;
	}

	public void begin(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
		if (dirty) {
			populated = false;
			dirty = false;
			spritesToUpdate.clear();
		}
	}

	public void render(Batchable batchable, class_332 draw, int x, int y, float delta) {
		if (!populated) {
			try {
				batchable.renderForBatch(batchable.isSideLit() ? imm : unlitFacade, draw, x-this.x, y+this.y, z, delta);
			} catch (Throwable t) {
				if (EmiConfig.devMode) {
					EmiLog.error("Batchable threw exception during batched rendering. See log for info", t);
				}
				batchable.setUnbatchable();
			}
		}
	}

	public void render(EmiIngredient stack, class_332 draw, int x, int y, float delta) {
		render(stack, draw, x, y, delta, ~EmiIngredient.RENDER_AMOUNT);
	}

	public void render(EmiIngredient stack, class_332 draw, int x, int y, float delta, int flags) {
		if (stack instanceof Batchable b && !b.isUnbatchable() && isEnabled() && (flags & EmiIngredient.RENDER_ICON) != 0) {
			if (!populated) {
				try {
					b.renderForBatch(b.isSideLit() ? imm : unlitFacade, draw, x-this.x, y + this.y, z, delta);
					if (sodiumSpriteHandle != null && !stack.isEmpty()) {
						class_1799 is = stack.getEmiStacks().getFirst().getItemStack();
						class_310 client = class_310.method_1551();
//						BakedModel model = client.getItemRenderer().getModels().getModel(is);
//						if (model != null) {
//							List<BakedQuad> quads = EmiPort.getQuads(model);
//							for (BakedQuad quad : quads) {
//								if (quad != null) {
//									spritesToUpdate.add(quad.sprite());
//								}
//							}
//						}
					}
				} catch (Throwable t) {
					if (EmiConfig.devMode) {
						EmiLog.error("Stack threw exception during batched rendering. See log for info", t);
					}
					b.setUnbatchable();
				}
			}
			stack.render(draw, x, y, delta, flags & (~EmiIngredient.RENDER_ICON));
		} else {
			stack.render(draw, x, y, delta, flags);
		}
	}

	public void draw() {
		if (!isEnabled()) {
			return;
		}
		if (sodiumSpriteHandle != null) {
			try {
				for (class_1058 sprite : spritesToUpdate) {
					sodiumSpriteHandle.invoke(sprite);
				}
			} catch (Throwable t) {
			}
		}
		if (!populated) {
			bake();
			populated = true;
		}
//		RenderSystem.enableDepthTest();
//		DiffuseLighting.enableGuiDepthLighting();
		Matrix4f mat = new Matrix4f(RenderSystem.getModelViewMatrix());
		mat.mul(new Matrix4f().translation(x, y, 0));
		for (Map.Entry<class_1921, GpuBuffer> en : buffers.entrySet()) {
//			en.getKey().startDrawing();
//			EmiPort.setShader(en.getValue(), mat);
//			en.getKey().endDrawing();
		}
//		BufferRenderer.reset();
	}
	
	private void bake() {
		imm.drawCurrentLayer();
//		buffers.values().forEach(VertexBuffer::close);
		buffers.clear();
		for (Map.Entry<class_1921, class_287> entry : imm.getPendingLayerBuffers().entrySet()) {
			bake(entry.getKey(), entry.getValue());
		}
		imm.getPendingLayerBuffers().clear();
	}

	public void bake(class_1921 layer, class_287 bldr) {
//		BuiltBuffer builtBuffer = bldr.endNullable();
//		if (builtBuffer == null) {
//			return;
//		}
//		VertexBuffer vb = RenderSystem.get
//		vb.bind();
//		vb.upload(builtBuffer);
//		buffers.put(layer, vb);

//        try (BuiltBuffer builtBuffer = bldr.endNullable()) {
//            if (builtBuffer == null) {
//                return;
//            }
//
//            BuiltBuffer.Contents contents = builtBuffer.contents();
//            if (contents == null) return;
//
//            GpuBuffer vb = new GpuBuffer(
//                    GpuBuffer.Usage.DYNAMIC,
//                    contents.format(),
//                    contents.indexCount(),
//                    contents.vertexCount()
//            );
//
//            vb.bind();
//            vb.upload(contents);
//
//            buffers.put(layer, vb);
//        }
	}

	// Apparently BufferBuilder leaks memory in vanilla. Go figure
	public static class ClaimedCollection {
		private final Set<StackBatcher> claimed = Sets.newHashSet();
		private final List<StackBatcher> unclaimed = Lists.newArrayList();

		public StackBatcher claim() {
			synchronized (this) {
				StackBatcher batcher;
				if (unclaimed.isEmpty()) {
					batcher = new StackBatcher();
				} else {
					batcher = unclaimed.removeLast();
				}
				if (batcher == null) {
					batcher = new StackBatcher();
				}
				claimed.add(batcher);
				return batcher;
			}
		}

		public void unclaim(StackBatcher batcher) {
			synchronized (this) {
				claimed.remove(batcher);
				unclaimed.add(batcher);
			}
		}

		public void unclaimAll() {
			synchronized (this) {
                unclaimed.addAll(claimed);
				claimed.clear();
			}
		}
	}

	/*
	 * This class is mostly a copy of a 1.21 implementation of VertexConsumerProvider.Immediate
	 * The reimplementation allows compatibility with shader mods, as well as less hackery.
	 */
	private static class BatcherVertexConsumerProvider implements class_4597 {
		protected final class_9799 fallbackBuffer;
		protected final Map<class_1921, class_9799> layerBuffers;
		protected final Map<class_1921, class_287> pending = new HashMap<>();
		protected class_1921 currentLayer = null;

		protected BatcherVertexConsumerProvider(class_9799 fallbackBuffer, Map<class_1921, class_9799> layerBuffers) {
			this.fallbackBuffer = fallbackBuffer;
			this.layerBuffers = layerBuffers;
		}

		@Override
		public class_4588 method_73477(class_1921 renderLayer) {
			class_287 bufferBuilder = this.pending.get(renderLayer);

			if (bufferBuilder == null) {
				class_9799 allocator = this.layerBuffers.get(renderLayer);
				if (allocator != null) {
					// Dedicated layer buffer, we can make a new buffer builder safely
					bufferBuilder = new class_287(allocator, renderLayer.method_23033(), renderLayer.method_23031());
				} else {
					// Not dedicated, flush previous layer first
					if (this.currentLayer != null) {
						this.draw(this.currentLayer);
					}
					bufferBuilder = new class_287(this.fallbackBuffer, renderLayer.method_23033(), renderLayer.method_23031());
					this.currentLayer = renderLayer;
				}

				this.pending.put(renderLayer, bufferBuilder);
			}

			return bufferBuilder;
		}

		private class_9799 getBufferInternal(class_1921 layer) {
			return this.layerBuffers.getOrDefault(layer, this.fallbackBuffer);
		}

		public void drawCurrentLayer() {
			if (this.currentLayer != null) {
				class_1921 renderLayer = this.currentLayer;
				if (!this.layerBuffers.containsKey(renderLayer)) {
					this.draw(renderLayer);
				}
				this.currentLayer = null;
			}
		}

		public void draw(class_1921 layer) {
			class_9799 bufferAllocator = this.getBufferInternal(layer);
			boolean isSameAsCurrentLayer = Objects.equals(this.currentLayer, layer);
			if (!isSameAsCurrentLayer && bufferAllocator == this.fallbackBuffer) {
				return;
			}
			class_287 builder = this.pending.remove(layer);
			if (builder == null) {
				return;
			}
			class_9801 buffer = builder.method_60794();
			if (buffer != null) {
				// TODO: do we actually need to sort quads still?
				buffer.method_60819(bufferAllocator, class_8251.field_43361);
				layer.method_60895(buffer);
			}
			if (isSameAsCurrentLayer) {
				this.currentLayer = null;
			}
		}

		public Map<class_1921, class_287> getPendingLayerBuffers() {
			return pending;
		}
	}

	private static class UnlitFacade implements class_4597 {
		private final class_4597 delegate;
		private final IdentityHashMap<class_4588, class_4588> cache = new IdentityHashMap<>();

		public UnlitFacade(class_4597 delegate) {
			this.delegate = delegate;
		}

		@Override
		public class_4588 method_73477(class_1921 layer) {
			return cache.computeIfAbsent(delegate.method_73477(layer), Consumer::new);
		}

        private record Consumer(class_4588 delegate) implements class_4588 {

            @Override
            public class_4588 method_22914(float x, float y, float z) {
                delegate.method_22914(0, -1, 0); // this is the change
                return this;
            }

            @Override
            public class_4588 method_60831(class_4587.class_4665 matrix, float x, float y, float z) {
                delegate.method_60831(matrix, 0, -1, 0); // this is the change
                return this;
            }

            @Override
            public class_4588 method_61959(class_4587.class_4665 matrix, Vector3f vec) {
                delegate.method_60831(matrix, 0, -1, 0); // this is the change
                return this;
            }

            @Override
            public void method_23919(float x, float y, float z, int color, float u, float v, int overlay, int light,
                               float normalX, float normalY, float normalZ) {
                delegate.method_23919(x, y, z, color, u, v, overlay, light, 0, -1, 0); // this is the change
            }

            // all other methods are direct delegation

            @Override
            public class_4588 method_75298(float width) {
                delegate.method_75298(width);
                return this;
            }

            @Override
            public class_4588 method_22915(float red, float green, float blue, float alpha) {
                delegate.method_22915(red, green, blue, alpha);
                return this;
            }

            @Override
            public class_4588 method_60803(int uv) {
                delegate.method_60803(uv);
                return this;
            }

            @Override
            public class_4588 method_22922(int uv) {
                delegate.method_22922(uv);
                return this;
            }

            @Override
            public void method_22919(class_4587.class_4665 matrixEntry, class_777 quad, float red, float green, float blue,
                             float alpha, int light, int overlay) {
                delegate.method_22919(matrixEntry, quad, red, green, blue, alpha, light, overlay);
            }

            @Override
            public void method_22920(class_4587.class_4665 matrixEntry, class_777 quad, float[] brightnesses, float red,
                             float green, float blue, float alpha, int[] lights, int overlay) {
                delegate.method_22920(matrixEntry, quad, brightnesses, red, green, blue, alpha, lights, overlay);
            }

            @Override
            public class_4588 method_60830(Vector3fc vec) {
                delegate.method_60830(vec);
                return this;
            }

            @Override
            public class_4588 method_61032(class_4587.class_4665 matrix, Vector3f vec) {
                delegate.method_61032(matrix, vec);
                return this;
            }

            @Override
            public class_4588 method_56824(class_4587.class_4665 matrix, float x, float y, float z) {
                delegate.method_56824(matrix, x, y, z);
                return this;
            }

            @Override
            public class_4588 method_22918(Matrix4fc matrix, float x, float y, float z) {
                delegate.method_22918(matrix, x, y, z);
                return this;
            }

            @Override
            public class_4588 method_70815(Matrix3x2fc matrix, float x, float y) {
                delegate.method_70815(matrix, x, y);
                return this;
            }

            @Override
            public class_4588 method_22912(float x, float y, float z) {
                delegate.method_22912(x, y, z);
                return this;
            }

            @Override
            public class_4588 method_22913(float u, float v) {
                delegate.method_22913(u, v);
                return this;
            }

            @Override
            public class_4588 method_60796(int u, int v) {
                delegate.method_60796(u, v);
                return this;
            }

            @Override
            public class_4588 method_22921(int u, int v) {
                delegate.method_22921(u, v);
                return this;
            }

            @Override
            public class_4588 method_1336(int r, int g, int b, int a) {
                delegate.method_1336(r, g, b, a);
                return this;
            }

            @Override
            public class_4588 method_39415(int argb) {
                delegate.method_39415(argb);
                return this;
            }
        }

    }

}
