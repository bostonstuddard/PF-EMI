package dev.emi.emi.screen.widget.config;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.widget.SizedButtonWidget;

public class ConfigJumpButton extends SizedButtonWidget {

	public ConfigJumpButton(int x, int y, int u, int v, class_4241 action, List<net.minecraft.class_2561> text) {
		super(x, y, 16, 16, u, v, () -> true, action, text);
		this.texture = EmiRenderHelper.CONFIG;
	}

	@Override
	protected int getV(int mouseX, int mouseY) {
		return this.v;
	}

    @Override
    protected void method_75752(class_332 raw, int mouseX, int mouseY, float delta) {
        EmiDrawContext context = EmiDrawContext.wrap(raw);

        int color = 0xFFFFFFFF;
        if (this.method_25405(mouseX, mouseY)) {
            color = 0xFF8099FF;
        }

//        context.enableDepthTest();
        context.drawTexture(texture, this.field_22760, this.field_22761, getU(mouseX, mouseY), getV(mouseX, mouseY), this.field_22758, this.field_22759, color);
        if (this.method_25405(mouseX, mouseY) && text != null && this.field_22763) {
            context.push();
//            context.matrices().translate(0, 0, 100);
//            context.disableDepthTest();
            class_310 client = class_310.method_1551();
            EmiRenderHelper.drawTooltip(client.field_1755, context, text.get().stream().map(EmiPort::ordered).map(class_5684::method_32662).toList(), mouseX, mouseY);
            context.pop();
        }
//        context.resetColor();
    }
}
