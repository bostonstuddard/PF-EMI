package dev.emi.emi.screen;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1109;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_5684;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.handler.EmiCraftContext;
import dev.emi.emi.api.recipe.handler.EmiRecipeHandler;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.RecipeFillButtonWidget;
import dev.emi.emi.api.widget.SlotWidget;
import dev.emi.emi.api.widget.Widget;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.SidebarSide;
import dev.emi.emi.input.EmiInput;
import dev.emi.emi.registry.EmiRecipeFiller;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiFavorite;
import dev.emi.emi.runtime.EmiHistory;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.widget.ResolutionButtonWidget;
import dev.emi.emi.screen.widget.SizedButtonWidget;

public class RecipeScreen extends class_437 {
	private static final class_2960 TEXTURE = EmiPort.id("emi", "textures/gui/background.png");
	public static @Nullable EmiIngredient resolve = null;
	private Map<EmiRecipeCategory, List<EmiRecipe>> recipes;
	public class_465<?> old;
	private List<RecipeTab> tabs = Lists.newArrayList();
	private int tabPageSize = 6;
	private int tabPage = 0, tab = 0, page = 0;
	private List<SizedButtonWidget> arrows;
	private List<WidgetGroup> currentPage = Lists.newArrayList();
	private int buttonOff = 0, tabOff = 0;
	private Widget hoveredWidget = null, pressedSlot = null;
	private ResolutionButtonWidget resolutionButton;
	private double scrollAcc = 0;
	private int minimumWidth = 176;
	int backgroundWidth = minimumWidth;
	int backgroundHeight = 200;
	int x = (this.field_22789 - backgroundWidth) / 2;
	int y = (this.field_22790 - backgroundHeight) / 2;

	public RecipeScreen(class_465<?> old, Map<EmiRecipeCategory, List<EmiRecipe>> recipes) {
		super(EmiPort.translatable("screen.emi.recipe"));
		this.old = old;
		arrows = List.of(
			new SizedButtonWidget(x + 2, y - 18, 12, 12, 0, 0,
				() -> tabs.size() > tabPageSize, w -> setPage(tabPage - 1, tab, page)),
			new SizedButtonWidget(x + backgroundWidth - 14, y - 18, 12, 12, 12, 0,
				() -> tabs.size() > tabPageSize, w -> setPage(tabPage + 1, tab, page)),
			new SizedButtonWidget(x + 5, y + 5, 12, 12, 0, 0,
				() -> tabs.size() > 1, w -> setPage(tabPage, tab - 1, 0)),
			new SizedButtonWidget(x + backgroundWidth - 17, y + 5, 12, 12, 12, 0,
				() -> tabs.size() > 1, w -> setPage(tabPage, tab + 1, 0)),
			new SizedButtonWidget(x + 5, y + 18, 12, 12, 0, 0,
				() -> tabs.get(tab).getPageCount() > 1, w -> setPage(tabPage, tab, page - 1)),
			new SizedButtonWidget(x + backgroundWidth - 17, y + 18, 12, 12, 12, 0,
				() -> tabs.get(tab).getPageCount() > 1, w -> setPage(tabPage, tab, page + 1))
		);
		resolve = null;
		this.recipes = recipes;
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		minimumWidth = Math.max(EmiConfig.minimumRecipeScreenWidth, 56);
		backgroundWidth = minimumWidth;
		backgroundHeight = Math.min(EmiConfig.maximumRecipeScreenHeight, field_22790 - 52 - EmiConfig.verticalMargin);
		x = (this.field_22789 - backgroundWidth) / 2;
		y = (this.field_22790 - backgroundHeight) / 2 + 1;
		this.tabPageSize = (minimumWidth - 32) / 24;
		
		for (SizedButtonWidget widget : arrows) {
			method_37063(widget);
		}
		EmiScreenManager.addWidgets(this);
		if (resolve != null) {
			resolutionButton = new ResolutionButtonWidget(x - 18, y + 10, 18, 18, resolve, () -> hoveredWidget);
			this.method_37063(resolutionButton);
		}
		if (recipes != null) {
			EmiRecipe current = null;
			if (tab < tabs.size() && page < tabs.get(tab).getPageCount() && tabs.get(tab).getPage(page).size() > 0) {
				current = tabs.get(tab).getPage(page).get(0).recipe;
			}
			tabs.clear();
			if (!recipes.isEmpty()) {
				for (Map.Entry<EmiRecipeCategory, List<EmiRecipe>> entry : recipes.entrySet().stream()
						.sorted((a, b) -> {
							int ai = EmiApi.getRecipeManager().getCategories().indexOf(a.getKey());
							int bi = EmiApi.getRecipeManager().getCategories().indexOf(b.getKey());
							if (ai < 0) {
								ai = Integer.MAX_VALUE;
							}
							if (bi < 0) {
								bi = Integer.MAX_VALUE;
							}
							return ai - bi;
						}).toList()) {
					List<EmiRecipe> set = entry.getValue();
					if (!set.isEmpty()) {
						RecipeTab tab = new RecipeTab(entry.getKey(), set);
						tab.bakePages(backgroundHeight);
						tabs.add(tab);
					}
				}
				
				tab = -1;
				setPage(tabPage, 0, 0);
			}
			//setPages(recipes);
			if (current != null) {
				focusRecipe(current);
			}
		}
		setRecipePageWidth(backgroundWidth);
	}

	private void setRecipePageWidth(int width) {
		if ((width & 1) == 1) {
			width++;
		}
		this.backgroundWidth = width;
		this.x = (this.field_22789 - backgroundWidth) / 2;
		this.buttonOff = (backgroundWidth - minimumWidth) / 2;
		int tabExtra = (minimumWidth - 32) % 24 / 2;
		this.tabOff = buttonOff + tabExtra;
		this.arrows.get(0).field_22760 = this.x + 2 + buttonOff + tabExtra;
		this.arrows.get(1).field_22760 = this.x + minimumWidth - 14 + buttonOff - tabExtra;
		this.arrows.get(2).field_22760 = this.x + 5 + buttonOff;
		this.arrows.get(3).field_22760 = this.x + minimumWidth - 17 + buttonOff;
		this.arrows.get(4).field_22760 = this.x + 5 + buttonOff;
		this.arrows.get(5).field_22760 = this.x + minimumWidth - 17 + buttonOff;

		this.arrows.get(0).field_22761 = this.y - 18;
		this.arrows.get(1).field_22761 = this.y - 18;
		this.arrows.get(2).field_22761 = this.y + 5;
		this.arrows.get(3).field_22761 = this.y + 5;
		this.arrows.get(4).field_22761 = this.y + 19;
		this.arrows.get(5).field_22761 = this.y + 19;
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public void method_25394(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		this.method_52752(context.raw());
		context.resetColor();
		EmiRenderHelper.drawNinePatch(context, TEXTURE, x, y, backgroundWidth, backgroundHeight, 0, 0, 4, 1);

		int tp = tabPage * tabPageSize;
		int off = 0;
		for (int i = tp; i < tabs.size() && i < tp + tabPageSize; i++) {
			RecipeTab tab = tabs.get(i);
			int sOff = (i == this.tab ? 2 : 0);
			EmiRenderHelper.drawNinePatch(context, TEXTURE, x + tabOff + off * 24 + 16, y - 24 - sOff, 24, 27 + sOff,
				i == this.tab ? 9 : 18, 0, 4, 1);
			tab.category.render(context.raw(), x + tabOff + off++ * 24 + 20, y - 20 - (i == this.tab ? 2 : 0), delta);
		}

		EmiRenderHelper.drawNinePatch(context, TEXTURE, x + 19 + buttonOff, y + 5, minimumWidth - 38, 12, 0, 16, 3, 6);
		//EmiRenderHelper.drawScroll(context, x + 19 + buttonOff, y + 5 + 10, minimumWidth - 38, 2, tab, tabs.size(), -1);
		EmiRenderHelper.drawNinePatch(context, TEXTURE, x + 19 + buttonOff, y + 19, minimumWidth - 38, 12, 0, 16, 3, 6);
		//EmiRenderHelper.drawScroll(context, x + 19 + buttonOff, y + 19 + 10, minimumWidth - 38, 2, page, tabs.get(tab).getPageCount(), -1);
		
		boolean categoryHovered = mouseX >= x + 19 + buttonOff && mouseY >= y + 5 && mouseX < x + minimumWidth + buttonOff - 19 && mouseY < y + 5 + 12;
		int categoryNameColor = categoryHovered ? 0xFF22FFFF : 0xFFFFFFFF;

		RecipeTab tab = tabs.get(this.tab);
		class_2561 text = tab.category.getName();
		if (field_22787.field_1772.method_27525(text) > minimumWidth - 40) {
			int extraWidth = field_22787.field_1772.method_1727("...");
			text = EmiPort.literal(field_22787.field_1772.method_1714(text, (minimumWidth - 40) - extraWidth).getString() + "...");
		}
		context.drawCenteredTextWithShadow(text, x + backgroundWidth / 2, y + 7, categoryNameColor);
		context.drawCenteredTextWithShadow(EmiRenderHelper.getPageText(this.page + 1, tab.getPageCount(), minimumWidth - 40),
			x + backgroundWidth / 2, y + 21, 0xFFFFFFFF);

		List<EmiIngredient> workstations = EmiApi.getRecipeManager().getWorkstations(tab.category);
		int workstationAmount = Math.min(workstations.size(), getMaxWorkstations());
		if (workstationAmount > 0 || resolve != null) {
			Bounds bounds = getWorkstationBounds(-1);
			int offset = getResolveOffset();
			if (workstationAmount <= 0) {
				offset = 18;
			}
			if (EmiConfig.workstationLocation == SidebarSide.LEFT) {
				EmiRenderHelper.drawNinePatch(context, TEXTURE, bounds.x() - 5, bounds.y() - 5, 28, 10 + 18 * workstationAmount + offset, 36, 0, 5, 1);
			} else if (EmiConfig.workstationLocation == SidebarSide.RIGHT) {
				EmiRenderHelper.drawNinePatch(context, TEXTURE, bounds.x() - 5, bounds.y() - 5, 28, 10 + 18 * workstationAmount + offset, 47, 0, 5, 1);
			} else if (EmiConfig.workstationLocation == SidebarSide.BOTTOM) {
				EmiRenderHelper.drawNinePatch(context, TEXTURE, bounds.x() - 5, bounds.y() - 5, 10 + 18 * workstationAmount + offset, 28, 58, 0, 5, 1);
			}
		}
		for (WidgetGroup group : currentPage) {
			int mx = mouseX - group.x();
			int my = mouseY - group.y();
			context.push();
			context.matrices().translate(group.x(), group.y()/*, 0*/);
//			EmiPort.applyModelViewMatrix();
			try {
				for (Widget widget : group.widgets) {
					widget.method_25394(context.raw(), mx, my, delta);
				}
			} catch (Throwable e) {
				EmiLog.error("Error rendering widget", e);
				group.error(e);
			}
			for (Widget widget : group.widgets) {
				if (widget instanceof RecipeFillButtonWidget) {
					if (widget.getBounds().contains(mx, my)) {
						class_465 hs = EmiApi.getHandledScreen();
						EmiRecipeHandler handler = EmiRecipeFiller.getFirstValidHandler(group.recipe, hs);
						if (handler != null) {
							handler.render(group.recipe, new EmiCraftContext(hs, handler.getInventory(hs), EmiCraftContext.Type.FILL_BUTTON), group.widgets, context.raw());
						} else if (EmiScreenManager.lastPlayerInventory != null) {
							StandardRecipeHandler.renderMissing(group.recipe, EmiScreenManager.lastPlayerInventory, group.widgets, context.raw());
						}
						break;
					}
				}
			}
			context.pop();
//			EmiPort.applyModelViewMatrix();
		}
		EmiScreenManager.drawBackground(context, mouseX, mouseY, delta);
		EmiScreenManager.render(context, mouseX, mouseY, delta);
		EmiScreenManager.drawForeground(context, mouseX, mouseY, delta);
		super.method_25394(context.raw(), mouseX, mouseY, delta);
		if (categoryHovered) {
			context.raw().method_51434(field_22787.field_1772, List.of(
				tab.category.getName(),
				EmiPort.translatable("emi.view_all_recipes")
			), mouseX, mouseY);
		}
		hoveredWidget = null;
		outer:
		for (WidgetGroup group : currentPage) {
			try {
				int mx = mouseX - group.x();
				int my = mouseY - group.y();
				for (Widget widget : group.widgets) {
					if (widget.getBounds().contains(mx, my)) {
						List<class_5684> tooltip = widget.getTooltip(mx, my);
						if (!tooltip.isEmpty()) {
							EmiRenderHelper.drawTooltip(this, context, tooltip, mouseX, mouseY);
							hoveredWidget = widget;
							break outer;
						}
					}
				}
			} catch (Throwable e) {
				EmiLog.error("Error rendering widget group", e);
				group.error(e);
			}
		}

		RecipeTab rTab = getTabAt(mouseX, mouseY);
		if (rTab != null) {
			EmiRenderHelper.drawTooltip(this, context, rTab.category.getTooltip(), mouseX, mouseY);
		}
	}

	@Override
	public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
		// Prevent double background draw
	}

	public EmiIngredient getHoveredStack() {
		if (hoveredWidget instanceof SlotWidget slot) {
			return slot.getStack();
		}
		return EmiStack.EMPTY;
	}

	public RecipeTab getTabAt(int mx, int my) {
		if (mx >= x + 16 + tabOff && mx < x + backgroundWidth && my >= y - 24 && my < y) {
			int n = (mx - x - 16 - tabOff) / 24 + tabPage * tabPageSize;
			if (n < tabs.size() && n >= tabPage * tabPageSize && n < (tabPage + 1) * tabPageSize) {
				return tabs.get(n);
			}
		}
		return null;
	}

	public int getMaxWorkstations() {
		return switch (EmiConfig.workstationLocation) {
			case LEFT, RIGHT -> (this.backgroundHeight - getResolveOffset() - 18) / 18; 
			case BOTTOM -> (this.backgroundWidth - getResolveOffset() - 18) / 18;
			default -> 0;
		};
	}

	public int getResolveOffset() {
		return resolve == null ? 0 : 23;
	}

	public Bounds getWorkstationBounds(int i) {
		int offset = 0;
		if (i == -1) {
			i = 0;
			offset = -getResolveOffset();
		}
		if (EmiConfig.workstationLocation == SidebarSide.LEFT) {
			return new Bounds(this.x - 18, this.y + 9 + getResolveOffset() + i * 18 + offset, 18, 18);
		} else if (EmiConfig.workstationLocation == SidebarSide.RIGHT) {
			return new Bounds(this.x + this.backgroundWidth, this.y + 9 + getResolveOffset() + i * 18 + offset, 18, 18);
		} else if (EmiConfig.workstationLocation == SidebarSide.BOTTOM) {
			return new Bounds(this.x + 5 + getResolveOffset() + i * 18 + offset, this.y + this.backgroundHeight - 23, 18, 18);
		}
		return Bounds.EMPTY;
	}

	public EmiRecipeCategory getFocusedCategory() {
		return tabs.get(tab).category;
	}

	public void focusCategory(EmiRecipeCategory category) {
		for (int i = 0; i < tabs.size(); i++) {
			if (tabs.get(i).category == category) {
				setPage(tabPage, i, 0);
				return;
			}
		}
	}

	public void focusRecipe(EmiRecipe recipe) {
		for (int i = 0; i < tabs.size(); i++) {
			RecipeTab tab = tabs.get(i);
			for (int j = 0; j < tab.getPageCount(); j++) {
				for (RecipeDisplay d : tab.getPage(j)) {
					if (d.recipe == recipe) {
						setPage(tabPage, i, j);
						return;
					}
				}
			}
		}
	}

	public void setPage(int tp, int t, int p) {
		currentPage.clear();
		if (tabs.isEmpty()) {
			return;
		}
		boolean snapTabPage = tp == tabPage && t != tab;
		tab = wrap(t, tabs.size());
		if (snapTabPage) {
			tp = (tab) / tabPageSize;
		}
		tabPage = wrap(tp, (tabs.size() - 1) / tabPageSize + 1);
		RecipeTab tab = tabs.get(this.tab);
		page = wrap(p, tab.getPageCount());
		if (page < tab.getPageCount()) {
			int width = Math.max(minimumWidth - 16, tab.getWidth());
			setRecipePageWidth(width + 16);
			currentPage = Lists.newArrayList();
			currentPage.addAll(tab.constructWidgets(page, x, y, backgroundWidth, backgroundHeight));
			List<EmiIngredient> workstations = EmiApi.getRecipeManager().getWorkstations(tab.category);
			if (!workstations.isEmpty()) {
				WidgetGroup widgets = new WidgetGroup(null, 0, 0, 0, 0);
				int maxWorkstations = getMaxWorkstations();
				for (int i = 0; i < workstations.size() && i < maxWorkstations; i++) {
					Bounds bounds = getWorkstationBounds(i);
					if (i == maxWorkstations - 1 && workstations.size() > maxWorkstations) {
						EmiIngredient ingredient = EmiIngredient.of(workstations.subList(i, workstations.size()));
						widgets.add(new SlotWidget(ingredient, bounds.x(), bounds.y()));
					} else {
						widgets.add(new SlotWidget(workstations.get(i), bounds.x(), bounds.y()));
					}
				}
				currentPage.add(widgets);
			}
		}
		if (resolve != null && resolutionButton != null) {
			Bounds bounds = getWorkstationBounds(-1);
			resolutionButton.field_22760 = bounds.x();
			resolutionButton.field_22761 = bounds.y();
		}
	}

	public int wrap(int value, int size) {
		if (value >= size) {
			return 0;
		} else if (value < 0) {
			return size - 1;
		}
		return value;
	}

    @Override
	public boolean method_25402(class_11909 click, boolean doubled) {
		int mx = (int) click.comp_4798();
		int my = (int) click.comp_4799();
		pressedSlot = null;
		if (click.comp_4798() >= x + 19 + buttonOff && click.comp_4799() >= y + 5 && click.comp_4798() < x + minimumWidth + buttonOff - 19 && click.comp_4799() <= y + 5 + 12) {
			EmiApi.displayAllRecipes();
			class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0f));
			return true;
		}
		for (WidgetGroup group : currentPage) {
			try {
				int ox = mx - group.x();
				int oy = my - group.y();
				boolean groupHovered = new Bounds(group.x(), group.y(), group.getWidth(), group.getHeight()).contains(mx, my);
				for (Widget widget : group.widgets) {
					if (widget.getBounds().contains(ox, oy)) {
						if (widget instanceof SlotWidget slot) {
							if (pressedSlot == null) {
								pressedSlot = widget;
							}
						} else {
							if (widget.mouseClicked(ox, oy, click.method_74245())) {
								return true;
							}
						}
						groupHovered = true;
					}
				}
				if (groupHovered && EmiScreenManager.recipeInteraction(group.recipe, bind -> bind.matchesMouse(click.method_74245()))) {
					return true;
				}
			} catch (Throwable e) {
				EmiLog.error("Error handling widget input", e);
				group.error(e);
			}
		}
		if (EmiScreenManager.mouseClicked(click, doubled)) {
			return true;
		}
		RecipeTab rTab = getTabAt(mx, my);
		if (rTab != null) {
			class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0f));
			focusCategory(rTab.category);
			return true;
		}
		return super.method_25402(click, doubled);
	}

    @Override
	public boolean method_25406(class_11909 click) {
		if (EmiScreenManager.mouseReleased(click)) {
			return true;
		}
		if (pressedSlot instanceof SlotWidget slot) {
			WidgetGroup group = getGroup(slot);
			if (group != null) {
				try {
					int ox = ((int) click.comp_4798()) - group.x();
					int oy = ((int) click.comp_4799()) - group.y();
					if (slot.getBounds().contains(ox, oy)) {
						if (slot.mouseClicked(ox, oy, click.method_74245())) {
							return true;
						}
					}
				} catch (Throwable e) {
					EmiLog.error("Error handling widget input", e);
					group.error(e);
				}
			}
			pressedSlot = null;
		}
		return super.method_25406(click);
	}

    @Override
	public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
		if (EmiScreenManager.mouseDragged(click, offsetX, offsetY)) {
			return true;
		}
		if (pressedSlot instanceof SlotWidget slot) {
			WidgetGroup group = getGroup(slot);
			if (group != null) {
				int ox = ((int) click.comp_4798()) - group.x();
				int oy = ((int) click.comp_4799()) - group.y();
				if (!slot.getBounds().contains(ox, oy) && click.method_74245() == 0) {
					EmiIngredient stack = slot.getStack();
					if (slot.getRecipe() != null) {
						stack = new EmiFavorite(stack, slot.getRecipe());
					}
					EmiScreenManager.pressedStack = stack;
					EmiScreenManager.draggedStack = stack;
					pressedSlot = null;
				}
			}
		}
		return super.method_25403(click, offsetX, offsetY);
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontal, double amount) {
		if (EmiScreenManager.mouseScrolled(mouseX, mouseY, amount)) {
			return true;
		} else if (mouseX > x && mouseX < x + backgroundWidth && mouseY < x + backgroundHeight) {
			scrollAcc += amount;
			int sa = (int) scrollAcc;
			scrollAcc %= 1;
			if (EmiInput.isShiftDown() || mouseY < this.y) {
				setPage(tabPage, tab - sa, 0);
			} else {
				setPage(tabPage, tab, page - sa);
			}
		}
		return super.method_25401(mouseX, mouseY, horizontal, amount);
	}

    @Override
	public boolean method_25400(class_11905 input) {
		if (EmiScreenManager.search.method_25400(input)) {
			return true;
		}
		return super.method_25400(input);
	}

    @Override
	public boolean method_25404(class_11908 input) {
		if (input.method_74231()) {
			this.method_25419();
			return true;
		} else if (EmiScreenManager.keyPressed(input)) {
			return true;
		} else if (this.field_22787.field_1690.field_1822.method_1417(input)) {
			this.method_25419();
			return true;
		}

		for (WidgetGroup group : currentPage) {
			try {
				int mx = EmiScreenManager.lastMouseX - group.x();
				int my = EmiScreenManager.lastMouseY - group.y();
				boolean groupHovered = new Bounds(group.x(), group.y(), group.getWidth(), group.getHeight()).contains(EmiScreenManager.lastMouseX, EmiScreenManager.lastMouseY);
				for (Widget widget : group.widgets) {
					if (widget.getBounds().contains(mx, my)) {
						if (widget.keyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797())) {
							return true;
						}
						groupHovered = true;
					}
				}
				if (groupHovered && EmiScreenManager.recipeInteraction(group.recipe, bind -> bind.matchesKey(input.comp_4795(), input.comp_4796()))) {
					return true;
				}
			} catch (Throwable e) {
				EmiLog.error("Error handling widget input", e);
				group.error(e);
			}
		}
		if (input.method_74232()) {
			setPage(tabPage, tab - 1, 0);
		} else if (input.method_74233()) {
			setPage(tabPage, tab + 1, 0);
		}
		return super.method_25404(input);
	}

	public WidgetGroup getGroup(Widget widget) {
		for (WidgetGroup group : currentPage) {
			if (group.widgets.contains(widget)) {
				return group;
			}
		}
		return null;
	}

	@Override
	public void method_25419() {
		EmiHistory.popUntil(s -> !(s instanceof RecipeScreen), old);
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	public Bounds getBounds() {
		int top = y - 26;
		int bottom = y + backgroundHeight;
		int left = x;
		int right = x + backgroundWidth;
		if (EmiConfig.workstationLocation == SidebarSide.LEFT) {
			left -= 22;
		} else if (EmiConfig.workstationLocation == SidebarSide.RIGHT) {
			right += 22;
		}
		return new Bounds(left, top, right - left, bottom - top);
	}
}
