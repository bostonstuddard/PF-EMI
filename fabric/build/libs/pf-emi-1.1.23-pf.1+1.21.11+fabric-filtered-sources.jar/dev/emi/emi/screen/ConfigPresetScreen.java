package dev.emi.emi.screen;

import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.com.unascribed.qdcss.QDCSS;
import dev.emi.emi.config.ConfigPresets;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.EmiConfig.ConfigGroup;
import dev.emi.emi.config.EmiConfig.ConfigValue;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.widget.config.EmiNameWidget;
import dev.emi.emi.screen.widget.config.ListWidget;

public class ConfigPresetScreen extends class_437 {
	private final ConfigScreen last;
	private ListWidget list;
	public class_4185 resetButton;

	public ConfigPresetScreen(ConfigScreen last) {
		super(EmiPort.translatable("screen.emi.presets"));
		this.last = last;
	}

	@Override
	public void method_25426() {
		super.method_25426();
		this.method_37060(new EmiNameWidget(field_22789 / 2, 16));
		int w = Math.min(400, field_22789 - 40);
		int x = (field_22789 - w) / 2;
		this.resetButton = EmiPort.newButton(x + 2, field_22790 - 30, w / 2 - 2, 20, EmiPort.translatable("gui.done"), button -> {
			EmiConfig.loadConfig(QDCSS.load("revert", last.originalConfig));
			class_310 client = class_310.method_1551();
			this.method_25423(client.method_22683().method_4486(), client.method_22683().method_4502());
		});
		this.method_37063(resetButton);
		this.method_37063(EmiPort.newButton(x + w / 2 + 2, field_22790 - 30, w / 2 - 2, 20, EmiPort.translatable("gui.done"), button -> {
			this.method_25419();
		}));
		list = new ListWidget(field_22787, field_22789, field_22790, 40, field_22790 - 40);
		try {
			for (Field field : ConfigPresets.class.getFields()) {
				ConfigValue config = field.getDeclaredAnnotation(ConfigValue.class);
				if (config != null) {
					if (field.get(null) instanceof Runnable runnable) {
						ConfigGroup group = field.getDeclaredAnnotation(ConfigGroup.class);
						if (group != null) {
							class_2561 translation = EmiPort.translatable("config.emi." + group.value().replace('-', '_'));
							list.addEntry(new PresetGroupWidget(translation));
						}
						class_2561 translation = EmiPort.translatable("config.emi." + config.value().replace('-', '_'));
						list.addEntry(new PresetWidget(runnable, translation, ConfigScreen.getFieldTooltip(field)));
					}
				}
			}
		} catch (Exception e) {
		}
		this.method_25429(list);
		updateChanges();
	}

	@Override
	public void method_25394(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		list.setScrollAmount(list.getScrollAmount());
//		this.renderDarkening(context.raw()); // This is confusing and makes the blur effect not work?
		list.method_25394(context.raw(), mouseX, mouseY, delta);
		super.method_25394(context.raw(), mouseX, mouseY, delta);
		if (list.getHoveredEntry() instanceof PresetWidget widget) {
			if (widget.button.method_49606()) {
				EmiRenderHelper.drawTooltip(this, context, widget.tooltip, mouseX, mouseY);
			}
		}
	}

//	@Override
//	public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
//		// Prevent double background draw
//	}

	@Override
	public void method_25419() {
		class_310.method_1551().method_1507(last);
	}

    @Override
	public boolean method_25404(class_11908 input) {
		if (input.method_74231()) {
			this.method_25419();
			return true;
		} else if (this.field_22787.field_1690.field_1822.method_1417(input)) {
			this.method_25419();
			return true;
		} else if (input.method_74236()) {
			return false;
		}
		return super.method_25404(input);
	}

	public void updateChanges() {
		// Split on the blank lines between config options
		String[] oLines = last.originalConfig.split("\n\n");
		String[] cLines = EmiConfig.getSavedConfig().split("\n\n");
		int different = 0;
		for (int i = 0; i < oLines.length; i++) {
			if (i >= cLines.length) {
				break;
			}
			if (!oLines[i].equals(cLines[i])) {
				different++;
			}
		}
		this.resetButton.field_22763 = different > 0;
		this.resetButton.method_25355(EmiPort.translatable("screen.emi.config.reset", different));
	}

	public class PresetWidget extends ListWidget.Entry {
		private final class_4185 button;
		private final List<class_5684> tooltip;

		public PresetWidget(Runnable runnable, class_2561 name, List<class_5684> tooltip) {
			button = EmiPort.newButton(0, 0, 200, 20, name, t -> {
				runnable.run();
				updateChanges();
			});
			this.tooltip = tooltip;
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of(button);
		}

		@Override
		public void render(class_332 raw, int index, int y, int x, int width, int height, int mouseX, int mouseY,
				boolean hovered, float delta) {
			button.field_22761 = y;
			button.field_22760 = x + width / 2 - button.method_25368() / 2;
			button.method_25394(raw, mouseX, mouseY, delta);
		}

		@Override
		public int getHeight() {
			return 20;
		}
	}

	public class PresetGroupWidget extends ListWidget.Entry {
		private final class_2561 text;

		public PresetGroupWidget(class_2561 text) {
			this.text = text;
		}

		@Override
		public List<? extends class_364> method_25396() {
			return List.of();
		}

		@Override
		public void render(class_332 raw, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean hovered, float delta) {
			EmiDrawContext context = EmiDrawContext.wrap(raw);
			context.drawCenteredTextWithShadow(text, x + width / 2, y + 3, -1);
		}

		@Override
		public int getHeight() {
			return 20;
		}
	}
}
