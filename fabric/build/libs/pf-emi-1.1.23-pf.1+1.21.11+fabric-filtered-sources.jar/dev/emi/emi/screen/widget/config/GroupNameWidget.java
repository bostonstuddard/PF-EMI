package dev.emi.emi.screen.widget.config;

import java.util.List;
import net.minecraft.class_1109;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_364;
import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.widget.config.ListWidget.Entry;

public class GroupNameWidget extends Entry {
	protected static final class_310 CLIENT = class_310.method_1551();
	public final String id;
	public final class_2561 text;
	public final List<ConfigEntryWidget> children = Lists.newArrayList();
	public boolean collapsed = false;

	public GroupNameWidget(String id, class_2561 text) {
		this.id = id;
		this.text = text;
	}

	@Override
	public void render(class_332 raw, int index, int y, int x, int width, int height, int mouseX, int mouseY,
			boolean hovered, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		context.drawCenteredTextWithShadow(text, x + width / 2, y + 3, -1);
		if (hovered || collapsed) {
			String collapse = "[-]";
			int cx = x + width / 2 - CLIENT.field_1772.method_27525(text) / 2 - 20;
			if (collapsed) {
				collapse = "[+]";
			}
			context.drawTextWithShadow(EmiPort.literal(collapse), cx, y + 3, -1);
		}
	}

	@Override
	public int getHeight() {
		for (ConfigEntryWidget w : children) {
			if (w.isVisible()) {
				return 20;
			}
		}
		return 0;
	}

    @Override
	public boolean method_25402(class_11909 click, boolean doubled) {
		if (method_25405(click.comp_4798(), click.comp_4799())) {
			collapsed = !collapsed;
			class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0f));
			return true;
		}
		return false;
	}

	@Override
	public List<? extends class_364> method_25396() {
		return List.of();
	}
}
