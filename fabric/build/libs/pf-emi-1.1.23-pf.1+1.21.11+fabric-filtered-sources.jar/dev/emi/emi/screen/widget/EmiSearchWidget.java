package dev.emi.emi.screen.widget;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1074;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_5250;
import net.minecraft.class_7833;
import org.joml.Matrix4fStack;
import org.lwjgl.glfw.GLFW;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.emi.emi.EmiPort;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.EmiScreenManager;
import dev.emi.emi.search.EmiSearch;
import dev.emi.emi.search.QueryType;

public class EmiSearchWidget extends class_342 {
	private static final Pattern ESCAPE = Pattern.compile("\\\\.");
	private List<String> searchHistory = Lists.newArrayList();
	private int searchHistoryIndex = 0;
	private List<class_3545<Integer, class_2583>> styles;
	private long lastClick = 0;
	private String last = "";
	private long lastRender = System.currentTimeMillis();
	private long accumulatedSpin = 0;
	public boolean highlight = false;
	// Reimplement focus because other mods keep breaking it
	public boolean isFocused;

	public EmiSearchWidget(class_327 textRenderer, int x, int y, int width, int height) {
		super(textRenderer, x, y, width, height, EmiPort.literal(""));
		this.method_1856(true);
		this.method_1868(-1);
		this.method_1860(-1);
		this.method_1880(256);
		this.method_73210((string, stringStart) -> {
			class_5250 text = null;
			int s = 0;
			int last = 0;
			for (; s < styles.size(); s++) {
				class_3545<Integer, class_2583> style = styles.get(s);
				int end = style.method_15442();
				if (end > stringStart) {
					if (end - stringStart >= string.length()) {
						text = EmiPort.literal(string.substring(0, string.length()), style.method_15441());
						// Skip second loop
						s = styles.size();
						break;
					}
					text = EmiPort.literal(string.substring(0, end - stringStart), style.method_15441());
					last = end - stringStart;
					s++;
					break;
				}
			}
			for (; s < styles.size(); s++) {
				class_3545<Integer, class_2583> style = styles.get(s);
				int end = style.method_15442();
				if (end - stringStart >= string.length()) {
					EmiPort.append(text, EmiPort.literal(string.substring(last, string.length()), style.method_15441()));
					break;
				}
				EmiPort.append(text, EmiPort.literal(string.substring(last, end - stringStart), style.method_15441()));
				last = end - stringStart;
			}
			return EmiPort.ordered(text);
		});
		this.method_1863(string -> {
			if (string.isEmpty()) {
				this.method_1887(class_1074.method_4662("emi.search"));
			} else {
				this.method_1887("");
			}
			EmiScreenManager.updateSearchSidebar();
			Matcher matcher = EmiSearch.TOKENS.matcher(string);
			List<class_3545<Integer, class_2583>> styles = Lists.newArrayList();
			int last = 0;
			while (matcher.find()) {
				int start = matcher.start();
				int end = matcher.end();
				if (last < start) {
					styles.add(new class_3545<Integer, class_2583>(start, class_2583.field_24360.method_27706(class_124.field_1068)));
				}
				String group = matcher.group();
				if (group.startsWith("-")) {
					styles.add(new class_3545<Integer, class_2583>(start + 1, class_2583.field_24360.method_27706(class_124.field_1061)));
					start++;
					group = group.substring(1);
				}
				QueryType type = QueryType.fromString(group);
				int subStart = type.prefix.length();
				if (group.length() > 1 + subStart && group.substring(subStart).startsWith("/") && group.endsWith("/")) {
					int rOff = start + subStart + 1;
					styles.add(new class_3545<Integer, class_2583>(rOff, type.slashColor));
					Matcher rMatcher = ESCAPE.matcher(string.substring(rOff, end - 1));
					int rLast = 0;
					while (rMatcher.find()) {
						int rStart = rMatcher.start();
						int rEnd = rMatcher.end();
						if (rLast < rStart) {
							styles.add(new class_3545<Integer, class_2583>(rStart + rOff, type.regexColor));
						}
						styles.add(new class_3545<Integer, class_2583>(rEnd + rOff, type.escapeColor));
						rLast = rEnd;
					}
					if (rLast < end - 1) {
						styles.add(new class_3545<Integer, class_2583>(end - 1, type.regexColor));
					}
					styles.add(new class_3545<Integer, class_2583>(end, type.slashColor));
				} else {
					styles.add(new class_3545<Integer, class_2583>(end, type.color));
				}

				last = end;
			}
			if (last < string.length()) {
				styles.add(new class_3545<Integer, class_2583>(string.length(), class_2583.field_24360.method_27706(class_124.field_1068)));
			}
			this.styles = styles;
			EmiSearch.search(string);
		});
	}

	public void update() {
		method_1852(method_1882());
	}

	public void swap() {
		String last = this.method_1882();
		this.method_1852(this.last);
		this.last = last;
	}

	@Override
	public void method_25365(boolean focused) {
		if (focused == isFocused) {
			return;
		}
		if (!focused) {
			searchHistoryIndex = 0;
			String currentSearch = method_1882();
			if (!currentSearch.isBlank() && !currentSearch.isEmpty()) {
				searchHistory.removeIf(String::isBlank);
				searchHistory.remove(currentSearch);
				searchHistory.add(0, currentSearch);
				if (searchHistory.size() > 36) {
					searchHistory.remove(searchHistory.size() - 1);
				}
			}
		}
		isFocused = focused;
		super.method_25365(focused);
		EmiScreenManager.updateSearchSidebar();
	}

	@Override
	public boolean method_25370() {
		return isFocused;
	}

    @Override
	public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

		if (!method_25405(mouseX, mouseY) || !EmiConfig.enabled) {
			EmiPort.focus(this, false);
			return false;
		} else {
            boolean b = super.method_25402(new class_11909(mouseX, mouseY, new class_11910(button == 1 ? 0 : button, click.comp_4797())), doubled);
            if (method_25405(mouseX, mouseY)) {
				EmiPort.focus(this, true);
			}
			if (this.method_25370()) {
				if (button == 0) {
					if (System.currentTimeMillis() - lastClick < 500) {
						highlight = !highlight;
						lastClick = 0;
					} else {
						lastClick = System.currentTimeMillis();
					}
				} else if (button == 1) {
					this.method_1852("");
					EmiPort.focus(this, true);
				}
			}
			return b;
		}
	}

    @Override
	public boolean method_25404(class_11908 input) {
        int keyCode = input.comp_4795();
        int scanCode = input.comp_4796();

		if (this.method_25370()) {
			if (EmiConfig.clearSearch.matchesKey(keyCode, scanCode)) {
				method_1852("");
				return true;
			}
			if ((EmiConfig.focusSearch.matchesKey(keyCode, scanCode)
					|| keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE)) {
				EmiPort.focus(this, false);
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN) {
				int offset = keyCode == GLFW.GLFW_KEY_UP ? 1 : -1;
				if (searchHistoryIndex + offset >= 0 && searchHistoryIndex + offset < searchHistory.size()) {
					if (searchHistoryIndex >= 0 && searchHistoryIndex < searchHistory.size()) {
						searchHistory.set(searchHistoryIndex, method_1882());
					}
					searchHistoryIndex += offset;
					method_1852(searchHistory.get(searchHistoryIndex));
				}
			}
		}
		return super.method_25404(input);
	}

	@Override
	public void method_48579(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		this.method_1888(EmiConfig.enabled);
		String lower = method_1882().toLowerCase();

		boolean dinnerbone = lower.contains("dinnerbone");
		accumulatedSpin += (dinnerbone ? 1 : -1) * Math.abs(System.currentTimeMillis() - lastRender);
		if (accumulatedSpin < 0) {
			accumulatedSpin = 0;
		} else if (accumulatedSpin > 500) {
			accumulatedSpin = 500;
		}
		lastRender = System.currentTimeMillis();
		long deg = accumulatedSpin * -180 / 500;
//		Matrix4fStack view = RenderSystem.getModelViewStack();
//		view.pushMatrix();
        context.push();
		if (deg != 0) {
            context.matrices().translate(this.field_22760 + this.field_22758 / 2, this.field_22761 + this.field_22759 / 2/*, 0*/);
            context.matrices().rotate(class_7833.field_40717.rotationDegrees(deg).angle());
            context.matrices().translate(-(this.field_22760 + this.field_22758 / 2), -(this.field_22761 + this.field_22759 / 2)/*, 0*/);
//			EmiPort.applyModelViewMatrix();
		}

		if (lower.contains("jeb_")) {
			int amount = 0x3FF;
			float h = ((lastRender & amount) % (float) amount) / (float) amount;
			int rgb = class_3532.method_15369(h, 1, 1);
//			context.setColor(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, ((rgb >> 0) & 0xFF) / 255f);
		}

		if (EmiConfig.enabled) {
			super.method_48579(context.raw(), mouseX, mouseY, delta);
			if (highlight) {
				int border = 0xffeeee00;
				context.fill(this.field_22760 - 1, this.field_22761 - 1, this.field_22758 + 2, 1, border);
				context.fill(this.field_22760 - 1, this.field_22761 + this.field_22759, this.field_22758 + 2, 1, border);
				context.fill(this.field_22760 - 1, this.field_22761 - 1, 1, this.field_22759 + 2, border);
				context.fill(this.field_22760 + this.field_22758, this.field_22761 - 1, 1, this.field_22759 + 2, border);
			}
		}
//		context.resetColor();
        context.pop();
//		view.popMatrix();
//		EmiPort.applyModelViewMatrix();
	}
}
