package dev.emi.emi.screen.widget.config;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.regex.Pattern;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import dev.emi.emi.EmiPort;
import dev.emi.emi.input.EmiInput;
import dev.emi.emi.screen.widget.SizedButtonWidget;

public class IntEdit {
	private static final Pattern NUMBER = Pattern.compile("^-?[0-9]*$");
	public final class_342 text;
	public final class_4185 up, down;
	
	public IntEdit(int width, IntSupplier getter, IntConsumer setter) {
		class_310 client = class_310.method_1551();
		text = new class_342(client.field_1772, 0, 0, width - 14, 18, EmiPort.literal(""));
		text.method_1852("" + getter.getAsInt());
		text.method_1863(string -> {
			try {
				if (string.isBlank()) {
					setter.accept(0);
				} else {
					setter.accept(Integer.parseInt(string));
				}
			} catch (Exception e) {
			}
		});
		text.method_1890(s -> {
			return NUMBER.matcher(s).matches();
		});

		up = new SizedButtonWidget(150, 0, 12, 10, 232, 48, () -> true, button -> {
			setter.accept(getter.getAsInt() + getInc());
			text.method_1852("" + getter.getAsInt());
		});
		down = new SizedButtonWidget(150, 10, 12, 10, 244, 48, () -> true, button -> {
			setter.accept(getter.getAsInt() - getInc());
			text.method_1852("" + getter.getAsInt());
		});
	}

	public boolean contains(int x, int y) {
		return x > text.field_22760 && x < up.field_22760 + up.method_25368() && y > text.field_22761 && y < text.field_22761 + text.method_25364();
	}

	public int getInc() {
		if (EmiInput.isShiftDown()) {
			return 10;
		} else if (EmiInput.isControlDown()) {
			return 5;
		}
		return 1;
	}

	public void setPosition(int x, int y) {
		text.method_46421(x + 1);
		text.method_46419(y + 1);
		up.method_46421(x + text.method_25368() + 2);
		up.method_46419(y);
		down.method_46421(up.field_22760);
		down.method_46419(y + 10);
	}
}
