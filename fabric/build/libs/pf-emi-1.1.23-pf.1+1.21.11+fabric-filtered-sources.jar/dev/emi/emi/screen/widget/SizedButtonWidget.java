package dev.emi.emi.screen.widget;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5684;
import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.runtime.EmiDrawContext;

public class SizedButtonWidget extends class_4185 {
	private final BooleanSupplier isActive;
	private final IntSupplier vOffset;
	protected class_2960 texture = EmiRenderHelper.BUTTONS;
	protected Supplier<List<net.minecraft.class_2561>> text;
	protected int u, v;

	public SizedButtonWidget(int x, int y, int width, int height, int u, int v, BooleanSupplier isActive, class_4241 action) {
		this(x, y, width, height, u, v, isActive, action, () -> 0);
	}

	public SizedButtonWidget(int x, int y, int width, int height, int u, int v, BooleanSupplier isActive, class_4241 action,
			List<net.minecraft.class_2561> text) {
		this(x, y, width, height, u, v, isActive, action, () -> 0, () -> text);
	}

	public SizedButtonWidget(int x, int y, int width, int height, int u, int v, BooleanSupplier isActive, class_4241 action,
			IntSupplier vOffset) {
		this(x, y, width, height, u, v, isActive, action, vOffset, null);
	}

	public SizedButtonWidget(int x, int y, int width, int height, int u, int v, BooleanSupplier isActive, class_4241 action,
			IntSupplier vOffset, Supplier<List<net.minecraft.class_2561>> text) {
		super(x, y, width, height, EmiPort.literal(""), action, s -> s.get());
		this.u = u;
		this.v = v;
		this.isActive = isActive;
		this.vOffset = vOffset;
		this.text = text;
	}

	protected int getU(int mouseX, int mouseY) {
		return this.u;
	}

	protected int getV(int mouseX, int mouseY) {
		int v = this.v + vOffset.getAsInt();
		this.field_22763 = this.isActive.getAsBoolean();
		if (!this.field_22763) {
			v += this.field_22759 * 2;
		} else if (this.method_25405(mouseX, mouseY)) {
			v += this.field_22759;
		}
		return v;
	}

    @Override
    protected void method_75752(class_332 raw, int mouseX, int mouseY, float deltaTicks) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		context.enableDepthTest();
		context.drawTexture(texture, this.field_22760, this.field_22761, getU(mouseX, mouseY), getV(mouseX, mouseY), this.field_22758, this.field_22759);
		if (this.method_25405(mouseX, mouseY) && text != null && this.field_22763) {
			context.push();
			context.disableDepthTest();
			class_310 client = class_310.method_1551();
			EmiRenderHelper.drawTooltip(client.field_1755, context, text.get().stream().map(EmiPort::ordered).map(class_5684::method_32662).toList(), mouseX, mouseY);
			context.pop();
		}
    }
}
