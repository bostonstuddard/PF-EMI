package dev.emi.emi;

import java.io.InputStream;
import java.util.Collection;
import java.util.Objects;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_10286;
import net.minecraft.class_10302;
import net.minecraft.class_10363;
import net.minecraft.class_124;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2521;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_287;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_342;
import net.minecraft.class_3611;
import net.minecraft.class_4185;
import net.minecraft.class_4185.class_4241;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_7699;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8786;
import net.minecraft.class_9307;
import net.minecraft.class_9326;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

import dev.emi.emi.api.stack.Comparison;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.registry.EmiRecipes;
import dev.emi.emi.runtime.EmiLog;

/**
 * Multiversion quarantine, to avoid excessive git pain
 */
public final class EmiPort {
	private static final net.minecraft.class_5819 RANDOM = net.minecraft.class_5819.method_43047();

	public static class_5250 literal(String s) {
		return class_2561.method_43470(s);
	}

	public static class_5250 literal(String s, class_124 formatting) {
		return class_2561.method_43470(s).method_27692(formatting);
	}

	public static class_5250 literal(String s, class_124... formatting) {
		return class_2561.method_43470(s).method_27695(formatting);
	}

	public static class_5250 literal(String s, class_2583 style) {
		return class_2561.method_43470(s).method_10862(style);
	}
	
	public static class_5250 translatable(String s) {
		return class_2561.method_43471(s);
	}
	
	public static class_5250 translatable(String s, class_124 formatting) {
		return class_2561.method_43471(s).method_27692(formatting);
	}
	
	public static class_5250 translatable(String s, Object... objects) {
		return class_2561.method_43469(s, objects);
	}

	public static class_5250 append(class_5250 text, class_2561 appended) {
		return text.method_10852(appended);
	}

	public static class_5481 ordered(class_2561 text) {
		return text.method_30937();
	}

	public static Collection<class_2960> findResources(class_3300 manager, String prefix, Predicate<String> pred) {
		return manager.method_14488(prefix, i -> pred.test(i.toString())).keySet();
	}

	public static InputStream getInputStream(class_3298 resource) {
		try {
			return resource.method_14482();
		} catch (Exception e) {
			return null;
		}
	}

	public static class_9307 addRandomBanner(class_9307 patterns, Random random) {
		var bannerRegistry = class_310.method_1551().field_1687.method_30349().method_30530(class_7924.field_41252);
		return new class_9307.class_3750().method_57575(patterns).method_16376(bannerRegistry.method_40265(random.nextInt(bannerRegistry.method_10204())).get(),
			class_1767.values()[random.nextInt(class_1767.values().length)]).method_57573();
	}

	public static boolean canTallFlowerDuplicate(class_2521 tallFlowerBlock) {
		try {
			return tallFlowerBlock.method_9651(null, null, null) && tallFlowerBlock.method_9650(null, null, null, null);
		} catch(Exception e) {
			return false;
		}
	}

//	public static void setShader(VertexBuffer buf, Matrix4f mat) {
//		buf.bind();
//		buf.draw(mat, RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
//	}

//	public static List<BakedQuad> getQuads(BakedModel model) {
//		return model.getQuads(null, null, RANDOM);
//	}

	public static void draw(class_287 bufferBuilder) {
//		BufferRenderer.drawWithGlobalProgram(bufferBuilder.end());
	}

	public static int getGuiScale(class_310 client) {
		return (int) client.method_22683().method_4495();
	}

	public static void setPositionTexShader() {
//		RenderSystem.setShader(GameRenderer::getPositionTexProgram);
	}

	public static void setPositionColorTexShader() {
//		RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
	}

	public static class_2378<class_1792> getItemRegistry() {
		return class_7923.field_41178;
	}

	public static class_2378<class_2248> getBlockRegistry() {
		return class_7923.field_41175;
	}

	public static class_2378<class_3611> getFluidRegistry() {
		return class_7923.field_41173;
	}

	public static class_2378<class_1842> getPotionRegistry() {
		return class_7923.field_41179;
	}

	public static class_2378<class_1887> getEnchantmentRegistry() {
		class_310 client = class_310.method_1551();
		return client.field_1687.method_30349().method_30530(class_7924.field_41265);
	}

	public static class_4185 newButton(int x, int y, int w, int h, class_2561 name, class_4241 action) {
		return class_4185.method_46430(name, action).method_46433(x, y).method_46437(w, h).method_46431();
	}

	public static class_1799 getOutput(class_1860<?> recipe) {
        // TODO: review this
        if (recipe.method_64664().size() > 1) {
            EmiLog.warn("Recipe " + recipe + " has more than one display, still not known how to handle this");
            return class_1799.field_8037;
        }

        class_10302 slotDisplay = recipe.method_64664().getFirst().comp_3258();
        if (slotDisplay instanceof class_10302.class_10307(class_1799 stack)) {
            return stack;
        } else if (slotDisplay instanceof class_10302.class_10310 smithing) {
            class_1937 world = class_310.method_1551().field_1687;
            return smithing.method_64742(class_10363.method_65008(Objects.requireNonNull(world)));
        } else {
            EmiLog.warn("Recipe " + recipe + " has an unsupported result slot display: " + slotDisplay.getClass()
                    .getName() + ": " + slotDisplay);
            return class_1799.field_8037;
        }
	}

	public static void focus(class_342 widget, boolean focused) {
		// Also ensure a current focus-element in the screen is cleared if it changes
		class_310 client = class_310.method_1551();
		if (client != null && client.field_1755 != null) {
			var currentFocus = client.field_1755.method_25399();
			if (!focused && currentFocus == widget || focused && currentFocus != widget) {
				client.field_1755.method_25395(null);
			}
		}
		widget.method_25365(focused);
	}

	public static Stream<class_1792> getDisabledItems() {
		class_310 client = class_310.method_1551();
		class_7699 fs = client.field_1687.method_45162();
		return getItemRegistry().method_10220().filter(i -> !i.method_45382(fs));
	}

	public static class_2960 getId(class_1860<?> recipe) {
		return EmiRecipes.recipeIds.get(recipe);
	}

	public static @Nullable class_8786<?> getRecipe(class_2960 id) {
		class_310 client = class_310.method_1551();
		if (client.field_1687 != null && id != null) {
			class_10286 manager = client.field_1687.method_8433();
			if (manager != null) {
				return EmiAgnos.getRecipe(manager, id);
			}
		}
		return null;
	}

	public static Comparison compareStrict() {
		return Comparison.compareComponents();
	}

	public static class_1799 setPotion(class_1799 stack, class_1842 potion) {
		stack.method_57367(class_9334.field_49651, class_1844.field_49274, getPotionRegistry().method_47983(potion), class_1844::method_57403);
		return stack;
	}

	public static class_9326 emptyExtraData() {
		return class_9326.field_49588;
	}

	public static class_2960 id(String id) {
		return class_2960.method_60654(id);
	}

	public static class_2960 id(String namespace, String path) {
		return class_2960.method_60655(namespace, path);
	}

	public static void applyModelViewMatrix() {
//		RenderSystem.applyModelViewMatrix();
	}
}
