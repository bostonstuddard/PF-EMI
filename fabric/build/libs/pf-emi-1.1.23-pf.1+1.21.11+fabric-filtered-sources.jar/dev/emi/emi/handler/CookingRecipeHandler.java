package dev.emi.emi.handler;

import java.util.List;
import net.minecraft.class_1720;
import net.minecraft.class_1735;
import com.google.common.collect.Lists;

import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;

public class CookingRecipeHandler<T extends class_1720> implements StandardRecipeHandler<T> {
	private final EmiRecipeCategory category;

	public CookingRecipeHandler(EmiRecipeCategory category) {
		this.category = category;
	}

	@Override
	public List<class_1735> getInputSources(T handler) {
		List<class_1735> list = Lists.newArrayList();
		list.add(handler.method_7611(0));
		int invStart = 3;
		for (int i = invStart; i < invStart + 36; i++) { 
			list.add(handler.method_7611(i));
		}
		return list;
	}
	
	@Override
	public List<class_1735> getCraftingSlots(T handler) {
		return List.of(handler.field_7761.get(0));
	}

	@Override
	public boolean supportsRecipe(EmiRecipe recipe) {
		return recipe.getCategory() == category && recipe.supportsRecipeTree();
	}
}
