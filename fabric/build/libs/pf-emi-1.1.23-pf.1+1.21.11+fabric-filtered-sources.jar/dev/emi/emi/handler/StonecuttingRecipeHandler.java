package dev.emi.emi.handler;

import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3971;
import net.minecraft.class_3975;
import net.minecraft.class_9696;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.recipe.handler.EmiCraftContext;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;

public class StonecuttingRecipeHandler implements StandardRecipeHandler<class_3971> {

	@Override
	public List<class_1735> getInputSources(class_3971 handler) {
		List<class_1735> list = Lists.newArrayList();
		list.add(handler.method_7611(0));
		int invStart = 2;
		for (int i = invStart; i < invStart + 36; i++) { 
			list.add(handler.method_7611(i));
		}
		return list;
	}

	@Override
	public List<class_1735> getCraftingSlots(class_3971 handler) {
		return List.of(handler.field_7761.get(0));
	}

	@Override
	public boolean supportsRecipe(EmiRecipe recipe) {
		return recipe.getCategory() == VanillaEmiRecipeCategories.STONECUTTING;
	}

	@Override
	public @Nullable class_1735 getOutputSlot(class_3971 handler) {
		return handler.method_7611(1);
	}

	@Override
	public boolean craft(EmiRecipe recipe, EmiCraftContext<class_3971> context) {
		boolean action = StandardRecipeHandler.super.craft(recipe, context);
		class_310 client = class_310.method_1551();
		class_1937 world = client.field_1687;
		class_9696 inv = new class_9696(recipe.getInputs().get(0).getEmiStacks().get(0).getItemStack());
		List<class_3975> recipes = world.method_8433().method_64677().comp_3255().stream()
                .map((it)->it.comp_3254().comp_3252().get().comp_1933()).toList();
		for (int i = 0; i < recipes.size(); i++) {
			if (EmiPort.getId(recipes.get(i)) != null && EmiPort.getId(recipes.get(i)).equals(recipe.getId())) {
				class_3971 sh = context.getScreenHandler();
				client.field_1761.method_2900(sh.field_7763, i);
				if (context.getDestination() == EmiCraftContext.Destination.CURSOR) {
					client.field_1761.method_2906(sh.field_7763, 1, 0, class_1713.field_7790, client.field_1724);
				} else if (context.getDestination() == EmiCraftContext.Destination.INVENTORY) {
					client.field_1761.method_2906(sh.field_7763, 1, 0, class_1713.field_7794, client.field_1724);
				}
				break;
			}
		}
		return action;
	}
}
