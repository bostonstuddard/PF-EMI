package dev.emi.emi.handler;

import java.util.List;
import net.minecraft.class_1714;
import net.minecraft.class_1735;
import com.google.common.collect.Lists;

import org.jetbrains.annotations.Nullable;

import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;

public class CraftingRecipeHandler implements StandardRecipeHandler<class_1714> {

	@Override
	public List<class_1735> getInputSources(class_1714 handler) {
		List<class_1735> list = Lists.newArrayList();
		for (int i = 1; i < 10; i++) { 
			list.add(handler.method_7611(i));
		}
		int invStart = 10;
		for (int i = invStart; i < invStart + 36; i++) { 
			list.add(handler.method_7611(i));
		}
		return list;
	}
	
	@Override
	public List<class_1735> getCraftingSlots(class_1714 handler) {
		List<class_1735> list = Lists.newArrayList();
		for (int i = 1; i < 10; i++) { 
			list.add(handler.method_7611(i));
		}
		return list;
	}

	@Override
	public @Nullable class_1735 getOutputSlot(class_1714 handler) {
		return handler.field_7761.get(0);
	}

	@Override
	public boolean supportsRecipe(EmiRecipe recipe) {
		return recipe.getCategory() == VanillaEmiRecipeCategories.CRAFTING && recipe.supportsRecipeTree();
	}
}
