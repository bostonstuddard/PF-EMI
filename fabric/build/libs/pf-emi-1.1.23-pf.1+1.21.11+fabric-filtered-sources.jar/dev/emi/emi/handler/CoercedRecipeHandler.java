package dev.emi.emi.handler;

import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_8566;
import com.google.common.collect.Lists;

import dev.emi.emi.api.recipe.EmiCraftingRecipe;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;
import dev.emi.emi.mixin.accessor.CraftingResultSlotAccessor;

public class CoercedRecipeHandler<T extends class_1703> implements StandardRecipeHandler<T> {
	private class_1734 output;
	private class_8566 inv;

	public CoercedRecipeHandler(class_1734 output) {
		this.output = output;
		this.inv = ((CraftingResultSlotAccessor) output).getInput();
	}

	@Override
	public class_1735 getOutputSlot(class_1703 handler) {
		return output;
	}

	@Override
	public List<class_1735> getInputSources(class_1703 handler) {
		class_310 client = class_310.method_1551();
		List<class_1735> slots = Lists.newArrayList();
		if (output != null) {
			for (class_1735 slot : handler.field_7761) {
				if (slot.method_7682() && slot.method_7674(client.field_1724) && slot != output) {
					slots.add(slot);
				}
			}
		}
		return slots;
	}

	@Override
	public List<class_1735> getCraftingSlots(class_1703 handler) {
		List<class_1735> slots = Lists.newArrayList();
		int width = inv.method_17398();
		int height = inv.method_17397();
		for (int i = 0; i < 9; i++) {
			slots.add(null);
		}
		for (class_1735 slot : handler.field_7761) {
			if (slot.field_7871 == inv && slot.method_34266() < width * height && slot.method_34266() >= 0) {
				int index = slot.method_34266();
				index = index * 3 / width;
				slots.set(index, slot);
			}
		}
		return slots;
	}

	@Override
	public boolean supportsRecipe(EmiRecipe recipe) {
		if (recipe.getCategory() == VanillaEmiRecipeCategories.CRAFTING && recipe.supportsRecipeTree()) {
			if (recipe instanceof EmiCraftingRecipe crafting) {
				return crafting.canFit(inv.method_17398(), inv.method_17397());
			}
			return true;
		}
		return false;
	}
}
