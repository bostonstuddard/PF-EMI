package dev.emi.emi.handler;

import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_5684;
import net.minecraft.class_9884;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiCraftingRecipe;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.VanillaEmiRecipeCategories;
import dev.emi.emi.api.recipe.handler.EmiCraftContext;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;

public class InventoryRecipeHandler implements StandardRecipeHandler<class_1723> {
	public static final class_2561 TOO_SMALL = EmiPort.translatable("emi.too_small");

	@Override
	public List<class_1735> getInputSources(class_1723 handler) {
		List<class_1735> list = Lists.newArrayList();
		for (int i = 1; i < 5; i++) { 
			list.add(handler.method_7611(i));
		}
		int invStart = 9;
		for (int i = invStart; i < invStart + 36; i++) { 
			list.add(handler.method_7611(i));
		}
		return list;
	}
	
	@Override
	public List<class_1735> getCraftingSlots(class_1723 handler) {
		List<class_1735> list = Lists.newArrayList();
		// This is like, bad, right? There has to be a better way to do this
		list.add(handler.method_7611(1));
		list.add(handler.method_7611(2));
		list.add(null);
		list.add(handler.method_7611(3));
		list.add(handler.method_7611(4));
		list.add(null);
		list.add(null);
		list.add(null);
		list.add(null);
		return list;
	}

	@Override
	public List<class_1735> getCraftingSlots(EmiRecipe recipe, class_1723 handler) {
		if (recipe instanceof EmiCraftingRecipe craf && craf.shapeless) {
			List<class_1735> list = Lists.newArrayList();
			list.add(handler.method_7611(1));
			list.add(handler.method_7611(2));
			list.add(handler.method_7611(3));
			list.add(handler.method_7611(4));
			return list;
		}
		return getCraftingSlots(handler);
	}

	@Override
	public @Nullable class_1735 getOutputSlot(class_1723 handler) {
		return handler.field_7761.get(0);
	}

	@Override
	public boolean supportsRecipe(EmiRecipe recipe) {
		if (recipe.getCategory() == VanillaEmiRecipeCategories.CRAFTING && recipe.supportsRecipeTree()) {
			if (recipe instanceof EmiCraftingRecipe crafting) {
				return crafting.canFit(2, 2);
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean canCraft(EmiRecipe recipe, EmiCraftContext<class_1723> context) {
		class_1703 sh = context.getScreenHandler();
		if (sh instanceof class_9884 acsh) {
			if (recipe instanceof EmiCraftingRecipe crafting) {
				return crafting.canFit(acsh.method_61629(), acsh.method_61630())
                        && StandardRecipeHandler.super.canCraft(recipe, context);
			}
		}
		return false;
	}

	@Override
	public List<class_5684> getTooltip(EmiRecipe recipe, EmiCraftContext<class_1723> context) {
		if (!canCraft(recipe, context)) {
			class_1703 sh = context.getScreenHandler();
			if (sh instanceof class_9884 acsh) {
				if (recipe instanceof EmiCraftingRecipe crafting) {
					if (!crafting.canFit(acsh.method_61629(), acsh.method_61630())) {
						return List.of(class_5684.method_32662(EmiPort.ordered(TOO_SMALL)));
					}
				}
			}
		}
		return StandardRecipeHandler.super.getTooltip(recipe, context);
	}
}
