package dev.emi.emi.api.widget;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_5684;

public abstract class Widget implements class_4068 {

	public abstract Bounds getBounds();
	
	public abstract void method_25394(class_332 draw, int mouseX, int mouseY, float delta);

	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		return List.of();
	}
	
	public boolean mouseClicked(int mouseX, int mouseY, int button) {
		return false;
	}

	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		return false;
	}
}
