package dev.emi.emi.api.stack;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3611;
import net.minecraft.class_5684;
import net.minecraft.class_9326;
import org.jetbrains.annotations.ApiStatus;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.render.EmiRender;
import dev.emi.emi.api.render.EmiTooltipComponents;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.tooltip.EmiTextTooltipWrapper;

@ApiStatus.Internal
public class FluidEmiStack extends EmiStack {
	private final class_3611 fluid;
	private final class_9326 componentChanges;

	public FluidEmiStack(class_3611 fluid) {
		this(fluid, class_9326.field_49588);
	}

	public FluidEmiStack(class_3611 fluid, class_9326 componentChanges) {
		this(fluid, componentChanges, 0);
	}

	public FluidEmiStack(class_3611 fluid, class_9326 componentChanges, long amount) {
		this.fluid = fluid;
		this.componentChanges = componentChanges;
		this.amount = amount;
	}

	@Override
	public EmiStack copy() {
		EmiStack e = new FluidEmiStack(fluid, componentChanges, amount);
		e.setChance(chance);
		e.setRemainder(getRemainder().copy());
		e.comparison = comparison;
		return e;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}

	@Override
	public class_9326 getComponentChanges() {
		return componentChanges;
	}

	@Override
	public Object getKey() {
		return fluid;
	}

	@Override
	public class_2960 getId() {
		return EmiPort.getFluidRegistry().method_10221(fluid);
	}

	@Override
	public void render(class_332 raw, int x, int y, float delta, int flags) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		if ((flags & RENDER_ICON) != 0) {
			context.push();
//			context.matrices().translate(0, 0, 100);
			EmiAgnos.renderFluid(this, context, x, y, delta);
			context.pop();
		}
		if ((flags & RENDER_REMAINDER) != 0) {
			EmiRender.renderRemainderIcon(this, context.raw(), x, y);
		}
	}

	@Override
	public List<class_2561> getTooltipText() {
		return EmiAgnos.getFluidTooltip(fluid, componentChanges);
	}

	@Override
	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		List<class_2561> text = getTooltipText();
		if (!text.isEmpty()) {
			list.add(new EmiTextTooltipWrapper(this, EmiPort.ordered(text.get(0))));
		}
		list.addAll(text.stream().skip(1).map(EmiTooltipComponents::of).collect(Collectors.toList()));
		if (amount > 1) {
			list.add(EmiTooltipComponents.getAmount(this));
		}
		String namespace = EmiPort.getFluidRegistry().method_10221(fluid).method_12836();
		EmiTooltipComponents.appendModName(list, namespace);
		list.addAll(super.getTooltip());
		return list;
	}

	@Override
	public class_2561 getName() {
		return EmiAgnos.getFluidName(fluid, componentChanges);
	}

	static class FluidEntry {
	}
}
