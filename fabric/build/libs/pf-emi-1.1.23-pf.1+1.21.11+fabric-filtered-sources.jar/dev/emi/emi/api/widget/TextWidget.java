package dev.emi.emi.api.widget;

import dev.emi.emi.runtime.EmiDrawContext;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5481;

public class TextWidget extends Widget {
	private static final class_310 CLIENT = class_310.method_1551();
	protected final class_5481 text;
	protected final int x, y;
	protected final int color;
	protected final boolean shadow;
	protected Alignment horizontalAlignment = Alignment.START;
	protected Alignment verticalAlignment = Alignment.START;

	public TextWidget(class_5481 text, int x, int y, int color, boolean shadow) {
		this.text = text;
		this.x = x;
		this.y = y;
		this.color = color;
		this.shadow = shadow;
	}

	public TextWidget horizontalAlign(Alignment alignment) {
		this.horizontalAlignment = alignment;
		return this;
	}

	public TextWidget verticalAlign(Alignment alignment) {
		this.verticalAlignment = alignment;
		return this;
	}

	@Override
	public Bounds getBounds() {
		int width = CLIENT.field_1772.method_30880(text);
		int xOff = horizontalAlignment.offset(width);
		int yOff = verticalAlignment.offset(CLIENT.field_1772.field_2000);
		return new Bounds(x + xOff, y + yOff, width, CLIENT.field_1772.field_2000);
	}

	@Override
	public void method_25394(class_332 draw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(draw);
		context.push();
		int xOff = horizontalAlignment.offset(CLIENT.field_1772.method_30880(text));
		int yOff = verticalAlignment.offset(CLIENT.field_1772.field_2000);
		context.matrices().translate(xOff, yOff/*, 300*/);
		if (shadow) {
			context.drawTextWithShadow(text, x, y, color);
		} else {
			context.drawText(text, x, y, color);
		}
		context.pop();
	}

	public enum Alignment {
		START, CENTER, END;

		public int offset(int length) {
			return switch (this) {
				case START -> 0;
				case CENTER -> -(length / 2);
				case END -> -length;
			};
		}
	}
}
