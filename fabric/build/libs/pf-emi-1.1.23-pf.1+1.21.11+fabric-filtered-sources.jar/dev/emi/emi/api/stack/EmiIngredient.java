package dev.emi.emi.api.stack;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_6862;
import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.registry.EmiTags;
import dev.emi.emi.runtime.EmiTagKey;

public interface EmiIngredient extends EmiRenderable {
	public static final int RENDER_ICON = 1;
	public static final int RENDER_AMOUNT = 2;
	public static final int RENDER_INGREDIENT = 4;
	public static final int RENDER_REMAINDER = 8;
	
	/**
	 * @return The {@link EmiStack}s represented by this ingredient.
	 * 	List is never empty. For an empty ingredient, us {@link EmiStack#EMPTY}
	 */
	List<EmiStack> getEmiStacks();

	default boolean isEmpty() {
		for (EmiStack stack : getEmiStacks()) {
			if (!stack.isEmpty()) {
				return false;
			}
		}
		return true;
	}

	EmiIngredient copy();

	long getAmount();

	EmiIngredient setAmount(long amount);

	float getChance();

	EmiIngredient setChance(float chance);

	@Override
	default void render(class_332 draw, int x, int y, float delta) {
		render(draw, x, y, delta, -1);
	}

	void render(class_332 draw, int x, int y, float delta, int flags);

	List<class_5684> getTooltip();

	public static boolean areEqual(EmiIngredient a, EmiIngredient b) {
		List<EmiStack> as = a.getEmiStacks();
		List<EmiStack> bs = b.getEmiStacks();
		if (as.size() != bs.size()) {
			return false;
		}
		for (int i = 0; i < as.size(); i++) {
			if (!as.get(i).isEqual(bs.get(i))) {
				return false;
			}
		}
		return true;
	}

	public static <T> EmiIngredient of(class_6862<T> key) {
		return of(key, 1);
	}

	public static <T> EmiIngredient of(class_6862<T> key, long amount) {
		return EmiIngredient.of(EmiTags.getRawValues(EmiTagKey.of(key)), amount);
	}

	public static EmiIngredient of(class_1856 ingredient) {
		if (ingredient == null || ingredient.method_65799()) {
			return EmiStack.EMPTY;
		}
		class_1799[] stacks = ingredient.method_8105().map((it)->it.comp_349().method_7854()).toArray(class_1799[]::new);
		int amount = 1;
		if (stacks.length != 0) {
			amount = stacks[0].method_7947();
			for (int i = 1; i < stacks.length; i++) {
				if (stacks[i].method_7947() != amount) {
					amount = 1;
					break;
				}
			}
		}
		return of(ingredient, amount);
	}

    public static EmiIngredient of(class_1856 ingredient, long amount) {
        if (ingredient == null || ingredient.method_65799()) {
            return EmiStack.EMPTY;
        }
        return EmiTags.getIngredient(class_1792.class, Arrays.stream(ingredient.method_8105()
                .map((it) -> it.comp_349().method_7854())
                .toArray(class_1799[]::new)).map(EmiStack::of).toList(), amount);
    }

	public static EmiIngredient of(List<? extends EmiIngredient> list) {
		return of(list, 1);
	}

	public static EmiIngredient of(List<? extends EmiIngredient> list, long amount) {
		if (list.size() == 0) {
			return EmiStack.EMPTY;
		} else if (list.size() == 1) {
			EmiIngredient stack = list.get(0);
			if (stack.getAmount() < amount) {
				return stack.copy().setAmount(amount);
			} else {
				return stack;
			}
		} else {
			long internalAmount = list.get(0).getAmount();
			for (EmiIngredient i : list) {
				if (i.getAmount() != internalAmount) {
					internalAmount = 1;
				}
			}
			if (internalAmount > 1) {
				amount = internalAmount;
				list = list.stream().map(st -> st.copy().setAmount(1)).toList();
			}
			Class<?> tagType = null;
			for (EmiIngredient i : list) {
				for (EmiStack s : i.getEmiStacks()) {
					if (!s.isEmpty()) {
						if (tagType == null) {
							tagType = EmiTags.ADAPTERS_BY_CLASS.getKey(s.getKey().getClass());
						}
						if (tagType == null || !tagType.isAssignableFrom(s.getKey().getClass())) {
							return new ListEmiIngredient(list, amount);
						}
					}
				}
			}
			return EmiTags.getIngredient(tagType, list.stream().flatMap(i -> i.getEmiStacks().stream()).toList(), amount);
		}
	}
}
