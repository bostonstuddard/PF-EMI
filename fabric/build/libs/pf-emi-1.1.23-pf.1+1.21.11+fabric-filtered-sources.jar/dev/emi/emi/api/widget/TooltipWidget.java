package dev.emi.emi.api.widget;

import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public class TooltipWidget extends Widget {
	private final Bounds bounds;
	private final BiFunction<Integer, Integer, List<class_5684>> tooltipSupplier;

	public TooltipWidget(BiFunction<Integer, Integer, List<class_5684>> tooltipSupplier, int x, int y, int width, int height) {
		this.bounds = new Bounds(x, y, width, height);
		this.tooltipSupplier = tooltipSupplier;
	}

	@Override
	public Bounds getBounds() {
		return bounds;
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		return tooltipSupplier.apply(mouseX, mouseY);
	}

	@Override
	public void method_25394(class_332 draw, int mouseX, int mouseY, float delta) {
	}
}
