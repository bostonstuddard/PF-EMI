package dev.emi.emi.api.recipe;

import java.util.Comparator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.data.EmiRecipeCategoryProperties;

public class EmiRecipeCategory implements EmiRenderable {
	public class_2960 id;
	public EmiRenderable icon, simplified;
	public Comparator<EmiRecipe> sorter;
	
	/**
	 * A constructor to use only a single renderable for both the icon and simplified icon.
	 * It is generally recommended that simplified icons be unique and follow the style of vanilla icons.
	 * 
	 * {@link EmiStack} instances can be passed as {@link EmiRenderable}
	 */
	public EmiRecipeCategory(class_2960 id, EmiRenderable icon) {
		this(id, icon, icon);
	}

	/**
	 * {@link EmiStack} instances can be passed as {@link EmiRenderable}
	 */
	public EmiRecipeCategory(class_2960 id, EmiRenderable icon, EmiRenderable simplified) {
		this(id, icon, simplified, EmiRecipeSorting.none());
	}

	/**
	 * {@link EmiStack} instances can be passed as {@link EmiRenderable}
	 */
	public EmiRecipeCategory(class_2960 id, EmiRenderable icon, EmiRenderable simplified, Comparator<EmiRecipe> sorter) {
		this.id = id;
		this.icon = icon;
		this.simplified = simplified;
		this.sorter = sorter;
	}

	public class_2561 getName() {
		return EmiPort.translatable(EmiUtil.translateId("emi.category.", getId()));
	}

	public class_2960 getId() {
		return id;
	}

	@Override
	public void render(class_332 draw, int x, int y, float delta) {
		EmiRecipeCategoryProperties.getIcon(this).render(draw, x, y, delta);
	}

	public void renderSimplified(class_332 draw, int x, int y, float delta) {
		EmiRecipeCategoryProperties.getSimplifiedIcon(this).render(draw, x, y, delta);
	}

	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		list.add(class_5684.method_32662(EmiPort.ordered(getName())));
		if (EmiUtil.showAdvancedTooltips()) {
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.literal(id.toString(), class_124.field_1063))));
		}
		if (EmiConfig.appendModId) {
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.literal(EmiUtil.getModName(getId().method_12836()),
				class_124.field_1078, class_124.field_1056))));
		}
		return list;
	}

	public @Nullable Comparator<EmiRecipe> getSort() {
		return sorter;
	}
}
