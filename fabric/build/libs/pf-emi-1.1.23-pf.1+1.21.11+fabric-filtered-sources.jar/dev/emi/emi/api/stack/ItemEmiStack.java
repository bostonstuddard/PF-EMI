package dev.emi.emi.api.stack;

import java.util.List;
import net.minecraft.class_10444;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5683;
import net.minecraft.class_5684;
import net.minecraft.class_811;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import org.jetbrains.annotations.ApiStatus;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.api.render.EmiRender;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.screen.StackBatcher.Batchable;
import dev.emi.emi.screen.tooltip.EmiTextTooltipWrapper;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public class ItemEmiStack extends EmiStack implements Batchable {
	private static final class_310 client = class_310.method_1551();

	private final class_1792 item;
	private final class_9326 componentChanges;

	private boolean unbatchable;

	public ItemEmiStack(class_1799 stack) {
		this(stack, stack.method_7947());
	}

	public ItemEmiStack(class_1799 stack, long amount) {
		this(stack.method_7909(), stack.method_57380(), amount);
	}

	public ItemEmiStack(class_1792 item, class_9326 components, long amount) {
		this.item = item;
		this.componentChanges = components;
		this.amount = amount;
	}

	@Override
	public class_1799 getItemStack() {
		return new class_1799(EmiPort.getItemRegistry().method_47983(this.item), (int) this.amount, componentChanges);
	}

	@Override
	public EmiStack copy() {
		EmiStack e = new ItemEmiStack(item, componentChanges, amount);
		e.setChance(chance);
		e.setRemainder(getRemainder().copy());
		e.comparison = comparison;
		return e;
	}

	@Override
	public boolean isEmpty() {
		return amount == 0 || item == class_1802.field_8162;
	}

	@Override
	public class_9326 getComponentChanges() {
		return this.componentChanges;
	}

	@Override
	public <T> @Nullable T get(class_9331<? extends T> type) {
		// Check the changes first
		var changedOpt = this.componentChanges.method_57845(type);
		//noinspection OptionalAssignedToNull
		if(changedOpt != null) {
			return changedOpt.orElse(null);
		}
		// Check the item's default components
		return this.item.method_57347().method_58694(type);
	}

	@Override
	public Object getKey() {
		return item;
	}

	@Override
	public class_2960 getId() {
		return EmiPort.getItemRegistry().method_10221(item);
	}

	@Override
	public void render(class_332 draw, int x, int y, float delta, int flags) {
		EmiDrawContext context = EmiDrawContext.wrap(draw);
		class_1799 stack = getItemStack();
		if ((flags & RENDER_ICON) != 0) {
			draw.method_51445(stack, x, y);
			draw.method_51432(client.field_1772, stack, x, y, "");
		}
		if ((flags & RENDER_AMOUNT) != 0) {
			String count = "";
			if (amount != 1) {
				count += amount;
			}
			EmiRenderHelper.renderAmount(context, x, y, EmiPort.literal(count));
		}
		if ((flags & RENDER_REMAINDER) != 0) {
			EmiRender.renderRemainderIcon(this, context.raw(), x, y);
		}
	}
	
	@Override
	public boolean isSideLit() {
        class_10444 state = new class_10444(); // TODO
        client.method_65386().method_65596(state, getItemStack(), class_811.field_4317, client.field_1687, null, 0);
		return state.method_65608();
	}
	
	@Override
	public boolean isUnbatchable() {
		class_1799 stack = getItemStack();
		return unbatchable || stack.method_7958() || stack.method_7986() || !EmiAgnos.canBatch(stack);
        // || client.getItemRenderer().getModel(getItemStack(), null, null, 0).isBuiltin();
	}
	
	@Override
	public void setUnbatchable() {
		this.unbatchable = true;
	}
	
	@Override
	public void renderForBatch(class_4597 vcp, class_332 draw, int x, int y, int z, float delta) {
//		EmiDrawContext context = EmiDrawContext.wrap(draw);
//		ItemStack stack = getItemStack();
//		ItemRenderer ir = client.getItemRenderer();
//		BakedModel model = ir.getModel(stack, null, null, 0);
//		context.push();
//		try {
//			context.matrices().translate(x, y, 100.0f + z + (model.hasDepth() ? 50 : 0));
//			context.matrices().translate(8.0, 8.0, 0.0);
//			context.matrices().scale(16.0f, -16.0f, 16.0f);
//			ir.renderItem(stack, ModelTransformationMode.GUI, false, context.matrices(), vcp, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV, model);
//		} finally {
//			context.pop();
//		}
	}

	@Override
	public List<class_2561> getTooltipText() {
		if (client.method_18854()) {
			return getItemStack().method_7950(class_1792.class_9635.method_59528(client.field_1687), client.field_1724, class_1836.field_41070);
		} else {
			// Don't provide world or entity as context, as they are not thread safe
			return getItemStack().method_7950(class_1792.class_9635.method_59530(client.field_1687.method_30349()), null, class_1836.field_41070);
		}
	}

	@Override
	public List<class_5684> getTooltip() {
		class_1799 stack = getItemStack();
		List<class_5684> list = Lists.newArrayList();
		if (!isEmpty()) {
			list.addAll(EmiAgnos.getItemTooltip(stack));
			if (!list.isEmpty() && list.get(0) instanceof class_5683 ottc) {
				list.set(0, new EmiTextTooltipWrapper(this, ottc));
			}
			//String namespace = EmiPort.getItemRegistry().getId(stack.getItem()).getNamespace();
			//String mod = EmiUtil.getModName(namespace);
			//list.add(TooltipComponent.of(EmiLang.literal(mod, Formatting.BLUE, Formatting.ITALIC)));
			list.addAll(super.getTooltip());
		}
		return list;
	}

	@Override
	public class_2561 getName() {
		if (isEmpty()) {
			return EmiPort.literal("");
		}
		return getItemStack().method_7964();
	}

	static class ItemEntry {
	}
}