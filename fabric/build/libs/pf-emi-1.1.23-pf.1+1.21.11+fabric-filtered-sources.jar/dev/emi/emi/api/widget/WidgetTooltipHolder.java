package dev.emi.emi.api.widget;

import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_2561;
import net.minecraft.class_5684;

public interface WidgetTooltipHolder<T> {
	
	T tooltip(BiFunction<Integer, Integer, List<class_5684>> tooltipSupplier);

	default T tooltip(List<class_5684> tooltip) {
		return tooltip((mx, my) -> tooltip);
	}

	default T tooltipText(BiFunction<Integer, Integer, List<class_2561>> tooltipSupplier) {
		return tooltip((x, y) -> tooltipSupplier.apply(x, y).stream().map(class_2561::method_30937).map(class_5684::method_32662).toList());
	}

	default T tooltipText(List<class_2561> tooltip) {
		return tooltip(tooltip.stream().map(class_2561::method_30937).map(class_5684::method_32662).toList());
	}
}
