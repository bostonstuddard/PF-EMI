package dev.emi.emi.api.stack;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_6862;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiRenderHelper;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.render.EmiRender;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.mixin.accessor.DrawContextAccessor;
import dev.emi.emi.mixin.accessor.ItemRendererAccessor;
import dev.emi.emi.platform.EmiAgnos;
import dev.emi.emi.registry.EmiTags;
import dev.emi.emi.runtime.EmiDrawContext;
import dev.emi.emi.runtime.EmiTagKey;
import dev.emi.emi.screen.tooltip.EmiTextTooltipWrapper;
import dev.emi.emi.screen.tooltip.RemainderTooltipComponent;
import dev.emi.emi.screen.tooltip.TagTooltipComponent;

@ApiStatus.Internal
public class TagEmiIngredient implements EmiIngredient {
	private final class_2960 id;
	private List<EmiStack> stacks;
	public final class_6862<?> key;
	private final EmiTagKey<?> tagKey;
	private long amount;
	private float chance = 1;

	@ApiStatus.Internal
	public TagEmiIngredient(class_6862<?> key, long amount) {
		this(EmiTagKey.of(key), amount);
	}

	@ApiStatus.Internal
	public TagEmiIngredient(class_6862<?> key, List<EmiStack> stacks, long amount) {
		this(EmiTagKey.of(key), stacks, amount);
	}

	@ApiStatus.Internal
	public TagEmiIngredient(EmiTagKey<?> key, long amount) {
		this(key, EmiTags.getValues(key), amount);
	}

	private TagEmiIngredient(EmiTagKey<?> key, List<EmiStack> stacks, long amount) {
		this.id = key.id();
		this.key = key.raw();
		this.tagKey = key;
		this.stacks = stacks;
		this.amount = amount;
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof TagEmiIngredient tag && tag.key.equals(this.key);
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public EmiIngredient copy() {
		EmiIngredient stack = new TagEmiIngredient(tagKey, amount);
		stack.setChance(chance);
		return stack;
	}

	@Override
	public List<EmiStack> getEmiStacks() {
		return stacks;
	}

	@Override
	public long getAmount() {
		return amount;
	}

	@Override
	public EmiIngredient setAmount(long amount) {
		this.amount = amount;
		return this;
	}

	@Override
	public float getChance() {
		return chance;
	}

	@Override
	public EmiIngredient setChance(float chance) {
		this.chance = chance;
		return this;
	}

	@Override
	public void render(class_332 draw, int x, int y, float delta, int flags) {
		EmiDrawContext context = EmiDrawContext.wrap(draw);
		class_310 client = class_310.method_1551();

		if ((flags & RENDER_ICON) != 0) {
			if (!tagKey.hasCustomModel()) {
				if (stacks.size() > 0) {
					stacks.get(0).render(context.raw(), x, y, delta, -1 ^ RENDER_AMOUNT);
				}
			} else {
                // TODO: still don't know how to do this
//				BakedModel model = EmiAgnos.getBakedTagModel(tagKey.getCustomModel());
//
//				context.matrices().push();
//				context.matrices().translate(x + 8, y + 8, 150);
//				context.matrices().multiplyPositionMatrix(new Matrix4f().scaling(1.0f, -1.0f, 1.0f));
//				context.matrices().scale(16.0f, 16.0f, 16.0f);
//
//				model.getTransformation().getTransformation(ModelTransformationMode.GUI).apply(false, context.matrices());
//				context.matrices().translate(-0.5f, -0.5f, -0.5f);
//
//				if (!model.isSideLit()) {
//					DiffuseLighting.disableGuiDepthLighting();
//				}
//				VertexConsumerProvider.Immediate immediate = context.raw().getVertexConsumers();
//
//				((ItemRendererAccessor) client.getItemRenderer())
//					.invokeRenderBakedItemModel(model,
//						ItemStack.EMPTY, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV, context.matrices(),
//						ItemRenderer.getDirectItemGlintConsumer(immediate,
//							TexturedRenderLayers.getEntityTranslucentCull(), true, false));
//				immediate.draw();
//
//				if (!model.isSideLit()) {
//					DiffuseLighting.enableGuiDepthLighting();
//				}
//
//				context.matrices().pop();
			}
		}
		if ((flags & RENDER_AMOUNT) != 0 && !tagKey.isOf(EmiPort.getFluidRegistry())) {
			String count = "";
			if (amount != 1) {
				count += amount;
			}
			EmiRenderHelper.renderAmount(context, x, y, EmiPort.literal(count));
		}
		if ((flags & RENDER_INGREDIENT) != 0) {
			EmiRender.renderTagIcon(this, context.raw(), x, y);
		}
		if ((flags & RENDER_REMAINDER) != 0) {
			EmiRender.renderRemainderIcon(this, context.raw(), x, y);
		}
	}

	@Override
	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		list.add(new EmiTextTooltipWrapper(this, EmiPort.ordered(tagKey.getTagName())));
		if (EmiUtil.showAdvancedTooltips()) {
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.literal("#" + id, class_124.field_1063))));
		}
		if (tagKey.isOf(EmiPort.getFluidRegistry()) && amount > 1) {
			list.add(class_5684.method_32662(EmiPort.ordered(EmiRenderHelper.getAmountText(this, amount))));
		}
		if (EmiConfig.appendModId) {
			String mod = EmiUtil.getModName(id.method_12836());
			list.add(class_5684.method_32662(EmiPort.ordered(EmiPort.literal(mod, class_124.field_1078, class_124.field_1056))));
		}
		list.add(new TagTooltipComponent(stacks));
		for (EmiStack stack : stacks) {
			if (!stack.getRemainder().isEmpty()) {
				list.add(new RemainderTooltipComponent(this));
				break;
			}
		}
		return list;
	}
}