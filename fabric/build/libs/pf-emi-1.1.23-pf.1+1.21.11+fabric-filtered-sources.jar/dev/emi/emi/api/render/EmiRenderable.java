package dev.emi.emi.api.render;

import net.minecraft.class_332;

/**
 * Provides a method to render something at a position
 */
public interface EmiRenderable {
	
	void render(class_332 draw, int x, int y, float delta);
}
