package dev.emi.emi.api.stack;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_5684;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.EmiPort;
import dev.emi.emi.registry.EmiComparisonDefaults;
import dev.emi.emi.screen.tooltip.RemainderTooltipComponent;

/**
 * An abstract representation of a resource in EMI.
 * Can be an item, a fluid, or something else.
 */
public abstract class EmiStack implements EmiIngredient {
	public static final EmiStack EMPTY = new EmptyEmiStack();
	private EmiStack remainder = EMPTY;
	protected Comparison comparison = Comparison.DEFAULT_COMPARISON;
	protected long amount = 1;
	protected float chance = 1;

	@Override
	public List<EmiStack> getEmiStacks() {
		return List.of(this);
	}

	public EmiStack getRemainder() {
		return remainder;
	}

	public EmiStack setRemainder(EmiStack stack) {
		if (stack == this) {
			stack = stack.copy();
		}
		remainder = stack;
		return this;
	}

	public EmiStack comparison(Function<Comparison, Comparison> comparison) {
		this.comparison = comparison.apply(this.comparison);
		return this;
	}

	public EmiStack comparison(Comparison comparison) {
		this.comparison = comparison;
		return this;
	}

	public abstract EmiStack copy();

	public abstract boolean isEmpty();

	public long getAmount() {
		return amount;
	}
	
	public EmiStack setAmount(long amount) {
		this.amount = amount;
		return this;
	}

	public float getChance() {
		return chance;
	}
	
	public EmiStack setChance(float chance) {
		this.chance = chance;
		return this;
	}

	public abstract class_9326 getComponentChanges();

	public <T> @Nullable T get(class_9331<? extends T> type) {
		var opt = getComponentChanges().method_57845(type);
		//noinspection OptionalAssignedToNull
		return opt != null ? opt.orElse(null) : null;
	}

	public <T> T getOrDefault(class_9331<? extends T> type, T fallback) {
		var componentValue = this.get(type);
		return componentValue != null ? componentValue : fallback;
	}

	public abstract Object getKey();

	@SuppressWarnings("unchecked")
	public <T> @Nullable T getKeyOfType(Class<T> clazz) {
		Object o = getKey();
		if (clazz.isAssignableFrom(o.getClass())) {
			return (T) o;
		}
		return null;
	}

	public abstract class_2960 getId();

	public class_1799 getItemStack() {
		return class_1799.field_8037;
	}

	public boolean isEqual(EmiStack stack) {
		if (!getKey().equals(stack.getKey())) {
			return false;
		}
		Comparison a = comparison == Comparison.DEFAULT_COMPARISON ? EmiComparisonDefaults.get(getKey()) : comparison;
		Comparison b = stack.comparison == Comparison.DEFAULT_COMPARISON ? EmiComparisonDefaults.get(stack.getKey()) : stack.comparison;
		if (a == b) {
			return a.compare(this, stack);
		} else {
			return a.compare(this, stack) && b.compare(this, stack);
		}
	}

	public boolean isEqual(EmiStack stack, Comparison comparison) {
		return getKey().equals(stack.getKey()) && comparison.compare(this, stack);
	}

	public abstract List<class_2561> getTooltipText();

	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		if (!getRemainder().isEmpty()) {
			list.add(new RemainderTooltipComponent(this));
		}
		return list;
	}

	public abstract class_2561 getName();

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof EmiStack stack) {
			return this.isEqual(stack);
		} else if (obj instanceof EmiIngredient stack) {
			return EmiIngredient.areEqual(this, stack);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return getKey().hashCode();
	}

	@Override
	public String toString() {
		String s = "" + getKey();
		class_9326 changes = getComponentChanges();
		if (changes != class_9326.field_49588) {
			s += changes;
		}
		return s + " x" + getAmount();
	}

	public static EmiStack of(class_1799 stack) {
		if (stack.method_7960()) {
			return EmiStack.EMPTY;
		}
		return new ItemEmiStack(stack);
	}

	public static EmiStack of(class_1799 stack, long amount) {
		if (stack.method_7960()) {
			return EmiStack.EMPTY;
		}
		return new ItemEmiStack(stack, amount);
	}

	public static EmiStack of(class_1935 item) {
		return of(item.method_8389().method_7854(), 1);
	}

	public static EmiStack of(class_1935 item, long amount) {
		return of(item.method_8389().method_7854(), amount);
	}

	public static EmiStack of(class_1935 item, class_9326 componentChanges) {
		return of(item, componentChanges, 1);
	}

	public static EmiStack of(class_1935 item, class_9326 componentChanges, long amount) {
		return new ItemEmiStack(item.method_8389(), componentChanges, amount);
	}

	public static EmiStack of(class_3611 fluid) {
		return of(fluid, EmiPort.emptyExtraData());
	}

	public static EmiStack of(class_3611 fluid, long amount) {
		return of(fluid, EmiPort.emptyExtraData(), amount);
	}

	public static EmiStack of(class_3611 fluid, class_9326 componentChanges) {
		return of(fluid, componentChanges, 0);
	}

	public static EmiStack of(class_3611 fluid, class_9326 componentChanges, long amount) {
		if (fluid instanceof class_3609 ff && ff.method_15751() != class_3612.field_15906) {
			fluid = ff.method_15751();
		}
		if (fluid == class_3612.field_15906) {
			return EmiStack.EMPTY;
		}
		return new FluidEmiStack(fluid, componentChanges, amount);
	}

	static abstract class Entry<T> {
	}
}
