package dev.emi.emi.api.stack;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_9326;
import org.jetbrains.annotations.ApiStatus;

import dev.emi.emi.EmiPort;

@ApiStatus.Internal
public class EmptyEmiStack extends EmiStack {
	private static final class_2960 ID = EmiPort.id("emi", "empty");

	@Override
	public EmiStack getRemainder() {
		return EMPTY;
	}

	@Override
	public List<EmiStack> getEmiStacks() {
		return List.of(EMPTY);
	}

	@Override
	public EmiStack setRemainder(EmiStack stack) {
		throw new UnsupportedOperationException("Cannot mutate an empty stack");
	}

	@Override
	public EmiStack copy() {
		return EMPTY;
	}
	
	public EmiStack setAmount(long amount) {
		return this;
	}
	
	public EmiStack setChance(float chance) {
		return this;
	}

	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public class_9326 getComponentChanges() {
		return class_9326.field_49588;
	}

	@Override
	public Object getKey() {
		return class_1802.field_8162;
	}

	@Override
	public class_1799 getItemStack() {
		return class_1799.field_8037;
	}

	@Override
	public class_2960 getId() {
		return ID;
	}

	@Override
	public boolean isEqual(EmiStack stack) {
		return stack == EMPTY;
	}

	@Override
	public void render(class_332 draw, int x, int y, float delta, int flags) {
	}

	@Override
	public List<class_2561> getTooltipText() {
		return List.of();
	}

	@Override
	public List<class_5684> getTooltip() {
		return List.of();
	}

	@Override
	public class_2561 getName() {
		return EmiPort.literal("");
	}

	static class EmptyEntry {
	}
}