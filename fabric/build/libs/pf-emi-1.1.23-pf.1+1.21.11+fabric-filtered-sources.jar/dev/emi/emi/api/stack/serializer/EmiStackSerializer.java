package dev.emi.emi.api.stack.serializer;

import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2509;
import net.minecraft.class_2522;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3518;
import net.minecraft.class_9326;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.runtime.EmiLog;

public interface EmiStackSerializer<T extends EmiStack> extends EmiIngredientSerializer<T> {
	static final Pattern STACK_REGEX = Pattern.compile("^([\\w_\\-./]+):([\\w_\\-.]+):([\\w_\\-./]+)(\\{.*\\})?$");
	
	EmiStack create(class_2960 id, class_9326 componentChanges, long amount);

	private static <T> DynamicOps<T> withRegistryAccess(DynamicOps<T> ops) {
		class_310 instance = class_310.method_1551();
		if (instance == null || instance.field_1687 == null) {
			//Note: instance can be null in datagen, just fall back to a variant that doesn't have registry access
			// as in the majority of cases this will work fine
			return ops;
		}
		return instance.field_1687.method_30349().method_57093(ops);
	}

	@Override
	default EmiIngredient deserialize(JsonElement element) {
		class_2960 id = null;
		String nbt = null;
		JsonObject changesJson = null;
		long amount = 1;
		float chance = 1;
		EmiStack remainder = EmiStack.EMPTY;
		if (class_3518.method_15286(element)) {
			String s = element.getAsString();
			Matcher m = STACK_REGEX.matcher(s);
			if (m.matches()) {
				id = EmiPort.id(m.group(2), m.group(3));
				nbt = m.group(4);
			}
		} else if (element.isJsonObject()) {
			JsonObject json = element.getAsJsonObject();
			id = EmiPort.id(class_3518.method_15265(json, "id"));
			nbt = class_3518.method_15253(json, "nbt", null);
			changesJson = class_3518.method_15281(json, "componentChanges", null);
			amount = class_3518.method_15280(json, "amount", 1);
			chance = class_3518.method_15277(json, "chance", 1);
			if (class_3518.method_15294(json, "remainder")) {
				EmiIngredient ing = EmiIngredientSerializer.getDeserialized(json.get("remainder"));
				if (ing instanceof EmiStack stack) {
					remainder = stack;
				}
			}
		}
		if (id != null) {
			try {
				class_9326 changes = class_9326.field_49588;
				if (changesJson != null) {
					changes = class_9326.field_49589.decode(withRegistryAccess(JsonOps.INSTANCE), changesJson).getOrThrow().getFirst();
				} else if (nbt != null) {
					changes = class_9326.field_49589.decode(withRegistryAccess(class_2509.field_11560), class_2522.method_67315(nbt)).getOrThrow().getFirst();
				}
				EmiStack stack = create(id, changes, amount);
				if (chance != 1) {
					stack.setChance(chance);
				}
				if (!remainder.isEmpty()) {
					stack.setRemainder(remainder);
				}
				return stack;
			} catch (Exception e) {
				EmiLog.error("Error parsing NBT in deserialized stack", e);
				return EmiStack.EMPTY;
			}
		}
		return EmiStack.EMPTY;
	}

	@Override
	default JsonElement serialize(T stack) {
		String nbt = null;
		class_9326 componentChanges = stack.getComponentChanges();
		if (componentChanges != class_9326.field_49588) {
			nbt = class_9326.field_49589.encodeStart(withRegistryAccess(class_2509.field_11560), componentChanges).getOrThrow().toString();
		}
		if (stack.getAmount() == 1 && stack.getChance() == 1 && stack.getRemainder().isEmpty()) {
			String s = getType() + ":" + stack.getId();
			if (nbt != null) {
				s += nbt;
			}
			return new JsonPrimitive(s);
		} else {
			JsonObject json = new JsonObject();
			json.addProperty("type", getType());
			json.addProperty("id", stack.getId().toString());
			if (nbt != null) {
				json.addProperty("nbt", nbt);
			}
			if (stack.getAmount() != 1) {
				json.addProperty("amount", stack.getAmount());
			}
			if (stack.getChance() != 1) {
				json.addProperty("chance", stack.getChance());
			}
			if (!stack.getRemainder().isEmpty()) {
				EmiStack remainder = stack.getRemainder();
				if (!remainder.getRemainder().isEmpty()) {
					remainder = remainder.copy().setRemainder(EmiStack.EMPTY);
				}
				if (remainder.getRemainder().isEmpty()) {
					JsonElement remainderElement = EmiIngredientSerializer.getSerialized(remainder);
					if (remainderElement != null) {
						json.add("remainder", remainderElement);
					}
				}
			}
			return json;
		}
	}
}
