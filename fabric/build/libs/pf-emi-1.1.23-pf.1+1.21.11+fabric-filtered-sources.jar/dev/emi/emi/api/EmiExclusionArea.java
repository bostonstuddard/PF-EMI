package dev.emi.emi.api;

import java.util.function.Consumer;
import net.minecraft.class_437;
import dev.emi.emi.api.widget.Bounds;

public interface EmiExclusionArea<T extends class_437> {
	
	void addExclusionArea(T screen, Consumer<Bounds> consumer);
}
