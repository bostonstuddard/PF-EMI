package dev.emi.emi.search;

import java.util.Set;
import net.minecraft.class_2561;
import com.google.common.collect.Sets;

import dev.emi.emi.api.stack.EmiStack;

public class NameQuery extends Query {
	private final Set<EmiStack> valid = Sets.newIdentityHashSet();
	private final String name;
	
	public NameQuery(String name) {
		EmiSearch.names.method_4804(name.toLowerCase()).forEach(s -> valid.add(s.stack));
		this.name = name.toLowerCase();
	}

	@Override
	public boolean matches(EmiStack stack) {
		return valid.contains(stack);
	}

	@Override
	public boolean matchesUnbaked(EmiStack stack) {
		return getText(stack).getString().toLowerCase().contains(name);
	}

	public static class_2561 getText(EmiStack stack) {
		return stack.getName();
	}
}
