package dev.emi.emi.registry;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_437;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.EmiStackProvider;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.EmiStackInteraction;
import dev.emi.emi.mixin.accessor.CraftingResultSlotAccessor;
import dev.emi.emi.mixin.accessor.HandledScreenAccessor;
import dev.emi.emi.platform.EmiAgnos;

public class EmiStackProviders {
	public static Map<Class<?>, List<EmiStackProvider<?>>> fromClass = Maps.newHashMap();
	public static List<EmiStackProvider<?>> generic = Lists.newArrayList();

	public static void clear() {
		fromClass.clear();
		generic.clear();
	}
	
	@SuppressWarnings({"unchecked", "rawtypes"})
	public static EmiStackInteraction getStackAt(class_437 screen, int x, int y, boolean notClick) {
		if (fromClass.containsKey(screen.getClass())) {
			for (EmiStackProvider provider : fromClass.get(screen.getClass())) {
				EmiStackInteraction stack = provider.getStackAt(screen, x, y);
				if (!stack.isEmpty() && (notClick || stack.isClickable())) {
					return stack;
				}
			}
		}
		for (EmiStackProvider handler : generic) {
			EmiStackInteraction stack = handler.getStackAt(screen, x, y);
			if (!stack.isEmpty() && (notClick || stack.isClickable())) {
				return stack;
			}
		}
		if (notClick && screen instanceof HandledScreenAccessor handled) {
			class_1735 s = handled.getFocusedSlot();
			if (s != null) {
				class_1799 stack = s.method_7677();
				if (!stack.method_7960()) {
					if (s instanceof class_1734 craf) {
						// Emi be making assumptions
						try {
							class_8566 inv = ((CraftingResultSlotAccessor) craf).getInput();
							class_9694 input = class_9694.method_59986(inv.method_17398(), inv.method_17397(), inv.method_51305());
							class_310 client = class_310.method_1551();
                            List<class_3955> list
								= EmiAgnos.getAllMatchesRecipe(client.field_1687.method_8433(), class_3956.field_17545, input, client.field_1687).map(class_8786::comp_1933).toList();
							if (!list.isEmpty()) {
								class_2960 id = EmiPort.getId(list.get(0));
								EmiRecipe recipe = EmiApi.getRecipeManager().getRecipe(id);
								if (recipe != null) {
									return new EmiStackInteraction(EmiStack.of(stack), recipe, false);
								}
							}
						} catch (Exception e) {
						}
					}
					return new EmiStackInteraction(EmiStack.of(stack));
				}
			}
		}
		return EmiStackInteraction.EMPTY;
	}
}
