package dev.emi.emi.registry;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_310;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_9326;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.Comparison;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiRegistryAdapter;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.config.EmiConfig;
import dev.emi.emi.config.IndexSource;
import dev.emi.emi.data.EmiAlias;
import dev.emi.emi.data.EmiData;
import dev.emi.emi.data.IndexStackData;
import dev.emi.emi.runtime.EmiHidden;
import dev.emi.emi.runtime.EmiLog;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenCustomHashSet;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;

public class EmiStackList {
	private static final class_6862<class_1792> ITEM_HIDDEN = class_6862.method_40092(EmiPort.getItemRegistry().method_46765(), EmiTags.HIDDEN_FROM_RECIPE_VIEWERS);
	private static final class_6862<class_2248> BLOCK_HIDDEN = class_6862.method_40092(EmiPort.getBlockRegistry().method_46765(), EmiTags.HIDDEN_FROM_RECIPE_VIEWERS);
	private static final class_6862<class_3611> FLUID_HIDDEN = class_6862.method_40092(EmiPort.getFluidRegistry().method_46765(), EmiTags.HIDDEN_FROM_RECIPE_VIEWERS);
	public static List<EmiAlias.Baked> registryAliases = Lists.newArrayList();
	public static List<Predicate<EmiStack>> invalidators = Lists.newArrayList();
	public static List<EmiStack> stacks = List.of();
	public static List<EmiStack> filteredStacks = List.of();
	private static Object2IntMap<EmiStack> strictIndices = new Object2IntOpenCustomHashMap<>(new StrictHashStrategy());
	private static Object2IntMap<Object> keyIndices = new Object2IntOpenHashMap<>();

	public static void clear() {
		invalidators.clear();
		registryAliases.clear();
		stacks = List.of();
		strictIndices.clear();
		keyIndices.clear();
	}

	public static void reload() {
		class_310 client = class_310.method_1551();
		class_1761.class_8128 context = new class_1761.class_8128(client.field_1724.field_3944.method_45735(), false, client.field_1687.method_30349());
		List<IndexGroup> groups = Lists.newArrayList();
		Map<String, IndexGroup> namespaceGroups = new LinkedHashMap<>();
		for (class_1792 item : EmiPort.getItemRegistry()) {
			String itemName = "null";
			try {
				itemName = item.toString();
				EmiStack stack = EmiStack.of(item);
				namespaceGroups.computeIfAbsent(stack.getId().method_12836(), (k) -> new IndexGroup()).stacks.add(stack);
			} catch (Exception e) {
				EmiLog.error("Item " + itemName + " threw while EMI was attempting to construct the index, items may be missing.", e);
			}
		}
		if (EmiConfig.indexSource != IndexSource.REGISTERED) {
			// There is an unwritten convention that ItemGroup.updateEntries is only invoked on the main thread
			long groupReloadStart = System.currentTimeMillis();
			EmiLog.info("Reloading item groups on client thread...");
			Map<class_1761, Collection<class_1799>> itemGroupToStacksMap = client.method_5385(() -> {
				Map<class_1761, Collection<class_1799>> map = new Reference2ReferenceOpenHashMap<>();
				Consumer<class_1761> itemGroupConsumer = group -> {
					String groupName = "null";
					try {
						groupName = group.method_7737().toString();
						group.method_47306(context);
						map.put(group, group.method_45414());
					} catch(Exception e) {
						EmiLog.error("Creative item group " + groupName + " threw while EMI was attempting to construct the index, items may be missing.", e);
					}
				};
				List<class_1761> itemGroups = class_7706.method_47341();
				// Category item groups must be updated before non-category ones, otherwise the search group will
				// read outdated item lists
				itemGroups.stream().filter(g -> g.method_47312() == class_1761.class_7916.field_41052).forEach(itemGroupConsumer);
				itemGroups.stream().filter(g -> g.method_47312() != class_1761.class_7916.field_41052).forEach(itemGroupConsumer);
				return map;
			}).join();
			EmiLog.info("Reloading item groups on client thread took " + (System.currentTimeMillis() - groupReloadStart) + "ms");
			for (class_1761 group : class_7706.method_47341()) {
				String groupName = "null";
				try {
					groupName = group.method_7737().getString();
					Object2IntMap<String> usedNamespaces = new Object2IntOpenHashMap<>();
					IndexGroup ig = new IndexGroup();
					Collection<class_1799> searchStacks = itemGroupToStacksMap.get(group);
					for (class_1799 stack : searchStacks) {
						EmiStack es = EmiStack.of(stack);
						String namespace = es.getId().method_12836();
						usedNamespaces.put(namespace, usedNamespaces.getOrDefault(namespace, 0) + 1);
						ig.stacks.add(es);
					}
					if (EmiConfig.indexSource == IndexSource.CREATIVE) {
						for (String namespace : usedNamespaces.keySet()) {
							if (namespaceGroups.containsKey(namespace)) {
								IndexGroup ng = namespaceGroups.get(namespace);
								if (usedNamespaces.getInt(namespace) * 3 >= searchStacks.size() || usedNamespaces.getInt(namespace) * 3 >= ng.stacks.size()) {
									ng.suppressedBy.add(ig);
								}
							}
						}
					}
					groups.add(ig);
				} catch (Exception e) {
					EmiLog.error("Creative item group " + groupName + " threw while EMI was attempting to construct the index, items may be missing.", e);
				}
			}
		}
		groups.addAll(namespaceGroups.values());
		IndexGroup fluidGroup = new IndexGroup();
		for (class_3611 fluid : EmiPort.getFluidRegistry()) {
			String fluidName = null;
			try {
				fluidName = fluid.toString();
				if (fluid.method_15793(fluid.method_15785()) || (fluid instanceof class_3609 ff && ff.method_15751() == class_3612.field_15906)) {
					EmiStack fs = EmiStack.of(fluid);
					fluidGroup.stacks.add(fs);
				}
			} catch (Exception e) {
				EmiLog.error("Fluid  " + fluidName + " threw while EMI was attempting to construct the index, stack may be missing.", e);
			}
		}
		groups.add(fluidGroup);

		Set<EmiStack> added = new ObjectOpenCustomHashSet<>(new StrictHashStrategy());
		
		stacks = Lists.newLinkedList();
		for (IndexGroup group : groups) {
			if (group.shouldDisplay()) {
				for (EmiStack stack : group.stacks) {
					if (!added.contains(stack)) {
						stacks.add(stack);
						added.add(stack);
					}
				}
			}
		}
	}

	@SuppressWarnings({"deprecation", "unchecked"})
	private static <T> boolean isHiddenFromRecipeViewers(T key) {
		if (key instanceof class_1792 i) {
			if (i instanceof class_1747 bi && bi.method_7711().method_9564().method_26164(BLOCK_HIDDEN)) {
				return true;
			} else if (i.method_40131().method_40220(ITEM_HIDDEN)) {
				return true;
			}
		} else if (key instanceof class_3611 f) {
			if (f.method_15791(FLUID_HIDDEN)) {
				return true;
			}
		} else {
			EmiRegistryAdapter<T> adapter = (EmiRegistryAdapter<T>) EmiTags.ADAPTERS_BY_CLASS.get(key.getClass());
			if (adapter != null) {
				return adapter.getRegistry().method_47983(key).method_40220(class_6862.method_40092(adapter.getRegistry().method_46765(), EmiTags.HIDDEN_FROM_RECIPE_VIEWERS));
			}
		}
		return false;
	}

	public static void bake() {
		stacks.removeIf(s -> {
			try {
				if (s.isEmpty()) {
					return true;
				}
				for (Predicate<EmiStack> invalidator : invalidators) {
					if (invalidator.test(s)) {
						return true;
					}
				}
				if (isHiddenFromRecipeViewers(s.getKey())) {
					return true;
				}
				return false;
			} catch (Throwable t) {
				EmiLog.error("Stack threw error while baking", t);
				return true;
			}
		});
		for (Supplier<IndexStackData> supplier : EmiData.stackData) {
			IndexStackData ssd = supplier.get();
			if (!ssd.removed().isEmpty()) {
				Set<EmiStack> removed = Sets.newHashSet();
				for (EmiIngredient invalidator : ssd.removed()) {
					for (EmiStack stack : invalidator.getEmiStacks()) {
						removed.add(stack.copy().comparison(c -> EmiPort.compareStrict()));
					}
				}
				stacks.removeAll(removed);
			}
			if (!ssd.filters().isEmpty()) {
				stacks.removeIf(s -> {
					String id = "" + s.getId();
					for (IndexStackData.Filter filter : ssd.filters()) {
						if (filter.filter().test(id)) {
							return true;
						}
					}
					return false;
				});
			}
			for (IndexStackData.Added added : ssd.added()) {
				if (added.added().isEmpty()) {
					continue;
				}
				if (added.after().isEmpty()) {
					stacks.add(added.added().getEmiStacks().get(0));
				} else {
					int i = stacks.indexOf(added.after());
					if (i == -1) {
						i = stacks.size() - 1;
					}
					stacks.add(i + 1, added.added().getEmiStacks().get(0));
				}
			}
		}
		stacks = stacks.stream().filter(stack -> {
			String name = "Unknown";
			String id = "unknown";
			try {
				if (stack.isEmpty()) {
					return false;
				}
				name = stack.toString();
				id = stack.getId().toString();
				if (name != null && stack.getKey() != null && stack.getName() != null) {
					return true;
				}
				EmiLog.warn("Hiding stack " + name + " with id " + id + " from index due to returning dangerous values");
				return false;
			} catch (Throwable t) {
				EmiLog.error("Hiding stack " + name + " with id " + id + " from index due to throwing errors", t);
				return false;
			}
		}).toList();
		for (int i = 0; i < stacks.size(); i++) {
			EmiStack stack = stacks.get(i);
			strictIndices.put(stack, i);
			keyIndices.put(stack.getKey(), i);
		}
		bakeFiltered();
	}

	public static void bakeFiltered() {
		filteredStacks = stacks.stream().filter(s -> !EmiHidden.isDisabled(s) && !EmiHidden.isHidden(s)).toList();
	}

	public static int getIndex(EmiIngredient ingredient) {
		EmiStack stack = ingredient.getEmiStacks().get(0);
		int ret = strictIndices.getOrDefault(stack, Integer.MAX_VALUE);
		if (ret == Integer.MAX_VALUE) {
			ret = keyIndices.getOrDefault(stack, ret);
		}
		return ret;
	}

	public static class IndexGroup {
		public List<EmiStack> stacks = Lists.newArrayList();
		public Set<IndexGroup> suppressedBy = Sets.newHashSet();

		public boolean shouldDisplay() {
			for (IndexGroup suppressor : suppressedBy) {
				if (suppressor.shouldDisplay()) {
					return false;
				}
			}
			return true;
		}
	}

	public static class StrictHashStrategy implements Hash.Strategy<EmiStack> {

		@Override
		public boolean equals(EmiStack a, EmiStack b) {
			if (a == b) {
				return true;
			} else if (a == null || b == null) {
				return false;
			} else if (a.isEmpty() && b.isEmpty()) {
				return true;
			}
			return a.isEqual(b, EmiPort.compareStrict());
		}

		@Override
		public int hashCode(EmiStack stack) {
			if (stack != null) {
				class_9326 changes = stack.getComponentChanges();
				int i = 31 + stack.getKey().hashCode();
				return 31 * i + changes.hashCode();
			}
			return 0;
		}
	}

	public static class ComparisonHashStrategy implements Hash.Strategy<EmiStack> {

		@Override
		public boolean equals(EmiStack a, EmiStack b) {
			if (a == b) {
				return true;
			} else if (a == null || b == null) {
				return false;
			} else if (a.isEmpty() && b.isEmpty()) {
				return true;
			}
			return a.isEqual(b, EmiComparisonDefaults.get(a.getKey()));
		}

		@Override
		public int hashCode(EmiStack stack) {
			if (stack != null) {
				int i = 31 + stack.getKey().hashCode();
				return 31 * i + EmiComparisonDefaults.get(stack.getKey()).getHash(stack);
			}
			return 0;
		}
	}
}
