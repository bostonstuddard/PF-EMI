package dev.emi.emi.registry;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_437;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import dev.emi.emi.api.EmiExclusionArea;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.screen.EmiScreenBase;
import dev.emi.emi.screen.EmiScreenManager;

public class EmiExclusionAreas {
	public static Map<Class<?>, List<EmiExclusionArea<?>>> fromClass = Maps.newHashMap();
	public static List<EmiExclusionArea<?>> generic = Lists.newArrayList();

	public static void clear() {
		fromClass.clear();
		generic.clear();
	}
	
	@SuppressWarnings({"unchecked", "rawtypes"})
	public static List<Bounds> getExclusion(EmiScreenBase base) {
		class_437 screen = base.screen();
		List<Bounds> list = Lists.newArrayList();
		list.add(base.bounds());
		// EMI buttons
		list.add(new Bounds(0, screen.field_22790 - 22, base.bounds().left(), 22));
		// Search bar
		if (EmiScreenManager.search.method_1885()) {
			list.add(new Bounds(EmiScreenManager.search.field_22760 - 1, EmiScreenManager.search.field_22761 - 1, EmiScreenManager.search.method_25368() + 2, EmiScreenManager.search.method_25364() + 2));
		}
		try {
			if (fromClass.containsKey(screen.getClass())) {
				for (EmiExclusionArea exclusion : fromClass.get(screen.getClass())) {
					exclusion.addExclusionArea(screen, addBounds(list));
				}
			}
			for (EmiExclusionArea exclusion : generic) {
				exclusion.addExclusionArea(screen, addBounds(list));
			}
		} catch (Exception e) {
			EmiLog.error("Exception thrown when adding exclusion areas", e);
		}
		return list;
	}

	private static Consumer<Bounds> addBounds(List<Bounds> list) {
		return rect -> {
			// Impossible sizing, or integer overflow
			if (rect.empty() || rect.right() <= rect.x() || rect.bottom() <= rect.y()) {
				return;
			}
			list.add(rect);
		};
	}
}
