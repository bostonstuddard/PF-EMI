package dev.emi.emi.registry;

import static net.minecraft.class_2232.method_9441;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

import org.jetbrains.annotations.Nullable;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;

import dev.emi.emi.network.CommandS2CPacket;
import dev.emi.emi.network.EmiNetwork;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class EmiCommands {
	public static final byte VIEW_RECIPE = 0x01;
	public static final byte VIEW_TREE = 0x02;
	public static final byte TREE_GOAL = 0x11;
	public static final byte TREE_RESOLUTION = 0x12;
	
	public static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(method_9247("emi")
			.requires(source -> source.method_75037().hasPermission(class_12099.field_63210))
			.then(
				method_9247("view")
				.then(
					method_9247("recipe")
					.then(
						method_9244("id", method_9441())
						.executes(context -> {
							send(context.getSource().method_44023(), VIEW_RECIPE, context.getArgument("id", class_2960.class));
							return Command.SINGLE_SUCCESS;
						})
					)
				)
				.then(
					method_9247("tree")
					.executes(context -> {
						send(context.getSource().method_44023(), VIEW_TREE, null);
						return Command.SINGLE_SUCCESS;
					})
				)
			)
			.then(
				method_9247("tree")
				.then(
					method_9247("goal")
					.then(
						method_9244("id", method_9441())
						.executes(context -> {
							send(context.getSource().method_44023(), TREE_GOAL, context.getArgument("id", class_2960.class));
							return Command.SINGLE_SUCCESS;
						})
					)
				)
				.then(
					method_9247("resolution")
					.then(
						method_9244("id", method_9441())
						.executes(context -> {
							send(context.getSource().method_44023(), TREE_RESOLUTION, context.getArgument("id", class_2960.class));
							return Command.SINGLE_SUCCESS;
						})
					)
				)
			)
		);
	}

	private static void send(class_3222 player, byte type, @Nullable class_2960 id) {
		EmiNetwork.sendToClient(player, new CommandS2CPacket(type, id));
	}
}
