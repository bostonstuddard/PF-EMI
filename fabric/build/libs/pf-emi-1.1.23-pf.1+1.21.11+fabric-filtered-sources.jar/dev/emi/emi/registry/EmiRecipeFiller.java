package dev.emi.emi.registry;

import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3917;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_636;
import net.minecraft.class_8566;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import dev.emi.emi.api.EmiApi;
import dev.emi.emi.api.recipe.EmiPlayerInventory;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.handler.EmiCraftContext;
import dev.emi.emi.api.recipe.handler.EmiRecipeHandler;
import dev.emi.emi.api.recipe.handler.StandardRecipeHandler;
import dev.emi.emi.api.stack.Comparison;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.handler.CoercedRecipeHandler;
import dev.emi.emi.mixin.accessor.CraftingResultSlotAccessor;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.runtime.EmiSidebars;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

public class EmiRecipeFiller {
	public static Map<class_3917<?>, List<EmiRecipeHandler<?>>> handlers = Maps.newHashMap();
	public static BiFunction<class_1703, EmiRecipe, EmiRecipeHandler<?>> extraHandlers = (h, r) -> null;

	public static void clear() {
		handlers.clear();
		extraHandlers = (h, r) -> null;
	}

	public static boolean isSupported(EmiRecipe recipe) {
		for (List<EmiRecipeHandler<?>> list : handlers.values()) {
			for (EmiRecipeHandler<?> handler : list) {
				if (handler.supportsRecipe(recipe) && handler.alwaysDisplaySupport(recipe)) {
					return true;
				}
			}
		}
		class_465<?> hs = EmiApi.getHandledScreen();
		if (hs != null) {
			for (EmiRecipeHandler<?> handler : getAllHandlers(hs)) {
				if (handler.supportsRecipe(recipe)) {
					return true;
				}
			}
			EmiRecipeHandler<?> handler = extraHandlers.apply(hs.method_17577(), recipe);
			if (handler != null && handler.supportsRecipe(recipe)) {
				return true;
			}
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public static <T extends class_1703> List<EmiRecipeHandler<T>> getAllHandlers(class_465<T> screen) {
		if (screen != null) {
			T screenHandler = screen.method_17577();
			class_3917<?> type;
			try {
				type = screenHandler instanceof class_1723 ? null : screenHandler.method_17358();
			} catch (UnsupportedOperationException e) {
				type = null;
			}
			if ((type != null || screenHandler instanceof class_1723) && handlers.containsKey(type)) {
				return (List<EmiRecipeHandler<T>>) (List<?>) handlers.get(type);
			}
			for (class_1735 slot : screen.method_17577().field_7761) {
				if (slot instanceof class_1734 crs) {
					class_8566 inv = ((CraftingResultSlotAccessor) crs).getInput();
					if (inv != null && inv.method_17398() > 0 && inv.method_17397() > 0) {
						return List.of(new CoercedRecipeHandler<T>(crs));
					}
				}
			}
		}
		return List.of();
	}

	@SuppressWarnings("unchecked")
	public static <T extends class_1703> @Nullable EmiRecipeHandler<T> getFirstValidHandler(EmiRecipe recipe, class_465<T> screen) {
		EmiRecipeHandler<T> ret = null;
		for (EmiRecipeHandler<T> handler : getAllHandlers(screen)) {
			if (handler.supportsRecipe(recipe)) {
				ret = handler;
				break;
			}
		}
		if (ret == null || (ret instanceof CoercedRecipeHandler && !(screen instanceof class_490))) {
			EmiRecipeHandler<T> extra = (EmiRecipeHandler<T>) extraHandlers.apply(screen.method_17577(), recipe);
			if (extra != null) {
				ret = extra;
			}
		}
		return ret;
	}

	public static <T extends class_1703> boolean performFill(EmiRecipe recipe, class_465<T> screen,
			EmiCraftContext.Type type, EmiCraftContext.Destination destination, int amount) {
		EmiRecipeHandler<T> handler = getFirstValidHandler(recipe, screen);
		if (handler != null && handler.supportsRecipe(recipe)) {
			EmiPlayerInventory inv = handler.getInventory(screen);
			EmiCraftContext<T> context = new EmiCraftContext<T>(screen, inv, type, destination, amount);
			if (handler.canCraft(recipe, context)) {
				EmiSidebars.craft(recipe);
				boolean crafted = handler.craft(recipe, context);
				if (crafted) {
					class_310.method_1551().method_1507(screen);
				}
				return crafted;
			}
		}
		return false;
	}

	public static <T extends class_1703> @Nullable List<class_1799> getStacks(StandardRecipeHandler<T> handler, EmiRecipe recipe, class_465<T> screen, int amount) {
		try {
			T screenHandler = screen.method_17577();
			if (handler != null) {
				List<class_1735> slots = handler.getInputSources(screenHandler);
				List<class_1735> craftingSlots = handler.getCraftingSlots(recipe, screenHandler);
				List<EmiIngredient> ingredients = recipe.getInputs();
				List<DiscoveredItem> discovered = Lists.newArrayList();
				Object2IntMap<EmiStack> weightDivider = new Object2IntOpenHashMap<>();
				for (int i = 0; i < ingredients.size(); i++) {
					List<DiscoveredItem> d = Lists.newArrayList();
					EmiIngredient ingredient = ingredients.get(i);
					List<EmiStack> emiStacks = ingredient.getEmiStacks();
					if (ingredient.isEmpty()) {
						discovered.add(null);
						continue;
					}
					for (int e = 0; e < emiStacks.size(); e++) {
						EmiStack stack = emiStacks.get(e);
						slotLoop:
						for (class_1735 s : slots) {
							class_1799 ss = s.method_7677();
							if (EmiStack.of(s.method_7677()).isEqual(stack)) {
								for (DiscoveredItem di : d) {
									if (class_1799.method_31577(ss, di.stack)) {
										di.amount += ss.method_7947();
										continue slotLoop;
									}
								}
								d.add(new DiscoveredItem(stack, ss, ss.method_7947(), (int) ingredient.getAmount(), ss.method_7914()));
							}
						}
					}
					DiscoveredItem biggest = null;
					for (DiscoveredItem di : d) {
						if (biggest == null) {
							biggest = di;
						} else {
							int a = di.amount / (weightDivider.getOrDefault(di.ingredient, 0) + di.consumed);
							int ba = biggest.amount / (weightDivider.getOrDefault(biggest.ingredient, 0) + biggest.consumed);
							if (ba < a) {
								biggest = di;
							}
						}
					}
					if (biggest == null || i >= craftingSlots.size()) {
						return null;
					}
					class_1735 slot = craftingSlots.get(i);
					if (slot == null) {
						return null;
					}
					weightDivider.put(biggest.ingredient, weightDivider.getOrDefault(biggest.ingredient, 0) + biggest.consumed);
					biggest.max = Math.min(biggest.max, slot.method_7675());
					discovered.add(biggest);
				}
				if (discovered.isEmpty()) {
					return null;
				}

				List<DiscoveredItem> unique = Lists.newArrayList();
				outer:
				for (DiscoveredItem di : discovered) {
					if (di == null) {
						continue;
					}
					for (DiscoveredItem ui : unique) {
						if (class_1799.method_31577(di.stack, ui.stack)) {
							ui.consumed += di.consumed;
							continue outer;
						}
					}
					unique.add(new DiscoveredItem(di.ingredient, di.stack, di.amount, di.consumed, di.max));
				}
				int maxAmount = Integer.MAX_VALUE;
				for (DiscoveredItem ui : unique) {
					if (!ui.catalyst()) {
						maxAmount = Math.min(maxAmount, ui.amount / ui.consumed);
						maxAmount = Math.min(maxAmount, ui.max);
					}
				}
				maxAmount = Math.min(maxAmount, amount + batchesAlreadyPresent(recipe, handler, screen));

				if (maxAmount == 0) {
					return null;
				}

				List<class_1799> desired = Lists.newArrayList();
				for (int i = 0; i < discovered.size(); i++) {
					DiscoveredItem di = discovered.get(i);
					if (di != null) {
						class_1799 is = di.stack.method_7972();
						int a = di.catalyst() ? di.consumed : di.consumed * maxAmount;
						is.method_7939(a);
						desired.add(is);
					} else {
						desired.add(class_1799.field_8037);
					}
				}
				return desired;
			}
		} catch (Exception e) {
			EmiLog.error("Error collecting stacks", e);
		}
		return null;
	}

	public static <T extends class_1703> int batchesAlreadyPresent(EmiRecipe recipe, StandardRecipeHandler<T> handler, class_465<T> screen) {
		List<EmiIngredient> inputs = recipe.getInputs();
		List<class_1799> stacks = Lists.newArrayList();
		class_1735 output = handler.getOutputSlot(screen.method_17577());
		if (output != null && !output.method_7677().method_7960() && recipe.getOutputs().size() > 0
				&& !class_1799.method_7973(output.method_7677(), recipe.getOutputs().get(0).getItemStack())) {
			return 0;
		}
		for (class_1735 slot : handler.getCraftingSlots(recipe, screen.method_17577())) {
			if (slot != null) {
				stacks.add(slot.method_7677());
			} else {
				stacks.add(class_1799.field_8037);
			}
		}
		long amount = Long.MAX_VALUE;
		outer:
		for (int i = 0; i < inputs.size(); i++) {
			EmiIngredient input = inputs.get(i);
			if (input.isEmpty()) {
				if (stacks.get(i).method_7960()) {
					continue;
				}
				return 0;
			}
			if (i >= stacks.size()) {
				return 0;
			}
			EmiStack es = EmiStack.of(stacks.get(i));
			for (EmiStack v : input.getEmiStacks()) {
				if (v.isEmpty()) {
					continue;
				}
				if (v.isEqual(es) && es.getAmount() >= v.getAmount()) {
					amount = Math.min(amount, es.getAmount() / v.getAmount());
					continue outer;
				}
			}
			return 0;
		}
		if (amount < Long.MAX_VALUE && amount > 0) {
			return (int) amount;
		}
		return 0;
	}

	public static <T extends class_1703> boolean clientFill(StandardRecipeHandler<T> handler, EmiRecipe recipe,
			class_465<T> screen, List<class_1799> stacks, EmiCraftContext.Destination destination) {
		T screenHandler = screen.method_17577();
		if (handler != null && screenHandler.method_34255().method_7960()) {
			class_310 client = class_310.method_1551();
			class_636 manager = client.field_1761;
			class_1657 player = client.field_1724;
			List<class_1735> clear = handler.getCraftingSlots(screenHandler);
			for (class_1735 slot : clear) {
				if (slot != null) {
					manager.method_2906(screenHandler.field_7763, slot.field_7874, 0, class_1713.field_7794, player);
				}
			}
			List<class_1735> inputs = handler.getInputSources(screenHandler);
			List<class_1735> slots = handler.getCraftingSlots(recipe, screenHandler);
			outer:
			for (int i = 0; i < stacks.size(); i++) {
				class_1799 stack = stacks.get(i);
				if (stack.method_7960()) {
					continue;
				}
				if (i >= slots.size()) {
					return false;
				}
				class_1735 crafting = slots.get(i);
				if (crafting == null) {
					return false;
				}
				int needed = stack.method_7947();
				for (class_1735 input : inputs) {
					if (slots.contains(input)) {
						continue;
					}
					class_1799 is = input.method_7677().method_7972();
					if (class_1799.method_31577(is, stack)) {
						manager.method_2906(screenHandler.field_7763, input.field_7874, 0, class_1713.field_7790, player);
						if (is.method_7947() <= needed) {
							needed -= is.method_7947();
							manager.method_2906(screenHandler.field_7763, crafting.field_7874, 0, class_1713.field_7790, player);
						} else {
							while (needed > 0) {
								manager.method_2906(screenHandler.field_7763, crafting.field_7874, 1, class_1713.field_7790, player);
								needed--;
							}
							manager.method_2906(screenHandler.field_7763, input.field_7874, 0, class_1713.field_7790, player);
						}
					}
					if (needed == 0) {
						continue outer;
					}
				}
				return false;
			}
			class_1735 slot = handler.getOutputSlot(screenHandler);
			if (slot != null) {
				if (destination == EmiCraftContext.Destination.CURSOR) {
					manager.method_2906(screenHandler.field_7763, slot.field_7874, 0, class_1713.field_7790, player);
				} else if (destination == EmiCraftContext.Destination.INVENTORY) {
					manager.method_2906(screenHandler.field_7763, slot.field_7874, 0, class_1713.field_7794, player);
				}
			}
			return true;
		}
		return false;
	}

	private static class DiscoveredItem {
		private static final Comparison COMPARISON = Comparison.DEFAULT_COMPARISON;
		public EmiStack ingredient;
		public class_1799 stack;
		public int consumed;
		public int amount;
		public int max;

		public DiscoveredItem(EmiStack ingredient, class_1799 stack, int amount, int consumed, int max) {
			this.ingredient = ingredient;
			this.stack = stack.method_7972();
			this.amount = amount;
			this.consumed = consumed;
			this.max = max;
		}

		public boolean catalyst() {
			return ingredient.getRemainder().isEqual(ingredient, COMPARISON);
		}
	}
}
