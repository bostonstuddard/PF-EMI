package dev.emi.emi.runtime;

import net.minecraft.class_10209;

public class EmiProfiler {
    public static void push(String name) {
        class_10209.method_64146().method_15396(name);
	}

	public static void pop() {
        class_10209.method_64146().method_15407();
	}

	public static void swap(String name) {
        class_10209.method_64146().method_15405(name);
	}
}
