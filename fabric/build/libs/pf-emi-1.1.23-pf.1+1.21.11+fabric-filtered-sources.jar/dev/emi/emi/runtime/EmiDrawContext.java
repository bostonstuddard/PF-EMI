package dev.emi.emi.runtime;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiIngredient;
import net.minecraft.class_1058;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import org.joml.Matrix3x2fStack;

public class EmiDrawContext {
	private final class_310 client = class_310.method_1551();
	private final class_332 context;
	
	private EmiDrawContext(class_332 context) {
		this.context = context;
	}

	public static EmiDrawContext wrap(class_332 context) {
		return new EmiDrawContext(context);
	}

	public class_332 raw() {
		return context;
	}

	public Matrix3x2fStack matrices() {
		return context.method_51448();
	}

	public void push() {
		matrices().pushMatrix();
	}

	public void pop() {
		matrices().popMatrix();
	}

	public void drawTexture(class_2960 texture, int x, int y, int u, int v, int width, int height) {
		drawTexture(texture, x, y, width, height, u, v, width, height, 256, 256);
	}

    public void drawTexture(class_2960 texture, int x, int y, int u, int v, int width, int height, int color) {
        drawTexture(texture, x, y, width, height, u, v, width, height, 256, 256, color);
    }

	public void drawTexture(class_2960 texture, int x, int y, int z, float u, float v, int width, int height) {
		drawTexture(texture, x, y, z, u, v, width, height, 256, 256);
	}

	public void drawTexture(class_2960 texture, int x, int y, int z, float u, float v, int width, int height, int textureWidth, int textureHeight) {
		context.method_25290(class_10799.field_56883, texture, x, y, /* z,*/ u, v, width, height, textureWidth, textureHeight);
	}

	public void drawTexture(class_2960 texture, int x, int y, int width, int height, float u, float v, int regionWidth, int regionHeight, int textureWidth, int textureHeight) {
		context.method_25302(class_10799.field_56883, texture, x, y, u, v, width, height, regionWidth, regionHeight, textureWidth, textureHeight);
	}

    public void drawTexture(class_2960 texture, int x, int y, int width, int height, float u, float v, int regionWidth, int regionHeight, int textureWidth, int textureHeight, int color) {
        context.method_25293(class_10799.field_56883, texture, x, y, u, v, width, height, regionWidth, regionHeight, textureWidth, textureHeight, color);
    }

    public void drawSpriteStretched(class_1058 sprite, int x, int y, int width, int height, int color) {
        context.method_52710(class_10799.field_56883, sprite, x, y, width, height, color);
    }

	public void fill(int x, int y, int width, int height, int color) {
		context.method_25294(x, y, x + width, y + height, color);
	}

	public void drawText(class_2561 text, int x, int y) {
		drawText(text, x, y, -1);
	}

	public void drawText(class_2561 text, int x, int y, int color) {
		context.method_51439(client.field_1772, text, x, y, color, false);
	}

	public void drawText(class_5481 text, int x, int y, int color) {
		context.method_51430(client.field_1772, text, x, y, color, false);
	}

	public void drawTextWithShadow(class_2561 text, int x, int y) {
		drawTextWithShadow(text, x, y, -1);
	}

	public void drawTextWithShadow(class_2561 text, int x, int y, int color) {
		context.method_51439(client.field_1772, text, x, y, color, true);
	}

	public void drawTextWithShadow(class_5481 text, int x, int y, int color) {
		context.method_51430(client.field_1772, text, x, y, color, true);
	}

	public void drawCenteredText(class_2561 text, int x, int y) {
		drawCenteredText(text, x, y, -1);
	}

	public void drawCenteredText(class_2561 text, int x, int y, int color) {
		context.method_51439(client.field_1772, text, x - client.field_1772.method_27525(text) / 2, y, color, false);
	}

	public void drawCenteredTextWithShadow(class_2561 text, int x, int y) {
		drawCenteredTextWithShadow(text, x, y, -1);
	}

	public void drawCenteredTextWithShadow(class_2561 text, int x, int y, int color) {
		context.method_35719(client.field_1772, text.method_30937(), x, y, color);
	}

	public void enableDepthTest() {
//		RenderSystem.enableDepthTest();
	}

	public void disableDepthTest() {
//		RenderSystem.disableDepthTest();
	}

	public void enableBlend() {
//		RenderSystem.enableBlend();
	}

	public void disableBlend() {
//		RenderSystem.disableBlend();
	}

	public void resetColor() {
//		setColor(1f, 1f, 1f, 1f);
	}

	public void setColor(float r, float g, float b) {
//		setColor(r, g, b, 1f);
	}

	public void setColor(float r, float g, float b, float a) {
//		raw().setShaderColor(r, g, b, a);
	}

	public void drawStack(EmiIngredient stack, int x, int y) {
		stack.render(raw(), x, y, client.method_61966().method_60637(false));
	}

	public void drawStack(EmiIngredient stack, int x, int y, int flags) {
		drawStack(stack, x, y, client.method_61966().method_60637(false), flags);
	}

	public void drawStack(EmiIngredient stack, int x, int y, float delta, int flags) {
		stack.render(raw(), x, y, delta, flags);
	}
}
