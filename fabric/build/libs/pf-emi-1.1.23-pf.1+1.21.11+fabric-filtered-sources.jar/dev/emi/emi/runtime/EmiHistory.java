package dev.emi.emi.runtime;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import com.google.common.collect.Lists;

import dev.emi.emi.api.EmiApi;

public class EmiHistory {
	private static final List<class_437> HISTORIES = Lists.newArrayList();
	private static final List<class_437> FORWARD_HISTORIES = Lists.newArrayList();
	
	public static boolean isEmpty() {
		return HISTORIES.isEmpty();
	}

	public static boolean isForwardEmpty() {
		return FORWARD_HISTORIES.isEmpty();
	}

	public static void push(class_437 history) {
		HISTORIES.add(history);
		FORWARD_HISTORIES.clear();
	}

	public static void pop() {
		class_310 client = class_310.method_1551();
		if (client.field_1755 instanceof class_465) {
			clear();
			return;
		}
		int i = HISTORIES.size() - 1;
		class_465<?> screen = EmiApi.getHandledScreen();
		if (i >= 0) {
			class_437 popped = HISTORIES.remove(i);
			FORWARD_HISTORIES.add(client.field_1755);
			client.method_1507(popped);
		} else if (screen != null) {
			client.method_1507(screen);
		}
	}

	public static void popUntil(Predicate<class_437> predicate, class_437 otherwise) {
		class_310 client = class_310.method_1551();
		while (!EmiHistory.isEmpty()) {
			EmiHistory.pop();
			if (predicate.test(client.field_1755)) {
				return;
			}
		}
		client.method_1507(otherwise);
	}

	public static void forward() {
		class_310 client = class_310.method_1551();
		int i = FORWARD_HISTORIES.size() - 1;
		if (i >= 0 && client.field_1755 != null) {
			class_437 popped = FORWARD_HISTORIES.remove(i);
			HISTORIES.add(client.field_1755);
			client.method_1507(popped);
		}
	}

	public static void clear() {
		HISTORIES.clear();
		FORWARD_HISTORIES.clear();
	}
}
