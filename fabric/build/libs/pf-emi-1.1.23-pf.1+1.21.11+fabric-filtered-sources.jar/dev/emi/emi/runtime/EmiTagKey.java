package dev.emi.emi.runtime;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1074;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885.class_6888;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Maps;

import dev.emi.emi.EmiPort;
import dev.emi.emi.EmiUtil;
import dev.emi.emi.registry.EmiTags;

// Wrapper around TagKeys
public class EmiTagKey<T> {
	public static final Map<class_6862<?>, EmiTagKey<?>> CACHE = Maps.newHashMap();
	private final class_6862<T> raw;
	private List<T> cached;
	
	private EmiTagKey(class_6862<T> raw) {
		this.raw = raw;
		recalculate();
	}

	public void recalculate() {
		cached = stream().toList();
	}

	public class_6862<T> raw() {
		return raw;
	}

	public boolean isOf(class_2378<?> registry) {
		return raw.method_41007(registry.method_46765());
	}

	public class_2960 id() {
		return raw.comp_327();
	}

	public class_2378<T> registry() {
		class_310 client = class_310.method_1551();
		return client.field_1687.method_30349().method_46759(raw.comp_326()).orElse(null);
	}

	public Stream<T> stream() {
		class_2378<T> registry = registry();
		Optional<class_6888<T>> opt = registry.method_46733(raw);
		if (opt.isEmpty()) {
			return Stream.of();
		} else {
			if (registry == EmiPort.getFluidRegistry()) {
				return opt.get().method_40239().filter(o -> {
					class_3611 f = (class_3611) o.comp_349();
					return f.method_15793(f.method_15785());
				}).map(class_6880::comp_349);
			}
			return opt.get().method_40239().map(class_6880::comp_349);
		}
	}

	public List<T> getList() {
		return cached;
	}

	public Set<T> getSet() {
		return stream().collect(Collectors.toSet());
	}

	public class_2561 getTagName() {
		String s = getTagTranslationKey();
		if (s == null) {
			return EmiPort.literal("#" + this.id());
		} else {
			return EmiPort.translatable(s);
		}
	}

	public boolean hasTranslation() {
		return getTagTranslationKey() != null;
	}

	private @Nullable String getTagTranslationKey() {
		class_2960 registry = raw.comp_326().method_29177();
		if (registry.method_12836().equals("minecraft")) {
			String s = translatePrefix("tag." + registry.method_12832().replace("/", ".") + ".", this.id());
			if (s != null) {
				return s;
			}
		} else {
			String s = translatePrefix("tag." + registry.method_12836() + "." + registry.method_12832().replace("/", ".") + ".", this.id());
			if (s != null) {
				return s;
			}
		}
		return translatePrefix("tag.", this.id());
	}

	private static @Nullable String translatePrefix(String prefix, class_2960 id) {
		String s = EmiUtil.translateId(prefix, id);
		if (class_1074.method_4663(s)) {
			return s;
		}
		if (id.method_12836().equals("forge")) {
			s = EmiUtil.translateId(prefix, EmiPort.id("c", id.method_12832()));
			if (class_1074.method_4663(s)) {
				return s;
			}
		}
		return null;
	}

	public @Nullable class_2960 getCustomModel() {
		class_2960 rid = this.id();
		if (rid.method_12836().equals("forge") && !EmiTags.MODELED_TAGS.containsKey(raw())) {
			return EmiTagKey.of(registry(), EmiPort.id("c", rid.method_12832())).getCustomModel();
		}
		return EmiTags.MODELED_TAGS.get(raw());
	}

	public boolean hasCustomModel() {
		return getCustomModel() != null;
	}

	@Override
	public int hashCode() {
		return raw().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof EmiTagKey other && raw().equals(other.raw());
	}

	@SuppressWarnings("unchecked")
	public static <T> EmiTagKey<T> of(class_6862<T> raw) {
		return (EmiTagKey<T>) CACHE.computeIfAbsent(raw, k -> new EmiTagKey<>(k));
	}

	public static <T> EmiTagKey<T> of(class_2378<T> registry, class_2960 id) {
		return of(class_6862.method_40092(registry.method_46765(), id));
	}

	public static <T> Stream<EmiTagKey<T>> fromRegistry(class_2378<T> registry) {
		return registry.method_46755().map(EmiTagKey::of);
	}

	public static void reload() {
		for (EmiTagKey<?> key : CACHE.values()) {
			key.recalculate();
		}
	}
}
