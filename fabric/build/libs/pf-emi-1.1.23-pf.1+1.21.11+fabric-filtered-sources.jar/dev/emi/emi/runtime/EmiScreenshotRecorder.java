package dev.emi.emi.runtime;

import java.io.File;
import java.util.function.Consumer;
import net.minecraft.class_1011;
import net.minecraft.class_156;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.emi.emi.EmiPort;
import dev.emi.emi.config.EmiConfig;
import org.joml.Matrix4fStack;

public class EmiScreenshotRecorder {
	private static final String SCREENSHOTS_DIRNAME = "screenshots";

	/**
	 * Saves a screenshot to the game's `screenshots` directory, doing the appropriate setup so that anything rendered in renderer will be captured
	 * and saved.
	 * <p>
	 * <b>Note:</b> the path can have <code>/</code> characters, indicating subdirectories. Java handles these correctly on Windows. The path should
	 * <b>not</b> contain the <code>.png</code> extension, as that will be added after checking for duplicates. If a file with this path already
	 * exists, then path will be suffixed with a <code>_#</code>, before adding the <code>.png</code> extension, where <code>#</code> represents an
	 * increasing number to avoid conflicts.
	 * <p>
	 * <b>Note 2:</b> The width and height parameters are reflected in the viewport when rendering. But the EMI-config
	 * <code>ui.recipe-screenshot-scale</code> value causes the resulting image to be scaled.
	 *
	 * @param path     the path to save the screenshot to, without extension.
	 * @param width    the width of the screenshot, not counting EMI-config scale.
	 * @param height   the height of the screenshot, not counting EMI-config scale.
	 * @param renderer a function to render the things being screenshotted.
	 */
	public static void saveScreenshot(String path, int width, int height, Runnable renderer) {
		if (!RenderSystem.isOnRenderThread()) {
//			RenderSystem.recordRenderCall(() -> saveScreenshotInner(path, width, height, renderer));
		} else {
			saveScreenshotInner(path, width, height, renderer);
		}
	}

	private static void saveScreenshotInner(String path, int width, int height, Runnable renderer) {
		class_310 client = class_310.method_1551();

		int scale;
		if (EmiConfig.recipeScreenshotScale < 1) {
			scale = EmiPort.getGuiScale(client);
		} else {
			scale = EmiConfig.recipeScreenshotScale;
		}

		class_276 framebuffer = new class_6367("TODO", width * scale, height * scale, true);
//		framebuffer.setClearColor(0f, 0f, 0f, 0f);
//		framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);
//
//		framebuffer.beginWrite(true);

		Matrix4fStack view = RenderSystem.getModelViewStack();
		view.pushMatrix();
		view.identity();
		view.translate(-1.0f, 1.0f, 0.0f);
		view.scale(2f / width, -2f / height, -1f / 1000f);
		view.translate(0.0f, 0.0f, 10.0f);
		EmiPort.applyModelViewMatrix();

//		Matrix4f backupProj = RenderSystem.getProjectionMatrix();
//		RenderSystem.setProjectionMatrix(new Matrix4f().identity(), VertexSorter.BY_Z);

		renderer.run();

//		RenderSystem.setProjectionMatrix(backupProj, VertexSorter.BY_Z);
		view.popMatrix();
		EmiPort.applyModelViewMatrix();

//		framebuffer.endWrite();
//		client.getFramebuffer().beginWrite(true);

		saveScreenshotInner(client.field_1697, path, framebuffer,
			message -> client.execute(() -> client.field_1705.method_1743().method_1812(message)));
	}

	private static void saveScreenshotInner(File gameDirectory, String suggestedPath, class_276 framebuffer, Consumer<class_2561> messageReceiver) {
		class_1011 nativeImage = takeScreenshot(framebuffer);

		File screenshots = new File(gameDirectory, SCREENSHOTS_DIRNAME);
		screenshots.mkdir();

		String filename = getScreenshotFilename(screenshots, suggestedPath);
		File file = new File(screenshots, filename);

		// Make sure the parent file exists. Note: `/`s in suggestedPath are valid, as they indicate subdirectories. Java even translates this
		// correctly on Windows.
		File parent = file.getParentFile();
		parent.mkdirs();

		class_156.method_27958().execute(() -> {
			try {
				nativeImage.method_4325(file);

				class_2561 text = EmiPort.literal(filename,
					class_2583.field_24360.method_30938(true).method_10958(new class_2558.class_10607(file.getAbsolutePath())));
				messageReceiver.accept(EmiPort.translatable("screenshot.success", text));
			} catch (Throwable e) {
				EmiLog.error("Failed to write screenshot", e);
				messageReceiver.accept(EmiPort.translatable("screenshot.failure", e.getMessage()));
			} finally {
				nativeImage.close();
			}
		});
	}

	private static class_1011 takeScreenshot(class_276 framebuffer) {
		int i = framebuffer.field_1482;
		int j = framebuffer.field_1481;
		class_1011 nativeImage = new class_1011(i, j, false);
//		RenderSystem.bindTexture(framebuffer.getColorAttachment());
//		nativeImage.loadFromTextureImage(0, false);
//		nativeImage.mirrorVertically();
		return nativeImage;
	}

	private static String getScreenshotFilename(File directory, String path) {
		int i = 1;
		while ((new File(directory, path + (i == 1 ? "" : "_" + i) + ".png")).exists()) {
			++i;
		}
		return path + (i == 1 ? "" : "_" + i) + ".png";
	}
}
