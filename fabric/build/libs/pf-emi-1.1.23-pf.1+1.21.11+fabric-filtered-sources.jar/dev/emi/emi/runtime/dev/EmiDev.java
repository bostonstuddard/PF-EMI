package dev.emi.emi.runtime.dev;

import java.util.Set;
import net.minecraft.class_2960;

public class EmiDev {
	public static Set<class_2960> duplicateRecipeIds = Set.of();
	public static Set<class_2960> incorrectRecipeIds = Set.of();
}
