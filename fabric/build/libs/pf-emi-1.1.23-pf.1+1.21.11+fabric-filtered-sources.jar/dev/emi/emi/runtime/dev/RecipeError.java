package dev.emi.emi.runtime.dev;

import java.util.List;
import net.minecraft.class_5684;

public record RecipeError(Severity severity, List<class_5684> tooltip) {
	
	public static enum Severity {
		ERROR,
		WARNING
	}
}
