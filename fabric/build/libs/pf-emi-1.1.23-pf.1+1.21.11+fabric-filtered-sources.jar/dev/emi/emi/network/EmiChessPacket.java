package dev.emi.emi.network;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import dev.emi.emi.chess.EmiChess;

public abstract class EmiChessPacket implements EmiPacket {
	protected final UUID uuid;
	protected final byte type, start, end;

	public EmiChessPacket(UUID uuid, byte type, byte start, byte end) {
		this.uuid = uuid;
		this.type = type;
		this.start = start;
		this.end = end;
	}

	public EmiChessPacket(class_2540 buf) {
		this(buf.method_10790(), buf.readByte(), buf.readByte(), buf.readByte());
	}

	@Override
	public void write(class_9129 buf) {
		buf.method_10797(uuid);
		buf.method_52997(type);
		buf.method_52997(start);
		buf.method_52997(end);
	}

	@Override
	public class_9154<EmiChessPacket> method_56479() {
		return EmiNetwork.CHESS;
	}

	public static class S2C extends EmiChessPacket {

		public S2C(UUID uuid, byte type, byte start, byte end) {
			super(uuid, type, start, end);
		}

		public S2C(class_2540 buf) {
			super(buf);
		}

		@Override
		public void apply(class_1657 player) {
			EmiChess.receiveNetwork(uuid, type, start, end);
		}
	}

	public static class C2S extends EmiChessPacket {

		public C2S(UUID uuid, byte type, byte start, byte end) {
			super(uuid, type, start, end);
		}

		public C2S(class_2540 buf) {
			super(buf);
		}

		@Override
		public void apply(class_1657 player) {
			class_1657 opponent = player.method_73183().method_18470(uuid);
			if (opponent instanceof class_3222 spe) {
				EmiNetwork.sendToClient(spe, new EmiChessPacket.S2C(player.method_5667(), type, start, end));
			}
		}
	}
}
