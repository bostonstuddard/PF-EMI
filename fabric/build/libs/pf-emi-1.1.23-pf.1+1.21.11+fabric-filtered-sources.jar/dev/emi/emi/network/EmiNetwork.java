package dev.emi.emi.network;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import dev.emi.emi.EmiPort;

public class EmiNetwork {
	public static final class_8710.class_9154<FillRecipeC2SPacket> FILL_RECIPE = new class_8710.class_9154<FillRecipeC2SPacket>(EmiPort.id("emi:fill_recipe"));
	public static final class_8710.class_9154<CreateItemC2SPacket> CREATE_ITEM = new class_8710.class_9154<CreateItemC2SPacket>(EmiPort.id("emi:create_item"));
	public static final class_8710.class_9154<CommandS2CPacket> COMMAND = new class_8710.class_9154<CommandS2CPacket>(EmiPort.id("emi:command"));
	public static final class_8710.class_9154<EmiChessPacket> CHESS = new class_8710.class_9154<EmiChessPacket>(EmiPort.id("emi:chess"));
	public static final class_8710.class_9154<PingS2CPacket> PING = new class_8710.class_9154<PingS2CPacket>(EmiPort.id("emi:ping"));
	private static BiConsumer<class_3222, EmiPacket> clientSender;
	private static Consumer<EmiPacket> serverSender;

	public static void initServer(BiConsumer<class_3222, EmiPacket> sender) {
		clientSender = sender;
	}

	public static void initClient(Consumer<EmiPacket> sender) {
		serverSender = sender;
	}

	public static void sendToClient(class_3222 player, EmiPacket packet) {
		clientSender.accept(player, packet);
	}

	public static void sendToServer(EmiPacket packet) {
		serverSender.accept(packet);
	}
}
