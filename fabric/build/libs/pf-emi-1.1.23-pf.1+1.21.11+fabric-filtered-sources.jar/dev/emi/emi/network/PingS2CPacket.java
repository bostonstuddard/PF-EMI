package dev.emi.emi.network;

import dev.emi.emi.platform.EmiClient;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_9129;

public class PingS2CPacket implements EmiPacket {

	public PingS2CPacket() {
	}

	public PingS2CPacket(class_2540 buf) {
	}

	@Override
	public void write(class_9129 buf) {
	}

	@Override
	public void apply(class_1657 player) {
		EmiClient.onServer = true;
	}

	@Override
	public class_9154<PingS2CPacket> method_56479() {
		return EmiNetwork.PING;
	}
}
