package dev.emi.emi.network;

import net.minecraft.class_1657;
import net.minecraft.class_8710;
import net.minecraft.class_9129;

public interface EmiPacket extends class_8710 {
	void write(class_9129 buf);
	
	void apply(class_1657 player);
}
