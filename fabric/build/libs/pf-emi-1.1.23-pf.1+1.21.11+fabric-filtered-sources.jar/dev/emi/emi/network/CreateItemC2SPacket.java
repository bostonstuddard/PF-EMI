package dev.emi.emi.network;

import dev.emi.emi.runtime.EmiLog;
import net.minecraft.class_12099;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_9129;

public class CreateItemC2SPacket implements EmiPacket {
	private final int mode;
	private final class_1799 stack;

	public CreateItemC2SPacket(int mode, class_1799 stack) {
		this.mode = mode;
		this.stack = stack;
	}

	public CreateItemC2SPacket(class_9129 buf) {
		this(buf.readByte(), class_1799.field_49268.decode(buf));
	}

	@Override
	public void write(class_9129 buf) {
		buf.method_52997(mode);
		class_1799.field_49268.encode(buf, stack);
	}

	@Override
	public void apply(class_1657 player) {
		if ((player.method_75004().hasPermission(class_12099.field_63210) || player.method_68878()) && player.field_7512 != null) {
			if (stack.method_7960()) {
				if (mode == 1 && !player.field_7512.method_34255().method_7960()) {
					EmiLog.info(player.method_74861() + " deleted " + player.field_7512.method_34255());
					player.field_7512.method_34254(stack);
				}
			} else {
				EmiLog.info(player.method_74861() + " cheated in " + stack);
				if (mode == 0) {
					player.method_31548().method_7398(stack);
				} else if (mode == 1) {
					player.field_7512.method_34254(stack);
				}
			}
		}
	}

	@Override
	public class_9154<CreateItemC2SPacket> method_56479() {
		return EmiNetwork.CREATE_ITEM;
	}
}
