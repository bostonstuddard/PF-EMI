package dev.emi.emi.network;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_9129;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.Lists;

import dev.emi.emi.runtime.EmiLog;

public class FillRecipeC2SPacket implements EmiPacket {
	private final int syncId;
	private final int action;
	private final List<Integer> slots, crafting;
	private final int output;
	private final List<class_1799> stacks;

	public FillRecipeC2SPacket(class_1703 handler, int action, List<class_1735> slots, List<class_1735> crafting, @Nullable class_1735 output, List<class_1799> stacks) {
		this.syncId = handler.field_7763;
		this.action = action;
		this.slots = slots.stream().map(s -> s == null ? -1 : s.field_7874).toList();
		this.crafting = crafting.stream().map(s -> s == null ? -1 : s.field_7874).toList();
		this.output = output == null ? -1 : output.field_7874;
		this.stacks = stacks;
	}

	public FillRecipeC2SPacket(class_9129 buf) {
		syncId = buf.readInt();
		action = buf.readByte();
		slots = parseCompressedSlots(buf);
		crafting = Lists.newArrayList();
		int craftingSize = buf.method_10816();
		for (int i = 0; i < craftingSize; i++) {
			int s = buf.method_10816();
			crafting.add(s);
		}
		if (buf.readBoolean()) {
			output = buf.method_10816();
		} else {
			output = -1;
		}
		int size = buf.method_10816();
		stacks = Lists.newArrayList();
		for (int i = 0; i < size; i++) {
			stacks.add(class_1799.field_49268.decode(buf));
		}
	}

	@Override
	public void write(class_9129 buf) {
		buf.method_53002(syncId);
		buf.method_52997(action);
		writeCompressedSlots(slots, buf);
		buf.method_10804(crafting.size());
		for (Integer s : crafting) {
			buf.method_10804(s);
		}
		if (output != -1) {
			buf.method_52964(true);
			buf.method_10804(output);
		} else {
			buf.method_52964(false);
		}
		buf.method_10804(stacks.size());
		for (class_1799 stack : stacks) {
			class_1799.field_49268.encode(buf, stack);
		}
	}

	@Override
	public void apply(class_1657 player) {
		if (slots == null || crafting == null) {
			EmiLog.error("Client requested fill but passed input and crafting slot information was invalid, aborting");
			return;
		}
		class_1703 handler = player.field_7512;
		if (handler == null || handler.field_7763 != syncId) {
			EmiLog.warn("Client requested fill but screen handler has changed, aborting");
			return;
		}
		List<class_1735> slots = Lists.newArrayList();
		List<class_1735> crafting = Lists.newArrayList();
		class_1735 output = null;
		for (int i : this.slots) {
			if (i < 0 || i >= handler.field_7761.size()) {
				EmiLog.error("Client requested fill but passed input slots don't exist, aborting");
				return;
			}
			slots.add(handler.field_7761.get(i));
		}
		for (int i : this.crafting) {
			if (i >= 0 && i < handler.field_7761.size()) {
				crafting.add(handler.field_7761.get(i));
			} else {
				crafting.add(null);
			}
		}
		if (this.output != -1) {
			if (this.output >= 0 && this.output < handler.field_7761.size()) {
				output = handler.field_7761.get(this.output);
			}
		}
		if (crafting.size() >= stacks.size()) {
			List<class_1799> rubble = Lists.newArrayList();
			for (int i = 0; i < crafting.size(); i++) {
				class_1735 s = crafting.get(i);
				if (s != null && s.method_7674(player) && !s.method_7677().method_7960()) {
					class_1799 taken = s.method_7677();
					rubble.add(taken.method_7972());
					s.method_53512(class_1799.field_8037);
					s.method_7667(player, taken);
				}
			}
			try {	
				for (int i = 0; i < stacks.size(); i++) {
					class_1799 stack = stacks.get(i);
					if (stack.method_7960()) {
						continue;
					}
					int gotten = grabMatching(player, slots, rubble, crafting, stack);
					if (gotten != stack.method_7947()) {
						if (gotten > 0) {
							stack.method_7939(gotten);
							player.method_31548().method_7398(stack);
						}
						return;
					} else {
						class_1735 s = crafting.get(i);
						if (s != null && s.method_7680(stack) && stack.method_7947() <= s.method_7675() && stack.method_7947() <= stack.method_7914()) {
							if (!s.method_7677().method_7960()) { // Make sure we don't accidentally delete any items that could have been placed in this slot
								if (s.method_7674(player)) {
									class_1799 taken = s.method_7677();
									rubble.add(taken.method_7972());
									s.method_53512(class_1799.field_8037);
									s.method_7667(player, taken);
								} else {
									player.method_31548().method_7398(stack);
									continue;
								}
							}
							s.method_53512(stack);
						} else {
							player.method_31548().method_7398(stack);
						}
					}
				}
				if (output != null) {
					if (action == 1) {
						handler.method_7593(output.method_34266(), 0, class_1713.field_7790, player);
					} else if (action == 2) {
						handler.method_7593(output.method_34266(), 0, class_1713.field_7794, player);
					}
				}
			} finally {
				for (class_1799 stack : rubble) {
					player.method_31548().method_7398(stack);
				}
			}
		}
	}

	private static List<Integer> parseCompressedSlots(class_2540 buf) {
		List<Integer> list = Lists.newArrayList();
		int amount = buf.method_10816();
		for (int i = 0; i < amount; i++) {
			int low = buf.method_10816();
			int high = buf.method_10816();
			if (low < 0) {
				return null;
			}
			for (int j = low; j <= high; j++) {
				list.add(j);
			}
		}
		return list;
	}
	
	private static void writeCompressedSlots(List<Integer> list, class_2540 buf) {
		List<Consumer<class_2540>> postWrite = Lists.newArrayList();
		int groups = 0;
		int i = 0;
		while (i < list.size()) {
			groups++;
			int start = i;
			int startValue = list.get(start);
			while (i < list.size() && i - start == list.get(i) - startValue) {
				i++;
			}
			int end = i - 1;
			postWrite.add(b -> {
				b.method_10804(startValue);
				b.method_10804(list.get(end));
			});
		}
		buf.method_10804(groups);
		for (Consumer<class_2540> consumer : postWrite) {
			consumer.accept(buf);
		}
	}

	private static int grabMatching(class_1657 player, List<class_1735> slots, List<class_1799> rubble, List<class_1735> crafting, class_1799 stack) {
		int amount = stack.method_7947();
		int grabbed = 0;
		for (int i = 0; i < rubble.size(); i++) {
			if (grabbed >= amount) {
				return grabbed;
			}
			class_1799 r = rubble.get(i);
			if (class_1799.method_31577(stack, r)) {
				int wanted = amount - grabbed;
				if (r.method_7947() <= wanted) {
					grabbed += r.method_7947();
					rubble.remove(i);
					i--;
				} else {
					grabbed = amount;
					r.method_7939(r.method_7947() - wanted);
				}
			}
		}
		for (class_1735 s : slots) {
			if (grabbed >= amount) {
				return grabbed;
			}
			if (crafting.contains(s) || !s.method_7674(player)) {
				continue;
			}
			class_1799 st = s.method_7677();
			if (class_1799.method_31577(stack, st)) {
				int wanted = amount - grabbed;
				class_1799 taken = st.method_7972();
				if (st.method_7947() <= wanted) {
					grabbed += st.method_7947();
					s.method_53512(class_1799.field_8037);
				} else {
					grabbed = amount;
					st.method_7939(st.method_7947() - wanted);
				}
				s.method_7667(player, taken);
			}
		}
		return grabbed;
	}

	@Override
	public class_9154<FillRecipeC2SPacket> method_56479() {
		return EmiNetwork.FILL_RECIPE;
	}
}
