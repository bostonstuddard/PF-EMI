package dev.emi.emi.jemi.widget;

import java.util.List;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.widget.TankWidget;
import dev.emi.emi.jemi.impl.JemiRecipeSlot;
import dev.emi.emi.runtime.EmiDrawContext;
import mezz.jei.api.recipe.RecipeIngredientRole;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public class JemiTankWidget extends TankWidget {
	private final JemiRecipeSlot slot;
	private final JemiSlotWidget jsw;

	public JemiTankWidget(JemiRecipeSlot slot, EmiRecipe recipe) {
		super(slot.stack, slot.x - 1, slot.y - 1, slot.tankInfo.width() + 2, slot.tankInfo.height() + 2, slot.tankInfo.capacity());
		this.slot = slot;
		slot.widget = this;
		if (slot.getRole() == RecipeIngredientRole.OUTPUT) {
			this.recipeContext(recipe);
		}
		this.drawBack(false);
		this.jsw = new JemiSlotWidget(slot, recipe);
	}

	@Override
	public void method_25394(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		if (slot.background != null) {
			slot.background.drawable().draw(context.raw(), x + 1 + slot.background.xOff(), y + 1 + slot.background.yOff());
		}
		super.method_25394(context.raw(), mouseX, mouseY, delta);
	}

	@Override
	public void drawOverlay(class_332 raw, int mouseX, int mouseY, float delta) {
		EmiDrawContext context = EmiDrawContext.wrap(raw);
		if (slot.overlay != null) {
			context.enableBlend();
			context.push();
//			context.matrices().translate(0, 0, 200);
			slot.overlay.drawable().draw(context.raw(), x + 1 + slot.overlay.xOff(), y + 1 + slot.overlay.yOff());
			context.pop();
		}
		super.drawOverlay(context.raw(), mouseX, mouseY, delta);
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		return jsw.getTooltip(mouseX, mouseY);
	}
}
