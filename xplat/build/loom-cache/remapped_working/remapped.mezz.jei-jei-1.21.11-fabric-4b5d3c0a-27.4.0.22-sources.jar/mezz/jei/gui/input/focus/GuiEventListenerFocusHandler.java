package mezz.jei.gui.input.focus;

import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.TextFieldWidget;

public class GuiEventListenerFocusHandler implements IFocusHandler {
	private final Element guiEventListener;

	public static IFocusHandler create(Element guiEventListener) {
		if (guiEventListener instanceof TextFieldWidget editBox) {
			return new EditBoxFocusHandler(editBox);
		}
		return new GuiEventListenerFocusHandler(guiEventListener);
	}

	private GuiEventListenerFocusHandler(Element guiEventListener) {
		this.guiEventListener = guiEventListener;
	}

	@Override
	public void unFocus() {
		if (guiEventListener.isFocused()) {
			guiEventListener.setFocused(false);
		}
	}

	@Override
	public void focus() {
		if (!guiEventListener.isFocused()) {
			guiEventListener.setFocused(true);
		}
	}
}
