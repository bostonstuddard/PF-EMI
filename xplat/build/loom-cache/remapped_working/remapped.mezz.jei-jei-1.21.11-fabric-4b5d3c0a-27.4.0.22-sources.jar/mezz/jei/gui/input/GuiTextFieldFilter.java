package mezz.jei.gui.input;

import mezz.jei.common.Internal;
import mezz.jei.common.gui.elements.ScalableDrawable;
import mezz.jei.common.gui.textures.Textures;
import mezz.jei.common.util.ImmutableRect2i;
import mezz.jei.core.util.TextHistory;
import mezz.jei.gui.input.focus.ScreenFocusHandler;
import mezz.jei.gui.input.handlers.TextFieldInputHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import java.util.function.BooleanSupplier;

public class GuiTextFieldFilter extends TextFieldWidget {
	private static final int maxSearchLength = 128;
	private static final TextHistory history = new TextHistory();
	private final BooleanSupplier filterEmpty;

	private ImmutableRect2i area;
	private final ScalableDrawable background;
	private ImmutableRect2i backgroundBounds;

	private @Nullable ScreenFocusHandler screenUnfocusHandler;

	public GuiTextFieldFilter(BooleanSupplier filterEmpty) {
		// TODO narrator string
		super(MinecraftClient.getInstance().textRenderer, 0, 0, 0, 0, ScreenTexts.EMPTY);
		this.filterEmpty = filterEmpty;

		setMaxLength(maxSearchLength);
		this.area = ImmutableRect2i.EMPTY;
		Textures textures = Internal.getTextures();
		this.background = textures.getSearchBackground();
		this.backgroundBounds = ImmutableRect2i.EMPTY;
		setDrawsBackground(false);
	}

	public void updateBounds(ImmutableRect2i area) {
		this.backgroundBounds = area;
		setX(area.getX() + 4);
		setY(area.getY() + (area.getHeight() - 8) / 2);
		this.width = area.getWidth() - 12;
		this.height = area.getHeight();
		this.area = area;
	}

	@Override
	public void setText(String filterText) {
		if (!filterText.equals(getText())) {
			super.setText(filterText);
		}
		int color = filterEmpty.getAsBoolean() ? 0xFFFF0000 : 0xFFFFFFFF;
		setEditableColor(color);
	}

	public Optional<String> getHistory(TextHistory.Direction direction) {
		String currentText = getText();
		return history.get(direction, currentText);
	}

	@Override
	public boolean isMouseOver(double mouseX, double mouseY) {
		return area.contains(mouseX, mouseY);
	}

	public IUserInputHandler createInputHandler() {
		return new TextFieldInputHandler(this);
	}

	@Override
	public void setFocused(boolean keyboardFocus) {
		final boolean previousFocus = isFocused();
		super.setFocused(keyboardFocus);

		if (previousFocus != keyboardFocus) {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			if (keyboardFocus) {
				Screen screen = minecraft.currentScreen;
				if (screen != null) {
					screenUnfocusHandler = ScreenFocusHandler.create(screen);
					if (screenUnfocusHandler != null) {
						screenUnfocusHandler.unFocus();
					}
				}
			} else {
				if (screenUnfocusHandler != null) {
					screenUnfocusHandler.focus();
					screenUnfocusHandler = null;
				}
			}

			String text = getText();
			history.add(text);
		}
	}

	@Override
	public void renderWidget(DrawContext guiGraphics, int mouseX, int mouseY, float partialTicks) {
		if (this.isVisible()) {
			background.draw(guiGraphics, this.backgroundBounds);
		}
		super.renderWidget(guiGraphics, mouseX, mouseY, partialTicks);
	}
}
