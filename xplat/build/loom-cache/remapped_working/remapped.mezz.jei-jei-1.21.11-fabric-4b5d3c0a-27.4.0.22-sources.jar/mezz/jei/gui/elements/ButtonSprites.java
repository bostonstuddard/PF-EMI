package mezz.jei.gui.elements;

import mezz.jei.api.gui.drawable.IScalableDrawable;
import mezz.jei.common.Internal;
import mezz.jei.common.gui.textures.Textures;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ButtonTextures;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ColorHelper;

public final class ButtonSprites {
	private final ButtonTextures widgetSprites;
	private final IScalableDrawable pressed;
	private final IScalableDrawable pressedFocused;

	public ButtonSprites() {
		this.widgetSprites = new ButtonTextures(
			Identifier.ofVanilla("widget/button"),
			Identifier.ofVanilla("widget/button_disabled"),
			Identifier.ofVanilla("widget/button_highlighted")
		);
		Textures textures = Internal.getTextures();
		this.pressed = textures.getButtonPressed();
		this.pressedFocused = textures.getButtonPressedHighlight();
	}

	public void render(DrawContext guiGraphics, boolean enabled, boolean focused, boolean pressed, int x, int y, int width, int height, int alpha) {
		if (pressed) {
			if (focused) {
				this.pressedFocused.draw(guiGraphics, x, y, width, height);
			} else {
				this.pressed.draw(guiGraphics, x, y, width, height);
			}
		} else {
			Identifier spriteLocation = widgetSprites.get(enabled, focused);
			guiGraphics.drawGuiTexture(RenderPipelines.GUI_TEXTURED, spriteLocation, x, y, width, height, ColorHelper.whiteWithAlpha(alpha));
		}
	}
}
