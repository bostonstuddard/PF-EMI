package mezz.jei.gui.overlay.bookmarks;

import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.recipe.transfer.IRecipeTransferError;
import mezz.jei.api.recipe.transfer.IRecipeTransferManager;
import mezz.jei.common.Internal;
import mezz.jei.common.transfer.RecipeTransferUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.Rect2i;
import net.minecraft.item.tooltip.TooltipData;
import net.minecraft.screen.ScreenHandler;
import org.jspecify.annotations.Nullable;

public class PreviewTooltipComponent<R> implements TooltipComponent, TooltipData {
	private static final int UPDATE_INTERVAL_MS = 2000;

	private final IRecipeLayoutDrawable<R> drawable;
	private @Nullable IRecipeTransferError transferError;
	private long lastUpdateTime = 0;

	public PreviewTooltipComponent(IRecipeLayoutDrawable<R> drawable) {
		this.drawable = drawable;
	}

	@Override
	public int getHeight(TextRenderer font) {
		return drawable.getRect().getHeight() + 10;
	}

	@Override
	public int getWidth(TextRenderer font) {
		return drawable.getRect().getWidth() + 4;
	}

	@Override
	public void drawItems(TextRenderer font, int x, int y, int p_368529_, int p_368584_, DrawContext guiGraphics) {
		var pose = guiGraphics.getMatrices();
		pose.pushMatrix();
		{
			pose.translate(x + 2, y + 5);
			drawable.drawRecipe(guiGraphics, 0, 0);
			updateTransferError();
			if (transferError != null) {
				Rect2i recipeRect = drawable.getRect();
				transferError.showError(guiGraphics, x, y, drawable.getRecipeSlotsView(), recipeRect.getX(), recipeRect.getY());
			}
		}
		pose.popMatrix();
	}

	private void updateTransferError() {
		long currentTime = System.currentTimeMillis();
		if (currentTime - lastUpdateTime < UPDATE_INTERVAL_MS) {
			return;
		}
		lastUpdateTime = currentTime;

		MinecraftClient minecraft = MinecraftClient.getInstance();
		ClientPlayerEntity player = minecraft.player;
		if (player == null) {
			transferError = null;
			return;
		}
		Screen screen = MinecraftClient.getInstance().currentScreen;
		if (screen instanceof HandledScreen<?> containerScreen) {
			ScreenHandler container = containerScreen.getScreenHandler();
			IRecipeTransferManager recipeTransferManager = Internal.getJeiRuntime().getRecipeTransferManager();
			transferError = RecipeTransferUtil.getTransferRecipeError(recipeTransferManager, container, drawable, player)
				.orElse(null);
		} else {
			transferError = null;
		}
	}
}
