package mezz.jei.gui.overlay.bookmarks.history;

import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.inputs.IJeiUserInput;
import mezz.jei.common.Internal;
import mezz.jei.common.config.IClientConfig;
import mezz.jei.common.gui.textures.Textures;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import mezz.jei.api.gui.buttons.IButtonState;
import mezz.jei.api.gui.buttons.IIconButtonController;

public class LookupHistoryButtonController implements IIconButtonController {
	private final IDrawable offIcon;
	private final IDrawable onIcon;
	private final IClientConfig clientConfig;

	public LookupHistoryButtonController(IClientConfig clientConfig) {
		Textures textures = Internal.getTextures();
		this.offIcon = textures.getHistoryButtonDisabledIcon();
		this.onIcon = textures.getHistoryButtonEnabledIcon();
		this.clientConfig = clientConfig;
	}

	@Override
	public void getTooltips(ITooltipBuilder tooltip) {
		if (clientConfig.isLookupHistoryEnabled()) {
			tooltip.add(Text.translatable("jei.tooltip.lookupHistory.disable"));
		} else {
			tooltip.add(Text.translatable("jei.tooltip.lookupHistory.enable"));
		}
		tooltip.add(
			Text.translatable("jei.tooltip.lookupHistory.usage")
				.formatted(Formatting.ITALIC)
				.formatted(Formatting.GRAY)
		);
	}

	@Override
	public void updateState(IButtonState state) {
		state.setForcePressed(clientConfig.isLookupHistoryEnabled());
		if (clientConfig.isLookupHistoryEnabled()) {
			state.setIcon(onIcon);
		} else {
			state.setIcon(offIcon);
		}
	}

	@Override
	public boolean onPress(IJeiUserInput input) {
		if (!input.isSimulate()) {
			clientConfig.setLookupHistoryEnabled(!clientConfig.isLookupHistoryEnabled());
		}
		return true;
	}
}
