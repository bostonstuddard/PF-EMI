package mezz.jei.gui.config;

import com.mojang.serialization.Codec;
import mezz.jei.api.helpers.ICodecHelper;
import mezz.jei.api.recipe.IRecipeManager;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.gui.bookmarks.IBookmark;
import net.minecraft.registry.DynamicRegistryManager;
import java.util.List;

public interface ILookupHistoryConfig {
	void save(IRecipeManager recipeManager, IIngredientManager ingredientManager, DynamicRegistryManager registryAccess, ICodecHelper codecHelper, List<IBookmark> bookmarks, Codec<IBookmark> bookmarkCodec);

	List<IBookmark> load(IRecipeManager recipeManager, IIngredientManager ingredientManager, DynamicRegistryManager registryAccess, ICodecHelper codecHelper, Codec<IBookmark> bookmarkCodec);
}
