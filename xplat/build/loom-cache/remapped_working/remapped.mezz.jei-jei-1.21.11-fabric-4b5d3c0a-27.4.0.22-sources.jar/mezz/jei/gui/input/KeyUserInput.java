package mezz.jei.gui.input;

import com.google.common.base.MoreObjects;
import com.mojang.datafixers.util.Either;
import mezz.jei.common.input.KeyNameUtil;
import mezz.jei.common.input.MouseButtonEventData;
import net.minecraft.client.input.AbstractInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.StringHelper;

public class KeyUserInput extends UserInput {
	private final InputUtil.Key key;
	private final KeyInput event;
	private final double mouseX;
	private final double mouseY;
	private final InputType inputType;

	public KeyUserInput(KeyInput event, InputType inputType) {
		this.key = InputUtil.fromKeyCode(event);
		this.event = event;
		this.mouseX = MouseUtil.getX();
		this.mouseY = MouseUtil.getY();
		this.inputType = inputType;
	}

	@Override
	public InputUtil.Key getKey() {
		return key;
	}

	@Override
	public double getMouseX() {
		return mouseX;
	}

	@Override
	public double getMouseY() {
		return mouseY;
	}

	@Override
	public InputType getInputType() {
		return inputType;
	}

	@Override
	@AbstractInput.Modifier
	public int getModifiers() {
		return event.modifiers();
	}

	@Override
	public AbstractInput getInputWithModifiers() {
		return event;
	}

	@Override
	public boolean isSimulate() {
		return inputType == InputType.SIMULATE;
	}

	@Override
	public boolean isAllowedChatCharacter() {
		return StringHelper.isValidChar((char) this.key.getCode());
	}

	@Override
	public Either<MouseButtonEventData, KeyInput> getEvent() {
		return Either.right(event);
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this)
			.add("inputType", inputType)
			.add("key", KeyNameUtil.getKeyDisplayName(key).getString())
			.add("event", event)
			.add("mouse", String.format("%s, %s", mouseX, mouseY))
			.toString();
	}
}
