package mezz.jei.gui.input;

import net.minecraft.client.input.CharInput;

public interface ICharTypedHandler {
	boolean hasKeyboardFocus();

	boolean onCharTyped(CharInput event);
}
