package mezz.jei.fabric.input;

import mezz.jei.common.input.keys.JeiKeyConflictContext;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public class FabricKeyMapping extends KeyBinding {
	protected InputUtil.Key realKey;
	protected final JeiKeyConflictContext context;

	public FabricKeyMapping(
		String description,
		InputUtil.Type type,
		int keyCode,
		Category category,
		JeiKeyConflictContext context
	) {
		// Ensure the default key is set correctly (it is final).
		super(description, type, keyCode, category);
		this.realKey = KeyBindingHelper.getBoundKeyOf(this);
		this.context = context;
		// Overwrite the parent's key variable so it doesn't block other keybinds.
		super.setBoundKey(InputUtil.UNKNOWN_KEY);
	}

	// Override all methods that would otherwise interact with super.key so displaying
	// and rebinding work correctly. This cannot work for the static methods that
	// count clicks and monitor presses, but JEI doesn't use them anyway.

	@Override
	public void setBoundKey(InputUtil.Key key) {
		this.realKey = key;
	}

	@Override
	public boolean equals(KeyBinding binding) {
		// Special implementation which is aware of the key conflict context.
		if (binding instanceof FabricKeyMapping other) {
			return realKey.equals(KeyBindingHelper.getBoundKeyOf(other)) &&
				(context.conflicts(other.context) || other.context.conflicts(context));
		} else {
			// This ensures symmetry between conflicts, as regular keybinds see this one as
			// being unbound and not conflicting.
			return false;
		}
	}

	@Override
	public boolean isUnbound() {
		return this.realKey.equals(InputUtil.UNKNOWN_KEY);
	}

	@Override
	public boolean matchesKey(KeyInput keyEvent) {
		int keyCode = keyEvent.key();
		if (keyCode != InputUtil.UNKNOWN_KEY.getCode()) {
			return this.realKey.getCategory() == InputUtil.Type.KEYSYM &&
				this.realKey.getCode() == keyCode;
		} else {
			return this.realKey.getCategory() == InputUtil.Type.SCANCODE &&
				this.realKey.getCode() == keyEvent.scancode();
		}
	}

	@Override
	public boolean matchesMouse(Click mouseButtonEvent) {
		return this.realKey.getCategory() == InputUtil.Type.MOUSE &&
			this.realKey.getCode() == mouseButtonEvent.button();
	}

	@Override
	public Text getBoundKeyLocalizedText() {
		return this.realKey.getLocalizedText();
	}

	@Override
	public boolean isDefault() {
		return this.realKey.equals(getDefaultKey());
	}

	@Override
	public String getBoundKeyTranslationKey() {
		return this.realKey.getTranslationKey();
	}
}
