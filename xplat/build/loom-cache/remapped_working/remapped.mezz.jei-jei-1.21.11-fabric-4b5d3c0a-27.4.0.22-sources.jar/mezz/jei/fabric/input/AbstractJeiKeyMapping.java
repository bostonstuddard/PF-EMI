package mezz.jei.fabric.input;

import mezz.jei.common.input.keys.IJeiKeyMappingInternal;
import mezz.jei.common.input.keys.JeiKeyConflictContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import java.util.function.Consumer;

public abstract class AbstractJeiKeyMapping implements IJeiKeyMappingInternal {
	protected final JeiKeyConflictContext context;

	public AbstractJeiKeyMapping(JeiKeyConflictContext context) {
		this.context = context;
	}

	protected abstract KeyBinding getMapping();

	@Override
	public boolean isUnbound() {
		return this.getMapping().isUnbound();
	}

	@Override
	public Text getTranslatedKeyMessage() {
		return this.getMapping().getBoundKeyLocalizedText();
	}

	@Override
	public IJeiKeyMappingInternal register(Consumer<KeyBinding> registerMethod) {
		registerMethod.accept(this.getMapping());
		return this;
	}
}
