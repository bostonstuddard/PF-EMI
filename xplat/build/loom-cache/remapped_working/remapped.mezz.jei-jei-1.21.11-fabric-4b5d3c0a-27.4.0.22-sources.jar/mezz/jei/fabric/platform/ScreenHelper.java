package mezz.jei.fabric.platform;

import mezz.jei.common.platform.IPlatformScreenHelper;
import mezz.jei.common.util.ImmutableRect2i;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.RecipeBookScreen;
import net.minecraft.client.gui.screen.recipebook.RecipeBookWidget;
import net.minecraft.client.gui.screen.recipebook.RecipeGroupButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.util.Window;
import net.minecraft.screen.AbstractRecipeScreenHandler;
import net.minecraft.screen.slot.Slot;
import java.util.List;
import java.util.Optional;

public class ScreenHelper implements IPlatformScreenHelper {
	@Override
	public Optional<Slot> getSlotUnderMouse(HandledScreen<?> containerScreen) {
		Slot slot = containerScreen.focusedSlot;
		return Optional.ofNullable(slot);
	}

	@Override
	public int getGuiLeft(HandledScreen<?> containerScreen) {
		return containerScreen.x;
	}

	@Override
	public int getGuiTop(HandledScreen<?> containerScreen) {
		return containerScreen.y;
	}

	@Override
	public int getXSize(HandledScreen<?> containerScreen) {
		return containerScreen.backgroundWidth;
	}

	@Override
	public int getYSize(HandledScreen<?> containerScreen) {
		return containerScreen.backgroundHeight;
	}

	@Override
	public ImmutableRect2i getBookArea(RecipeBookWidget<?> guiRecipeBook) {
		if (guiRecipeBook.isOpen()) {
			return new ImmutableRect2i(
				guiRecipeBook.getLeft(),
				guiRecipeBook.getTop(),
				RecipeBookWidget.field_32408,
				RecipeBookWidget.field_32409
			);
		}
		return ImmutableRect2i.EMPTY;
	}

	@Override
	public ImmutableRect2i getToastsArea() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		ToastManager toastManager = minecraft.getToastManager();
		List<ToastManager.Entry<?>> visible = toastManager.visibleEntries;
		if (visible.isEmpty()) {
			return ImmutableRect2i.EMPTY;
		}
		int height = 0;
		int width = 0;
		for (ToastManager.Entry<?> instance : visible) {
			Toast toast = instance.method_2001();
			height += toast.getHeight();
			width = Math.max(toast.getWidth(), width);
		}
		Window window = minecraft.getWindow();
		int screenWidth = window.getScaledWidth();
		return new ImmutableRect2i(screenWidth - width, 0, width, height);
	}

	@Override
	public List<RecipeGroupButtonWidget> getTabButtons(RecipeBookWidget<?> recipeBookComponent) {
		return recipeBookComponent.tabButtons;
	}

	@Override
	public <T extends AbstractRecipeScreenHandler> RecipeBookWidget<?> getRecipeBookComponent(RecipeBookScreen<T> screen) {
		return screen.recipeBook;
	}

	@Override
	public boolean canLoseFocus(TextFieldWidget editBox) {
		return editBox.focusUnlocked;
	}
}
