package mezz.jei.fabric.platform;

import mezz.jei.common.platform.IPlatformIngredientHelper;
import net.minecraft.block.ComposterBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;
import java.util.List;
import java.util.stream.Stream;

public class IngredientHelper implements IPlatformIngredientHelper {
	@Override
	public List<Ingredient> getPotionContainers(BrewingRecipeRegistry potionBrewing) {
		return potionBrewing.potionTypes;
	}

	@Override
	public Stream<Ingredient> getPotionIngredients(BrewingRecipeRegistry potionBrewing) {
		return Stream.concat(
			potionBrewing.potionRecipes.stream(),
			potionBrewing.itemRecipes.stream()
		)
			.map(class_1845.class_1846::comp_2191);
	}

	@Override
	public float getCompostValue(ItemStack itemStack) {
		Item item = itemStack.getItem();
		return ComposterBlock.ITEM_TO_LEVEL_INCREASE_CHANCE.getOrDefault(item, 0f);
	}
}
