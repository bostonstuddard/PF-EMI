package mezz.jei.fabric.platform;

import com.mojang.datafixers.util.Either;
import mezz.jei.common.input.MouseButtonEventData;
import mezz.jei.common.input.keys.IJeiKeyMappingCategoryBuilder;
import mezz.jei.common.platform.IPlatformInputHelper;
import mezz.jei.fabric.input.FabricJeiKeyMappingCategoryBuilder;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class InputHelper implements IPlatformInputHelper {
	@Override
	public boolean isActiveAndMatches(KeyBinding keyMapping, InputUtil.Key key, Either<MouseButtonEventData, KeyInput> event) {
		if (keyMapping.isUnbound()) {
			return false;
		}
		return event.map(e -> keyMapping.matchesMouse(e.event()), keyMapping::matchesKey);
	}

	@Override
	public IJeiKeyMappingCategoryBuilder createKeyMappingCategoryBuilder(KeyBinding.Category category) {
		return new FabricJeiKeyMappingCategoryBuilder(category);
	}
}
