package mezz.jei.fabric.platform;

import mezz.jei.api.recipe.vanilla.IJeiBrewingRecipe;
import mezz.jei.api.recipe.vanilla.IVanillaRecipeFactory;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.common.platform.IPlatformRecipeHelper;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RawShapedRecipe;
import net.minecraft.recipe.SmithingRecipe;
import net.minecraft.recipe.SmithingTransformRecipe;
import net.minecraft.recipe.SmithingTrimRecipe;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GrindstoneScreenHandler;
import java.util.List;
import java.util.Optional;

public class RecipeHelper implements IPlatformRecipeHelper {
	@Override
	public Ingredient getBase(SmithingRecipe recipe) {
		if (recipe instanceof SmithingTransformRecipe transformRecipe) {
			return transformRecipe.base;
		}
		if (recipe instanceof SmithingTrimRecipe trimRecipe) {
			return trimRecipe.base;
		}
		throw new IllegalArgumentException("Unknown recipe type: " + recipe.getClass());
	}

	@Override
	public Optional<Ingredient> getAddition(SmithingRecipe recipe) {
		if (recipe instanceof SmithingTransformRecipe transformRecipe) {
			return transformRecipe.addition;
		}
		if (recipe instanceof SmithingTrimRecipe trimRecipe) {
			return Optional.of(trimRecipe.addition);
		}
		throw new IllegalArgumentException("Unknown recipe type: " + recipe.getClass());
	}

	@Override
	public Optional<Ingredient> getTemplate(SmithingRecipe recipe) {
		if (recipe instanceof SmithingTransformRecipe transformRecipe) {
			return transformRecipe.template;
		}
		if (recipe instanceof SmithingTrimRecipe trimRecipe) {
			return Optional.of(trimRecipe.template);
		}
		throw new IllegalArgumentException("Unknown recipe type: " + recipe.getClass());
	}

	@Override
	public ItemStack getGrindstoneResult(GrindstoneScreenHandler grindstoneMenu, ItemStack input1, ItemStack input2) {
		return grindstoneMenu.getOutputStack(input1, input2);
	}

	@Override
	public List<IJeiBrewingRecipe> getBrewingRecipes(IIngredientManager ingredientManager, IVanillaRecipeFactory vanillaRecipeFactory, BrewingRecipeRegistry potionBrewing) {
		return BrewingRecipeMaker.getBrewingRecipes(ingredientManager, vanillaRecipeFactory, potionBrewing);
	}

	@Override
	public String[] shrinkShapedRecipePattern(List<String> pattern) {
		return RawShapedRecipe.removePadding(pattern);
	}

	@Override
	public boolean isItemEnchantable(ItemStack stack, RegistryEntry<Enchantment> enchantment) {
		return true;
	}
}
