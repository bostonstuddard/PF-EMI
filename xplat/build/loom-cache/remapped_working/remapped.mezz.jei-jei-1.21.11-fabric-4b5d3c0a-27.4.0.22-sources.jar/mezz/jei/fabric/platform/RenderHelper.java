package mezz.jei.fabric.platform;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.datafixers.util.Either;
import mezz.jei.common.platform.IPlatformRenderHelper;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.HoveredTooltipPositioner;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.render.block.BlockModels;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Scaling;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteContents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipData;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RenderHelper implements IPlatformRenderHelper {
	@Override
	public TextRenderer getFontRenderer(MinecraftClient minecraft, ItemStack itemStack) {
		return minecraft.textRenderer;
	}

	@Override
	public boolean shouldRender(StatusEffectInstance potionEffect) {
		return true;
	}

	@Override
	@Nullable
	public Sprite getTextureAtlasSprite(BlockState blockState) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		BlockRenderManager blockRendererDispatcher = minecraft.getBlockRenderManager();
		BlockModels blockModelShapes = blockRendererDispatcher.getModels();
		Sprite textureAtlasSprite = blockModelShapes.getModelParticleSprite(blockState);
		if (textureAtlasSprite.getAtlasId().equals(MissingSprite.getMissingSpriteId())) {
			return null;
		}
		return textureAtlasSprite;
	}

	@Override
	public void blitSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, int textureWidth, int textureHeight, int uPosition, int vPosition, int x, int y, int uWidth, int vHeight) {
		guiGraphics.drawSpriteRegion(renderPipeline, sprite, textureWidth, textureHeight, uPosition, vPosition, x, y, uWidth, vHeight, -1);
	}

	@Override
	public void blitNineSlicedSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, Scaling.NineSlice scaling, int xOffset, int yOffset, int width, int height) {
		guiGraphics.drawSpriteNineSliced(renderPipeline, sprite, scaling, xOffset, yOffset, width, height, -1);
	}

	@Override
	public void blitTiledSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, Scaling.Tile scaling, int xOffset, int yOffset, int width, int height, int color) {
		guiGraphics.drawSpriteTiled(
			renderPipeline,
			sprite,
			xOffset,
			yOffset,
			width,
			height,
			0,
			0,
			scaling.width(),
			scaling.height(),
			scaling.width(),
			scaling.height(),
			color
		);
	}

	@Override
	public Optional<NativeImage> getMainImage(Sprite sprite) {
		SpriteContents contents = sprite.getContents();
		NativeImage[] frames = contents.mipmapLevelsImages;
		if (frames.length == 0) {
			return Optional.empty();
		}
		NativeImage frame = frames[0];
		return Optional.ofNullable(frame);
	}

	@Override
	public void renderTooltip(DrawContext guiGraphics, List<Either<StringVisitable, TooltipData>> elements, int x, int y, TextRenderer font, ItemStack stack) {
		List<TooltipComponent> components = elements.stream()
			.flatMap(e -> e.map(
				text -> font.wrapLines(text, 400).stream().map(TooltipComponent::of),
				tooltipComponent -> Stream.of(createClientTooltipComponent(tooltipComponent))
			))
			.collect(Collectors.toCollection(ArrayList::new));

		guiGraphics.drawTooltip(font, components, x, y, HoveredTooltipPositioner.INSTANCE, null, true);
	}

	@Override
	public Text getName(TagKey<?> tagKey) {
		return tagKey.getName();
	}

	private TooltipComponent createClientTooltipComponent(TooltipData tooltipComponent) {
		if (tooltipComponent instanceof TooltipComponent clientTooltipComponent) {
			return clientTooltipComponent;
		}
		return TooltipComponent.of(tooltipComponent);
	}
}
