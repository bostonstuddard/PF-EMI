package mezz.jei.common.gui.elements;

import mezz.jei.api.gui.drawable.IScalableDrawable;
import mezz.jei.common.gui.textures.JeiAtlasManager;
import mezz.jei.common.platform.IPlatformRenderHelper;
import mezz.jei.common.platform.Services;
import mezz.jei.common.util.ImmutableRect2i;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.metadata.GuiResourceMetadata;
import net.minecraft.client.texture.Scaling;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.Identifier;

public class ScalableDrawable implements IScalableDrawable {
	private final JeiAtlasManager atlasManager;
	private final Identifier spriteId;

	public ScalableDrawable(JeiAtlasManager atlasManager, Identifier spriteId) {
		this.atlasManager = atlasManager;
		this.spriteId = spriteId;
	}

	public void draw(DrawContext guiGraphics, ImmutableRect2i area) {
		draw(guiGraphics, area.getX(), area.getY(), area.getWidth(), area.getHeight());
	}

	@Override
	public void draw(DrawContext guiGraphics, int xOffset, int yOffset, int width, int height) {
		Sprite sprite = atlasManager.getAtlas()
			.getSprite(spriteId);
		Scaling scaling = sprite.getContents()
			.getAdditionalMetadataValue(GuiResourceMetadata.SERIALIZER)
			.orElse(GuiResourceMetadata.DEFAULT)
			.scaling();

		switch (scaling) {
			case Scaling.Tile tileScaling -> {
				IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
				renderHelper.blitTiledSprite(
					guiGraphics,
					RenderPipelines.GUI_TEXTURED,
					sprite,
					tileScaling,
					xOffset,
					yOffset,
					width,
					height,
					-1
				);
			}
			case Scaling.NineSlice nineSliceScaling -> {
				IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
				renderHelper.blitNineSlicedSprite(
					guiGraphics,
					RenderPipelines.GUI_TEXTURED,
					sprite,
					nineSliceScaling,
					xOffset,
					yOffset,
					width,
					height
				);
			}
			default -> {
				guiGraphics.drawSpriteStretched(
					RenderPipelines.GUI_TEXTURED,
					sprite,
					xOffset,
					yOffset,
					width,
					height
				);
			}
		}
	}
}
