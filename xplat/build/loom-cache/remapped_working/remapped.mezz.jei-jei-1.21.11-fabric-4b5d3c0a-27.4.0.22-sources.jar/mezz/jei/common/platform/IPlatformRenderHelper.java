package mezz.jei.common.platform;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.datafixers.util.Either;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Scaling;
import net.minecraft.client.texture.Sprite;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipData;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;

public interface IPlatformRenderHelper {
	TextRenderer getFontRenderer(MinecraftClient minecraft, ItemStack itemStack);

	boolean shouldRender(StatusEffectInstance potionEffect);

	Optional<NativeImage> getMainImage(Sprite sprite);

	void renderTooltip(DrawContext guiGraphics, List<Either<StringVisitable, TooltipData>> elements, int x, int y, TextRenderer font, ItemStack stack);

	Text getName(TagKey<?> tagKey);

	@Nullable
	Sprite getTextureAtlasSprite(BlockState blockState);

	void blitSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, int textureWidth, int textureHeight, int uPosition, int vPosition, int x, int y, int uWidth, int vHeight);

	void blitNineSlicedSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, Scaling.NineSlice scaling, int xOffset, int yOffset, int width, int height);

	void blitTiledSprite(DrawContext guiGraphics, RenderPipeline renderPipeline, Sprite sprite, Scaling.Tile scaling, int xOffset, int yOffset, int width, int height, int color);
}
