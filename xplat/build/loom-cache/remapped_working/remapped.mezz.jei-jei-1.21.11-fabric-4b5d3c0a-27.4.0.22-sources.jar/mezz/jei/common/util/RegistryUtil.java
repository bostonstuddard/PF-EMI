package mezz.jei.common.util;

import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;

public class RegistryUtil {
	private static final Map<RegistryKey<? extends Registry<?>>, Registry<?>> REGISTRY_CACHE = new HashMap<>();
	private static @Nullable DynamicRegistryManager REGISTRY_ACCESS;

	public static <T> Registry<T> getRegistry(RegistryKey<? extends Registry<T>> key) {
		Registry<?> registry = REGISTRY_CACHE.get(key);
		if (registry == null) {
			registry = getRegistryUncached(key);
			REGISTRY_CACHE.put(key, registry);
		}
		@SuppressWarnings("unchecked")
		Registry<T> castRegistry = (Registry<T>) registry;
		return castRegistry;
	}

	private static Registry<?> getRegistryUncached(RegistryKey<? extends Registry<?>> key) {
		DynamicRegistryManager registryAccess = getRegistryAccess();
		return registryAccess.getOrThrow(key);
	}

	public static DynamicRegistryManager getRegistryAccess() {
		if (REGISTRY_ACCESS == null) {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			ClientWorld level = minecraft.world;
			if (level == null) {
				throw new IllegalStateException("Could not get registry, registry access is unavailable because the level is currently null");
			}
			REGISTRY_ACCESS = level.getRegistryManager();
		}
		return REGISTRY_ACCESS;
	}

	public static void setRegistryAccess(@Nullable DynamicRegistryManager registryAccess) {
		REGISTRY_ACCESS = registryAccess;
		REGISTRY_CACHE.clear();
	}
}
