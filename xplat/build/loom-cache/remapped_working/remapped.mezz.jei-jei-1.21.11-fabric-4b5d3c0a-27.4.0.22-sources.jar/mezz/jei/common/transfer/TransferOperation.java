package mezz.jei.common.transfer;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/**
 * Represents transferring an ItemStack from inventorySlot to craftingSlot.
 */
public record TransferOperation(int inventorySlotId, int craftingSlotId) {
	public static final PacketCodec<ByteBuf, TransferOperation> STREAM_CODEC = PacketCodec.tuple(
		PacketCodecs.VAR_INT,
		p -> p.inventorySlotId,
		PacketCodecs.VAR_INT,
		p -> p.craftingSlotId,
		TransferOperation::new
	);

	public Slot inventorySlot(ScreenHandler container) {
		return container.getSlot(inventorySlotId);
	}

	public Slot craftingSlot(ScreenHandler container) {
		return container.getSlot(craftingSlotId);
	}
}
