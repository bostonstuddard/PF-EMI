package mezz.jei.common.network;

import net.minecraft.client.network.ClientPlayerEntity;

public record ClientPacketContext(ClientPlayerEntity player, IConnectionToServer connection) {
}
