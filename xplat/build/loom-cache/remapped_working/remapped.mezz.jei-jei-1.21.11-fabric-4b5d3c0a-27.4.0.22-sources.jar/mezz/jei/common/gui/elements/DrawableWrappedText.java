package mezz.jei.common.gui.elements;

import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.common.util.StringUtil;
import mezz.jei.core.util.Pair;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.util.Language;
import java.util.List;

public class DrawableWrappedText implements IDrawable {
	private static final int lineSpacing = 2;

	private final List<StringVisitable> descriptionLines;
	private final int lineHeight;
	private final int width;
	private final int height;

	public DrawableWrappedText(List<StringVisitable> text, int maxWidth) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		TextRenderer font = minecraft.textRenderer;
		this.lineHeight = font.fontHeight + lineSpacing;
		Pair<List<StringVisitable>, Boolean> result = StringUtil.splitLines(font, text, maxWidth, Integer.MAX_VALUE);
		this.descriptionLines = result.first();
		this.width = maxWidth;
		this.height = lineHeight * descriptionLines.size() - lineSpacing;
	}

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public int getHeight() {
		return height;
	}

	@Override
	public void draw(DrawContext guiGraphics, int xOffset, int yOffset) {
		Language language = Language.getInstance();
		MinecraftClient minecraft = MinecraftClient.getInstance();
		TextRenderer font = minecraft.textRenderer;

		int yPos = 0;
		for (StringVisitable descriptionLine : descriptionLines) {
			OrderedText charSequence = language.reorder(descriptionLine);
			guiGraphics.drawText(font, charSequence, xOffset, yPos + yOffset, 0xFF000000, false);
			yPos += lineHeight;
		}
	}
}
