package mezz.jei.common.platform;

import com.mojang.datafixers.util.Either;
import mezz.jei.common.input.MouseButtonEventData;
import mezz.jei.common.input.keys.IJeiKeyMappingCategoryBuilder;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.tooltip.TooltipType;

public interface IPlatformInputHelper {
	boolean isActiveAndMatches(KeyBinding keyMapping, InputUtil.Key key, Either<MouseButtonEventData, KeyInput> event);

	IJeiKeyMappingCategoryBuilder createKeyMappingCategoryBuilder(KeyBinding.Category category);

	default TooltipType getClientTooltipFlag(TooltipType tooltipFlag) {
		return tooltipFlag;
	}
}
