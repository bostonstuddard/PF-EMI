package mezz.jei.common.network.packets;

import mezz.jei.common.network.ServerPacketContext;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

public abstract class PlayToServerPacket<T extends PlayToServerPacket<T>> implements CustomPayload {
	@Override
	public abstract Id<T> getId();
	public abstract PacketCodec<RegistryByteBuf, T> streamCodec();
	public abstract void process(ServerPacketContext context);
}
