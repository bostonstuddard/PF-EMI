package mezz.jei.common.platform;

import java.util.List;
import java.util.stream.Stream;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;

public interface IPlatformIngredientHelper {
	List<Ingredient> getPotionContainers(BrewingRecipeRegistry potionBrewing);

	Stream<Ingredient> getPotionIngredients(BrewingRecipeRegistry potionBrewing);

	float getCompostValue(ItemStack itemStack);
}
