package mezz.jei.common.util;

import mezz.jei.core.util.Pair;
import net.minecraft.client.font.TextHandler;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public final class StringUtil {
	private StringUtil() {

	}

	public static Text stripStyling(Text textComponent) {
		MutableText text = textComponent.copyContentOnly();
		for (Text sibling : textComponent.getSiblings()) {
			text.append(stripStyling(sibling));
		}
		return text;
	}

	public static String removeChatFormatting(String string) {
		return Formatting.strip(string);
	}

	public static StringVisitable truncateStringToWidth(StringVisitable text, int width, TextRenderer font) {
		int ellipsisWidth = font.getWidth("...");

		StringVisitable truncatedText = font.trimToWidth(text, width - ellipsisWidth);

		Style style = getStyleAtEnd(truncatedText);

		return StringVisitable.concat(truncatedText, Text.literal("...").setStyle(style));
	}

	public static Style getStyleAtEnd(StringVisitable text) {
		final Style[] endStyle = {Style.EMPTY};

		text.visit(
			(style, s) -> {
				endStyle[0] = style;
				return Optional.empty();
			},
			Style.EMPTY
		);

		return endStyle[0];
	}

	/**
	 * Split and wrap lines, and truncate the last line if it exceeds the max lines.
	 * @return the wrapped lines, and a boolean indicating if the last line was truncated.
	 */
	public static Pair<List<StringVisitable>, Boolean> splitLines(TextRenderer font, List<StringVisitable> lines, int width, int maxLines) {
		if (lines.isEmpty()) {
			return new Pair<>(List.of(), false);
		}
		if (maxLines <= 0) {
			return new Pair<>(List.of(), true);
		}
		if (width <= 0) {
			return new Pair<>(List.copyOf(lines), false);
		}

		TextHandler splitter = font.getTextHandler();
		List<StringVisitable> result = new ArrayList<>();
		for (StringVisitable line : lines) {
			List<StringVisitable> splitLines;
			if (line.getString().isEmpty()) {
				splitLines = List.of(line);
			} else {
				splitLines = splitter.wrapLines(line, width, Style.EMPTY);
			}

			for (StringVisitable splitLine : splitLines) {
				if (result.size() == maxLines) {
					// result is at the max size, but we still have more to add.
					// Truncate the last line to indicate that there is more text that can't be displayed.
					StringVisitable last = result.removeLast();
					last = truncateStringToWidth(last, width, font);
					result.add(last);
					return new Pair<>(result, true);
				}
				result.add(splitLine);
			}

		}

		return new Pair<>(result, false);
	}

	public static List<StringVisitable> expandNewlines(Text... descriptionComponents) {
		List<StringVisitable> descriptionLinesExpanded = new ArrayList<>();
		for (Text descriptionLine : descriptionComponents) {
			ExpandNewLineTextAcceptor newLineTextAcceptor = new ExpandNewLineTextAcceptor();
			descriptionLine.visit(newLineTextAcceptor, Style.EMPTY);
			newLineTextAcceptor.addLinesTo(descriptionLinesExpanded);
		}
		return descriptionLinesExpanded;
	}

	public static String intsToString(Collection<Integer> indexes) {
		return indexes.stream()
			.sorted()
			.map(i -> Integer.toString(i))
			.collect(Collectors.joining(", "));
	}

	public static void drawCenteredStringWithShadow(DrawContext guiGraphics, TextRenderer font, String string, ImmutableRect2i area) {
		ImmutableRect2i textArea = MathUtil.centerTextArea(area, font, string);
		guiGraphics.drawTextWithShadow(font, string, textArea.getX(), textArea.getY(), 0xFFFFFFFF);
	}

	public static void drawCenteredStringWithShadow(DrawContext guiGraphics, TextRenderer font, OrderedText text, ImmutableRect2i area) {
		ImmutableRect2i textArea = MathUtil.centerTextArea(area, font, text);
		guiGraphics.drawTextWithShadow(font, text, textArea.getX(), textArea.getY(), 0xFFFFFFFF);
	}
}
