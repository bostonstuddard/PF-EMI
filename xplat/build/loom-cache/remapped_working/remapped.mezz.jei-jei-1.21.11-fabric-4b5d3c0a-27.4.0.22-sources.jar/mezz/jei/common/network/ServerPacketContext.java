package mezz.jei.common.network;

import mezz.jei.common.config.IServerConfig;
import net.minecraft.server.network.ServerPlayerEntity;

public record ServerPacketContext(ServerPlayerEntity player,
								IServerConfig serverConfig,
								IConnectionToClient connection
) {
}
