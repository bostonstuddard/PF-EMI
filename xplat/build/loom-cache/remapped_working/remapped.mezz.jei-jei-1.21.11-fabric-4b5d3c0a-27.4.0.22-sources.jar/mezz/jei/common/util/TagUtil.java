package mezz.jei.common.util;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;

public class TagUtil {
	public static <VALUE, STACK> Optional<TagKey<?>> getTagEquivalent(
		Collection<STACK> stacks,
		Function<STACK, VALUE> stackToValue,
		Supplier<Stream<RegistryEntryList.Named<VALUE>>> tagSupplier
	) {
		List<VALUE> values = stacks.stream()
			.map(stackToValue)
			.toList();

		return tagSupplier.get()
			.filter(tag -> areEquivalent(tag, values))
			.<TagKey<?>>map(RegistryEntryList.Named::getTag)
			.findFirst();
	}

	private static <VALUE> boolean areEquivalent(RegistryEntryList.Named<VALUE> tag, List<VALUE> values) {
		int count = tag.size();
		if (count != values.size()) {
			return false;
		}
		for (int i = 0; i < count; i++) {
			VALUE tagValue = tag.get(i).value();
			VALUE value = values.get(i);
			if (!value.equals(tagValue)) {
				return false;
			}
		}
		return true;
	}
}
