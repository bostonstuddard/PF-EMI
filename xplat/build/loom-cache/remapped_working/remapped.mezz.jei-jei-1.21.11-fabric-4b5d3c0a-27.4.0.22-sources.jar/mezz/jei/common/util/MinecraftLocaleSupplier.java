package mezz.jei.common.util;

import org.jspecify.annotations.Nullable;

import java.util.Locale;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.language.LanguageManager;

public class MinecraftLocaleSupplier implements Supplier<Locale> {
	@Nullable
	private String cachedLocaleCode;
	@Nullable
	private Locale cachedLocale;

	@Override
	public Locale get() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		//noinspection ConstantValue
		if (minecraft == null) {
			return Locale.getDefault();
		}
		LanguageManager languageManager = minecraft.getLanguageManager();
		String code = languageManager.getLanguage();
		if (cachedLocale == null || !code.equals(cachedLocaleCode)) {
			cachedLocaleCode = code;
			String[] splitLangCode = code.split("_", 2);
			if (splitLangCode.length == 1) { // Vanilla has some languages without underscores
				cachedLocale = Locale.of(code);
			} else {
				cachedLocale = Locale.of(splitLangCode[0], splitLangCode[1]);
			}
		}
		return cachedLocale;
	}
}
