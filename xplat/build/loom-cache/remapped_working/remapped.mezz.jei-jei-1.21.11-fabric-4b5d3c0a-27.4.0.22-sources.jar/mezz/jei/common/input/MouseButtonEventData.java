package mezz.jei.common.input;

import net.minecraft.client.gui.Click;

public record MouseButtonEventData(Click event, boolean doubleClicked) {}
