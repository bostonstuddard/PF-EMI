package mezz.jei.common.network.packets;

import mezz.jei.api.constants.ModIds;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.transfer.BasicRecipeTransferHandlerServer;
import mezz.jei.common.transfer.TransferOperation;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Identifier;
import java.util.List;

public class PacketRecipeTransfer extends PlayToServerPacket<PacketRecipeTransfer> {
	public static final CustomPayload.Id<PacketRecipeTransfer> TYPE = new CustomPayload.Id<>(Identifier.of(ModIds.JEI_ID, "recipe_transfer"));
	public static final PacketCodec<RegistryByteBuf, PacketRecipeTransfer> STREAM_CODEC = PacketCodec.tuple(
		TransferOperation.STREAM_CODEC.collect(PacketCodecs.toList()),
		p -> p.transferOperations,
		PacketCodecs.VAR_INT.collect(PacketCodecs.toList()),
		p -> p.craftingSlots,
		PacketCodecs.VAR_INT.collect(PacketCodecs.toList()),
		p -> p.inventorySlots,
		PacketCodecs.BOOLEAN,
		p -> p.maxTransfer,
		PacketCodecs.BOOLEAN,
		p -> p.requireCompleteSets,
		PacketRecipeTransfer::new
	);

	public final List<TransferOperation> transferOperations;
	public final List<Integer> craftingSlots;
	public final List<Integer> inventorySlots;
	private final boolean maxTransfer;
	private final boolean requireCompleteSets;

	public static PacketRecipeTransfer fromSlots(
			List<TransferOperation> transferOperations,
			List<Slot> craftingSlots,
			List<Slot> inventorySlots,
			boolean maxTransfer,
			boolean requireCompleteSets
	) {
		return new PacketRecipeTransfer(
				transferOperations,
				craftingSlots.stream().map(s -> s.id).toList(),
				inventorySlots.stream().map(s -> s.id).toList(),
				maxTransfer,
				requireCompleteSets
		);
	}

	public PacketRecipeTransfer(
		List<TransferOperation> transferOperations,
		List<Integer> craftingSlots,
		List<Integer> inventorySlots,
		boolean maxTransfer,
		boolean requireCompleteSets
	) {
		this.transferOperations = transferOperations;
		this.craftingSlots = craftingSlots;
		this.inventorySlots = inventorySlots;
		this.maxTransfer = maxTransfer;
		this.requireCompleteSets = requireCompleteSets;
	}

	@Override
	public Id<PacketRecipeTransfer> getId() {
		return TYPE;
	}

	@Override
	public PacketCodec<RegistryByteBuf, PacketRecipeTransfer> streamCodec() {
		return STREAM_CODEC;
	}

	@Override
	public void process(ServerPacketContext context) {
		ScreenHandler container = context.player().currentScreenHandler;
		BasicRecipeTransferHandlerServer.setItems(
				context.player(),
				transferOperations,
				craftingSlots.stream().map(container::getSlot).toList(),
				inventorySlots.stream().map(container::getSlot).toList(),
				maxTransfer,
				requireCompleteSets
		);
	}

}
