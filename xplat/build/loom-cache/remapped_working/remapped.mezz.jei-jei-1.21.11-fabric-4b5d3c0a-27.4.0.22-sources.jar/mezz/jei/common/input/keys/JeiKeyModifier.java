package mezz.jei.common.input.keys;

import mezz.jei.common.input.KeyNameUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.SystemKeycodes;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public enum JeiKeyModifier {
	CONTROL {
		@Override
		public boolean isActive(JeiKeyConflictContext context) {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			return minecraft.isCtrlPressed();
		}

		@Override
		public Text getCombinedName(InputUtil.Key key) {
			return Text.translatable("jei.key.combo.control", KeyNameUtil.getKeyDisplayName(key));
		}
	},
	CONTROL_OR_COMMAND {
		@Override
		public boolean isActive(JeiKeyConflictContext context) {
			if (SystemKeycodes.IS_MAC_OS) {
				MinecraftClient minecraft = MinecraftClient.getInstance();
				Window window = minecraft.getWindow();
				return InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_LEFT_SUPER) || InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_RIGHT_SUPER);
			}
			return CONTROL.isActive(context);
		}

		@Override
		public Text getCombinedName(InputUtil.Key key) {
			if (SystemKeycodes.IS_MAC_OS) {
				return Text.translatable("jei.key.combo.command", KeyNameUtil.getKeyDisplayName(key));
			}
			return CONTROL.getCombinedName(key);
		}
	},
	SHIFT {
		@Override
		public boolean isActive(JeiKeyConflictContext context) {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			return minecraft.isShiftPressed();
		}

		@Override
		public Text getCombinedName(InputUtil.Key key) {
			return Text.translatable("jei.key.combo.shift", KeyNameUtil.getKeyDisplayName(key));
		}
	},
	ALT {
		@Override
		public boolean isActive(JeiKeyConflictContext context) {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			return minecraft.isAltPressed();
		}

		@Override
		public Text getCombinedName(InputUtil.Key key) {
			return Text.translatable("jei.key.combo.alt", KeyNameUtil.getKeyDisplayName(key));
		}
	},
	NONE {
		@Override
		public boolean isActive(JeiKeyConflictContext context) {
			if (context.conflicts(JeiKeyConflictContext.IN_GAME)) {
				return true;
			}
			return !CONTROL.isActive(context) &&
				!CONTROL_OR_COMMAND.isActive(context) &&
				!SHIFT.isActive(context) &&
				!ALT.isActive(context);
		}

		@Override
		public Text getCombinedName(InputUtil.Key key) {
			return KeyNameUtil.getKeyDisplayName(key);
		}
	};

	public abstract boolean isActive(JeiKeyConflictContext context);

	public abstract Text getCombinedName(InputUtil.Key key);
}
