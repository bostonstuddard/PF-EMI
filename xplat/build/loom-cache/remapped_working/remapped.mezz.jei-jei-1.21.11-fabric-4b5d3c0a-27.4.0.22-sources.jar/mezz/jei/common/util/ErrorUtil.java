package mezz.jei.common.util;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import mezz.jei.api.gui.IRecipeLayoutDrawable;
import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeType;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.common.platform.IPlatformModHelper;
import mezz.jei.common.platform.Services;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryOps;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jspecify.annotations.Nullable;

import java.util.Collection;

public final class ErrorUtil {
	private static final Logger LOGGER = LogManager.getLogger();

	private ErrorUtil() {
	}

	public static <T> String getIngredientInfo(T ingredient, IIngredientType<T> ingredientType, IIngredientManager ingredientManager) {
		IIngredientHelper<T> ingredientHelper = ingredientManager.getIngredientHelper(ingredientType);
		return ingredientHelper.getErrorInfo(ingredient);
	}

	public static String getItemStackInfo(@Nullable ItemStack itemStack) {
		if (itemStack == null) {
			return "null";
		}
		Item item = itemStack.getItem();
		String itemName = getItemName(item);
		String components = itemStack.getComponentChanges().toString();
		return itemStack + " " + itemName + " components:" + components;
	}

	private static String getItemName(Item item) {
		Registry<Item> itemRegistry = RegistryUtil.getRegistry(RegistryKeys.ITEM);
		Identifier key = itemRegistry.getId(item);

		if (key != null) {
			return key.toString();
		} else if (item instanceof BlockItem blockItem) {
			final String blockName = getBlockName(blockItem);
			return "BlockItem(" + blockName + ")";
		}
		return item.getClass().getName();
	}

	@SuppressWarnings("ConstantValue")
	private static String getBlockName(BlockItem blockItem) {
		Block block = blockItem.getBlock();
		if (block == null) {
			return "null";
		}
		Registry<Block> blockRegistry = RegistryUtil.getRegistry(RegistryKeys.BLOCK);
		Identifier key = blockRegistry.getId(block);
		if (key != null) {
			return key.toString();
		}
		return block.getClass().getName();
	}

	@SuppressWarnings("ConstantConditions")
	public static void checkNotEmpty(ItemStack itemStack, String name) {
		if (itemStack == null) {
			throw new NullPointerException(name + " must not be null.");
		} else if (itemStack.isEmpty()) {
			String info = getItemStackInfo(itemStack);
			throw new IllegalArgumentException("ItemStack " + name + " must not be empty. " + info);
		}
	}

	@SuppressWarnings("ConstantConditions")
	public static <T> void checkNotEmpty(T[] values, String name) {
		if (values == null) {
			throw new NullPointerException(name + " must not be null.");
		} else if (values.length == 0) {
			throw new IllegalArgumentException(name + " must not be empty.");
		}
		for (T value : values) {
			if (value == null) {
				throw new NullPointerException(name + " must not contain null values.");
			}
		}
	}

	@SuppressWarnings("ConstantConditions")
	public static void checkNotEmpty(Collection<?> values, String name) {
		if (values == null) {
			throw new NullPointerException(name + " must not be null.");
		} else if (values.isEmpty()) {
			throw new IllegalArgumentException(name + " must not be empty.");
		} else if (!(values instanceof DefaultedList)) {
			for (Object value : values) {
				if (value == null) {
					throw new NullPointerException(name + " must not contain null values.");
				}
			}
		}
	}

	public static <T> void checkNotNull(@Nullable T object, String name) {
		if (object == null) {
			throw new NullPointerException(name + " must not be null.");
		}
	}

	@SuppressWarnings("ConstantConditions")
	public static void checkNotNull(Collection<?> values, String name) {
		if (values == null) {
			throw new NullPointerException(name + " must not be null.");
		} else if (!(values instanceof DefaultedList)) {
			for (Object value : values) {
				if (value == null) {
					throw new NullPointerException(name + " must not contain null values.");
				}
			}
		}
	}

	@SuppressWarnings("ConstantConditions")
	public static void assertMainThread() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		if (minecraft != null && !minecraft.isOnThread()) {
			Thread currentThread = Thread.currentThread();
			throw new IllegalStateException(
				"A JEI API method is being called by another mod from the wrong thread:\n" +
					currentThread + "\n" +
					"It must be called on the main thread by using Minecraft.addScheduledTask."
			);
		}
	}

	public static <T> void validateRecipes(IRecipeType<T> recipeType, Iterable<? extends T> recipes) {
		Class<?> recipeClass = recipeType.getRecipeClass();
		for (T recipe : recipes) {
			if (!recipeClass.isInstance(recipe)) {
				throw new IllegalArgumentException(recipeType + " recipes must be an instance of " + recipeClass + ". Instead got: " + recipe.getClass());
			}
		}
	}

	public static <T> CrashReport createIngredientCrashReport(Throwable throwable, String title, IIngredientManager ingredientManager, ITypedIngredient<T> typedIngredient) {
		return createIngredientCrashReport(throwable, title, ingredientManager, typedIngredient.getType(), typedIngredient.getIngredient());
	}

	public static <T> CrashReport createIngredientCrashReport(Throwable throwable, String title, IIngredientManager ingredientManager, IIngredientType<T> ingredientType, T ingredient) {
		CrashReport crashReport = CrashReport.create(throwable, title);
		CrashReportSection category = crashReport.addElement("Ingredient");
		setIngredientCategoryDetails(category, ingredientType, ingredient, ingredientManager);
		return crashReport;
	}

	public static <T> void logIngredientCrash(Throwable throwable, String title, IIngredientManager ingredientManager, IIngredientType<T> ingredientType, T ingredient) {
		CrashReportSection category = new CrashReportSection("Ingredient");
		setIngredientCategoryDetails(category, ingredientType, ingredient, ingredientManager);
		LOGGER.error(crashReportToString(throwable, title, category));
	}

	private static <T> void setIngredientCategoryDetails(CrashReportSection category, IIngredientType<T> ingredientType, T ingredient, IIngredientManager ingredientManager) {
		IIngredientHelper<T> ingredientHelper = ingredientManager.getIngredientHelper(ingredientType);
		Codec<T> ingredientCodec = ingredientManager.getIngredientCodec(ingredientType);

		IPlatformModHelper modHelper = Services.PLATFORM.getModHelper();

		category.add("Name", () -> ingredientHelper.getDisplayName(ingredient));
		category.add("Mod's Name", () -> {
			String modId = ingredientHelper.getDisplayModId(ingredient);
			return modHelper.getModNameForModId(modId);
		});
		category.add("Registry Name", () -> ingredientHelper.getIdentifier(ingredient).toString());
		category.add("Class Name", () -> ingredient.getClass().toString());
		category.add("toString Name", ingredient::toString);
		category.add("JSON", () -> {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			ClientWorld level = minecraft.world;
			assert level != null;
			DynamicRegistryManager registryAccess = level.getRegistryManager();
			RegistryOps<JsonElement> registryOps = registryAccess.getOps(JsonOps.INSTANCE);
			return ingredientCodec.encodeStart(registryOps, ingredient)
				.mapOrElse(
					JsonElement::toString,
					DataResult.Error::message
				);
		});
		category.add("Ingredient Type for JEI", () -> ingredientType.getIngredientClass().toString());
		category.add("Error Info gathered from JEI", () -> ingredientHelper.getErrorInfo(ingredient));
	}

	private static String crashReportToString(Throwable t, String title, CrashReportSection... categories) {
		StringBuilder sb = new StringBuilder();
		sb.append(title);
		sb.append(":\n\n");
		for (CrashReportSection category : categories) {
			category.addStackTrace(sb);
			sb.append("\n\n");
		}
		sb.append("-- Stack Trace --\n\n");
		sb.append(ExceptionUtils.getStackTrace(t));
		return sb.toString();
	}

	public static <T> String getRecipeInfo(IRecipeLayoutDrawable<T> recipeLayoutDrawable) {
		IRecipeCategory<T> recipeCategory = recipeLayoutDrawable.getRecipeCategory();
		T recipe = recipeLayoutDrawable.getRecipe();
		return getRecipeInfo(recipeCategory, recipe);
	}

	public static <T> String getRecipeInfo(IRecipeCategory<T> recipeCategory, T recipe) {
		String recipeClass;
		if (recipe instanceof RecipeEntry<?> recipeHolder) {
			recipeClass = "RecipeHolder(%s)".formatted(recipeHolder.value().getClass());
		} else {
			recipeClass = recipe.getClass().toString();
		}

		String modName = "<unknown>";
		Identifier registryId = recipeCategory.getIdentifier(recipe);
		if (registryId != null) {
			String modId = registryId.getNamespace();
			IPlatformModHelper modHelper = Services.PLATFORM.getModHelper();
			modName = "%s (%s)".formatted(modHelper.getModNameForModId(modId), modId);
		}

		return "Recipe is from Mod: " + modName +
			"\nRecipe Id: " + registryId +
			"\nRecipe Class: " + recipeClass +
			"\nRecipe Type: " + recipeCategory.getRecipeType().getUid();
	}
}
