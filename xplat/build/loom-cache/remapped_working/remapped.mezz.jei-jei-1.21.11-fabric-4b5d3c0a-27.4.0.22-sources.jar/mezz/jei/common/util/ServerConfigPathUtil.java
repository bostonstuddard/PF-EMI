package mezz.jei.common.util;

import mezz.jei.core.util.PathUtil;
import mezz.jei.core.util.ReflectionUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.world.level.storage.LevelStorage;
import java.nio.file.Path;
import java.util.Optional;

public final class ServerConfigPathUtil {
	private static final Path worldDirPath = Path.of("world");
	private static final ReflectionUtil reflectionUtil = new ReflectionUtil();

	private ServerConfigPathUtil() {

	}

	public static Optional<Path> getWorldPath(Path basePath) {
		return getWorldPath()
			.map(basePath::resolve);
	}

	private static Optional<Path> getWorldPath() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		return Optional.ofNullable(minecraft.getNetworkHandler())
			.flatMap(clientPacketListener -> {
				ClientConnection connection = clientPacketListener.getConnection();
				if (connection.isLocal()) {
					return Optional.ofNullable(minecraft.getServer())
						.flatMap(minecraftServer ->
							reflectionUtil.getFieldWithClass(minecraftServer, LevelStorage.Session.class)
								.findFirst()
								.map(LevelStorage.Session::getDirectoryName)
								.map(PathUtil::sanitizePathName)
								.map(name -> worldDirPath.resolve("local").resolve(name))
						);
				}
				return Optional.ofNullable(minecraft.getCurrentServerEntry())
					.map(serverData -> {
						int ipHash = serverData.address.hashCode();
						String ipHashHex = Integer.toHexString(ipHash);
						String name = String.format("%s_%s", serverData.name, ipHashHex);
						name = PathUtil.sanitizePathName(name);
						return worldDirPath.resolve("server").resolve(name);
					});
			});
	}
}
