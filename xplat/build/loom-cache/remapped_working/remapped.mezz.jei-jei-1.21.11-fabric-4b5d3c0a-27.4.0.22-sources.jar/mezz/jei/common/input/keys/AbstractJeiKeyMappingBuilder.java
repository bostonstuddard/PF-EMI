package mezz.jei.common.input.keys;

import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public abstract class AbstractJeiKeyMappingBuilder implements IJeiKeyMappingBuilder {
	protected abstract IJeiKeyMappingInternal buildMouse(int mouseButton);

	@Override
	public final IJeiKeyMappingInternal buildMouseLeft() {
		return buildMouse(InputUtil.GLFW_MOUSE_BUTTON_LEFT);
	}

	@Override
	public final IJeiKeyMappingInternal buildMouseRight() {
		return buildMouse(InputUtil.GLFW_MOUSE_BUTTON_RIGHT);
	}

	@Override
	public final IJeiKeyMappingInternal buildMouseMiddle() {
		return buildMouse(InputUtil.GLFW_MOUSE_BUTTON_MIDDLE);
	}

	@Override
	public final IJeiKeyMappingInternal buildUnbound() {
		return buildKeyboardKey(GLFW.GLFW_KEY_UNKNOWN);
	}
}
