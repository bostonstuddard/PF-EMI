package mezz.jei.common.input;

import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public class KeyNameUtil {
	/**
	 * The vanilla translation for left click is "LEFT BUTTON" and right click is "RIGHT BUTTON".
	 * We want better names for these in tooltips, and so use our own localization.
	 */
	public static Text getKeyDisplayName(InputUtil.Key key) {
		// The vanilla translation for left click is "LEFT BUTTON" and right click is "RIGHT BUTTON".
		// We want better names for these in tooltips, and so use our own localization.
		if (key.getCategory() == InputUtil.Type.MOUSE) {
			int value = key.getCode();
			if (value == InputUtil.GLFW_MOUSE_BUTTON_LEFT) {
				return Text.translatable("jei.key.mouse.left");
			} else if (value == InputUtil.GLFW_MOUSE_BUTTON_RIGHT) {
				return Text.translatable("jei.key.mouse.right");
			}
		}
		return key.getLocalizedText();
	}
}
