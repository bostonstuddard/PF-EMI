package mezz.jei.common.platform;

import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FuelRegistry;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;

public interface IPlatformItemStackHelper {
	int getBurnTime(ItemStack itemStack, RecipeType<?> recipeType, FuelRegistry fuelValues);

	Optional<String> getCreatorModId(ItemStack stack);

	List<Text> getTestTooltip(@Nullable PlayerEntity player, ItemStack itemStack);

	default AttributeModifiersComponent getItemAttributeModifiers(ItemStack stack) {
		return stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
	}

	boolean canEnchant(RegistryEntry<Enchantment> enchantment, ItemStack ingredient);
}
