package mezz.jei.common.network.codecs;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;

public class EnumStreamCodec<T extends Enum<T>> implements PacketCodec<PacketByteBuf, T> {
	private final Class<T> enumClass;

	public EnumStreamCodec(Class<T> enumClass) {
		this.enumClass = enumClass;
	}

	@Override
	public T decode(PacketByteBuf buf) {
		return buf.readEnumConstant(enumClass);
	}

	@Override
	public void encode(PacketByteBuf buf, T e) {
		buf.writeEnumConstant(e);
	}
}
