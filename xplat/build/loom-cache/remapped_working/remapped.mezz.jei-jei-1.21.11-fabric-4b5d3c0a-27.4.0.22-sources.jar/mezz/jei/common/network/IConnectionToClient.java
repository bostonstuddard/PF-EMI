package mezz.jei.common.network;

import mezz.jei.common.network.packets.PlayToClientPacket;
import net.minecraft.server.network.ServerPlayerEntity;

public interface IConnectionToClient {
	<T extends PlayToClientPacket<T>> void sendPacketToClient(T packet, ServerPlayerEntity player);
}
