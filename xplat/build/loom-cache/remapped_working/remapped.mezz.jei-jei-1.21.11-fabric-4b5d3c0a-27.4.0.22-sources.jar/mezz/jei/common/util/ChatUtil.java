package mezz.jei.common.util;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Utilities for chat messages.
 */
public final class ChatUtil {
	private ChatUtil() {
	}

	public static void writeChatMessage(PlayerEntity player, String translationKey, Formatting color) {
		MutableText component = Text.translatable(translationKey);
		Style redStyle = component.getStyle().withFormatting(color);
		component.setStyle(redStyle);
		player.sendMessage(component, false);
	}
}
