package mezz.jei.common.network.packets;

import mezz.jei.common.network.ClientPacketContext;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

public abstract class PlayToClientPacket<T extends PlayToClientPacket<T>> implements CustomPayload {
	@Override
	public abstract Id<T> getId();
	public abstract PacketCodec<RegistryByteBuf, T> streamCodec();
	public abstract void process(ClientPacketContext context);
}
