package mezz.jei.common.gui.textures;

import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.SpriteLoader;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.resource.metadata.ResourceMetadataSerializer;
import net.minecraft.util.Identifier;

public class JeiAtlasManager implements ResourceReloader, AutoCloseable {
	public static final ResourceReloader.Key<PendingStitchResults> PENDING_STITCH = new ResourceReloader.Key<>();
	private final AtlasEntry atlasEntry;

	public JeiAtlasManager(TextureManager textureManager, Config config) {
		SpriteAtlasTexture atlas = new SpriteAtlasTexture(config.textureId);
		textureManager.registerTexture(config.textureId, atlas);
		this.atlasEntry = new AtlasEntry(atlas, config);
	}

	public SpriteAtlasTexture getAtlas() {
		return atlasEntry.atlas;
	}

	@Override
	public void close() {
		this.atlasEntry.close();
	}

	@Override
	public void prepareSharedState(ResourceReloader.Store state) {
		CompletableFuture<SpriteLoader.StitchResult> preparations = new CompletableFuture<>();
		PendingStitch pendingStitch = new PendingStitch(atlasEntry, preparations);
		CompletableFuture<?> readyToUpload = preparations.thenCompose(SpriteLoader.StitchResult::readyForUpload);

		state.put(PENDING_STITCH, new PendingStitchResults(pendingStitch, readyToUpload));
	}

	@Override
	public CompletableFuture<Void> reload(
		ResourceReloader.Store state,
		Executor loadAndStitchExecutor,
		ResourceReloader.Synchronizer preparationBarrier,
		Executor joinAndUploadExecutor
	) {
		PendingStitchResults pendingStitchResults = state.getOrThrow(PENDING_STITCH);
		ResourceManager resourcemanager = state.getResourceManager();

		PendingStitch pendingStitch = pendingStitchResults.pendingStitch;
		pendingStitch.entry.scheduleLoad(resourcemanager, loadAndStitchExecutor)
			.whenComplete((preparations, throwable) -> {
				if (preparations != null) {
					pendingStitch.preparations.complete(preparations);
				} else {
					pendingStitch.preparations.completeExceptionally(throwable);
				}
			});
		return pendingStitchResults.readyToUpload
			.thenCompose(preparationBarrier::whenPrepared)
			.thenAcceptAsync(ignored -> pendingStitchResults.joinAndUpload(), joinAndUploadExecutor);
	}

	public record Config(
		Identifier textureId,
		Identifier definitionLocation,
		Set<ResourceMetadataSerializer<?>> additionalMetadata
	) {}

	record AtlasEntry(SpriteAtlasTexture atlas, Config config) implements AutoCloseable {
		@Override
		public void close() {
			this.atlas.clear();
		}

		CompletableFuture<SpriteLoader.StitchResult> scheduleLoad(ResourceManager resourceManager, Executor executor) {
			return SpriteLoader.fromAtlas(this.atlas)
				.load(resourceManager, this.config.definitionLocation, 0, executor, this.config.additionalMetadata);
		}
	}

	record PendingStitch(AtlasEntry entry, CompletableFuture<SpriteLoader.StitchResult> preparations) {
		public void joinAndUpload() {
			SpriteLoader.StitchResult preparations = this.preparations.join();
			this.entry.atlas.create(preparations);
		}
	}

	public static class PendingStitchResults {
		private final PendingStitch pendingStitch;
		private final CompletableFuture<?> readyToUpload;

		PendingStitchResults(
			PendingStitch pendingStitch,
			CompletableFuture<?> readyToUpload
		) {
			this.pendingStitch = pendingStitch;
			this.readyToUpload = readyToUpload;
		}

		public void joinAndUpload() {
			pendingStitch.joinAndUpload();
		}
	}
}
