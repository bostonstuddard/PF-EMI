package mezz.jei.common.network.packets;

import com.google.common.base.Preconditions;
import mezz.jei.api.constants.ModIds;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.util.ErrorUtil;
import mezz.jei.common.util.ServerCommandUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public class PacketSetHotbarItemStack extends PlayToServerPacket<PacketSetHotbarItemStack> {
	public static final CustomPayload.Id<PacketSetHotbarItemStack> TYPE = new CustomPayload.Id<>(Identifier.of(ModIds.JEI_ID, "set_hotbar_item_stack"));
	public static final PacketCodec<RegistryByteBuf, PacketSetHotbarItemStack> STREAM_CODEC = PacketCodec.tuple(
		ItemStack.PACKET_CODEC,
		p -> p.itemStack,
		PacketCodecs.VAR_INT,
		p -> p.hotbarSlot,
		PacketSetHotbarItemStack::new
	);

	private final ItemStack itemStack;
	private final int hotbarSlot;

	public PacketSetHotbarItemStack(ItemStack itemStack, int hotbarSlot) {
		ErrorUtil.checkNotNull(itemStack, "itemStack");
		Preconditions.checkArgument(PlayerInventory.isValidHotbarIndex(hotbarSlot), "hotbar slot must be in the hotbar. got: " + hotbarSlot);
		this.itemStack = itemStack;
		this.hotbarSlot = hotbarSlot;
	}

	@Override
	public void process(ServerPacketContext context) {
		ServerCommandUtil.setHotbarSlot(context, itemStack, hotbarSlot);
	}

	@Override
	public Id<PacketSetHotbarItemStack> getId() {
		return TYPE;
	}

	@Override
	public PacketCodec<RegistryByteBuf, PacketSetHotbarItemStack> streamCodec() {
		return STREAM_CODEC;
	}
}
