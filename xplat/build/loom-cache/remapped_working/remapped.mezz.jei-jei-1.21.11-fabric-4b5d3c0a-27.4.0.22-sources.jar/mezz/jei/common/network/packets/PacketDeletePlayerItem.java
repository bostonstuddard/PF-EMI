package mezz.jei.common.network.packets;

import mezz.jei.api.constants.ModIds;
import mezz.jei.common.config.IServerConfig;
import mezz.jei.common.network.IConnectionToClient;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.util.ServerCommandUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class PacketDeletePlayerItem extends PlayToServerPacket<PacketDeletePlayerItem> {
	private static final Logger LOGGER = LogManager.getLogger();

	public static final CustomPayload.Id<PacketDeletePlayerItem> TYPE = new CustomPayload.Id<>(Identifier.of(ModIds.JEI_ID, "delete_player_item"));
	public static final PacketCodec<RegistryByteBuf, PacketDeletePlayerItem> STREAM_CODEC = PacketCodec.tuple(
		ItemStack.PACKET_CODEC,
		p -> p.itemStack,
		PacketDeletePlayerItem::new
	);

	private final ItemStack itemStack;

	public PacketDeletePlayerItem(ItemStack itemStack) {
		this.itemStack = itemStack;
	}

	@Override
	public Id<PacketDeletePlayerItem> getId() {
		return TYPE;
	}

	@Override
	public PacketCodec<RegistryByteBuf, PacketDeletePlayerItem> streamCodec() {
		return STREAM_CODEC;
	}

	@Override
	public void process(ServerPacketContext context) {
		ServerPlayerEntity player = context.player();
		IServerConfig serverConfig = context.serverConfig();
		if (ServerCommandUtil.hasPermissionForCheatMode(player, serverConfig)) {
			ItemStack playerItem = player.currentScreenHandler.getCursorStack();
			if (playerItem.getItem() == itemStack.getItem()) {
				player.currentScreenHandler.setCursorStack(ItemStack.EMPTY);
			} else if (!playerItem.isEmpty()) {
				LOGGER.warn("Player '{} ({})' tried to delete ItemStack '{}' but is currently holding a different ItemStack '{}'.", player.getName(), player.getUuid(), itemStack.toHoverableText(), playerItem.toHoverableText());
			}
		} else {
			ItemStack playerItem = player.currentScreenHandler.getCursorStack();
			LOGGER.error("Player '{} ({})' tried to delete ItemStack '{}' but does not have permission.", player.getName(), player.getUuid(), playerItem.toHoverableText());
			IConnectionToClient connection = context.connection();
			connection.sendPacketToClient(new PacketCheatPermission(false, serverConfig), player);
		}
	}
}
