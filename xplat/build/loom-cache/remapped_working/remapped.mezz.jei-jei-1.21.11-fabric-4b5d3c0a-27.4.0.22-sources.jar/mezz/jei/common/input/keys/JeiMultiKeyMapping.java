package mezz.jei.common.input.keys;

import mezz.jei.api.runtime.IJeiKeyMapping;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import java.util.Arrays;
import java.util.List;

public class JeiMultiKeyMapping implements IJeiKeyMapping {
	private final List<IJeiKeyMapping> mappings;

	public JeiMultiKeyMapping(IJeiKeyMapping... mappings) {
		this.mappings = Arrays.asList(mappings);
	}

	@Override
	public boolean isActiveAndMatches(InputUtil.Key key) {
		return this.mappings.stream()
			.anyMatch(m -> m.isActiveAndMatches(key));
	}

	@Override
	public boolean isUnbound() {
		return this.mappings.stream()
			.allMatch(IJeiKeyMapping::isUnbound);
	}

	@Override
	public Text getTranslatedKeyMessage() {
		return this.mappings.stream()
			.filter(m -> !m.isUnbound())
			.map(IJeiKeyMapping::getTranslatedKeyMessage)
			.findFirst()
			.orElseGet(() ->
				this.mappings.stream()
				.map(IJeiKeyMapping::getTranslatedKeyMessage)
				.findFirst()
				.orElseGet(() -> Text.literal("error"))
			);
	}
}
