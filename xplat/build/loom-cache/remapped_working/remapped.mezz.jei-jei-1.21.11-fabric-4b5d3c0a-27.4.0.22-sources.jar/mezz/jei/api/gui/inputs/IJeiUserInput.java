package mezz.jei.api.gui.inputs;

import mezz.jei.api.runtime.IJeiKeyMapping;
import mezz.jei.api.runtime.IJeiKeyMappings;
import net.minecraft.client.gui.Element;
import net.minecraft.client.input.AbstractInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/**
 * Represents a click or key press.
 *
 * @since 19.6.0
 */
public interface IJeiUserInput {
	/**
	 * Vanilla information about a click or key press.
	 *
	 * @since 19.6.0
	 */
	InputUtil.Key getKey();

	/**
	 * Modifiers passed into methods like {@link Element#mouseClicked}
	 *
	 * @since 19.6.0
	 */
	@AbstractInput.Modifier
	int getModifiers();

	/**
	 * Get the backing {@link AbstractInput} that this {@link IJeiUserInput} was created from.
	 *
	 * @since 27.1.0
	 */
	AbstractInput getInputWithModifiers();

	/**
	 * True on mouse down, used to check if a click could be handled.
	 *
	 * False on mouse up and key down: when the input should execute an action.
	 *
	 * Key up is ignored because JEI handles key down immediately.
	 *
	 * @since 19.6.0
	 */
	boolean isSimulate();

	/**
	 * Check if the input matches a given vanilla {@link KeyBinding}.
	 *
	 * @return true if this input and modifiers match the given key mapping.
	 *
	 * @since 19.6.0
	 */
	boolean is(KeyBinding keyMapping);

	/**
	 * Check if the input matches a given {@link IJeiKeyMapping}.
	 * See all the mappings in {@link IJeiKeyMappings}
	 *
	 * @return true if this input and modifiers match the given key mapping.
	 *
	 * @since 19.6.0
	 */
	boolean is(IJeiKeyMapping keyMapping);
}
